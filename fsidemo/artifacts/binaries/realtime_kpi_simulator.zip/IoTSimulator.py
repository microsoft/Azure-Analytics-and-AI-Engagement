import uuid
import random
import datetime
import csv, json, time
import asyncio
from azure.iot.device.aio import ProvisioningDeviceClient
import os
from azure.iot.device.aio import IoTHubDeviceClient
from azure.iot.device import Message


device_client = None

async def initializeIoTHubConnection(connection):
    global device_client

    device_client = None

    device_client = IoTHubDeviceClient.create_from_connection_string(connection['IoTHubConnectionString'])

    await device_client.connect()

async def sendDataToIoTHub(data):
    global device_client
    msg = Message(json.dumps(data))
    await device_client.send_message(msg)

async def generateData():
    
    configs = json.loads(os.getenv("IoTSimulatorConfigs"))
    sleep_seconds = configs['main_data_frequency_seconds']
    data = configs['data']

    toConvertFloatKeys = set()
    payload = {}
    while True:
        payload["RecordedOn"] = str(datetime.datetime.utcnow())
        for index in range(len(data)):
            for key in data[index]:
                if type(data[index][key]["minValue"]) == int:
                    currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                else:
                    currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                payload[key]=currVal
        print(payload)
        mainPayloadStr = json.dumps(payload)
        await sendDataToIoTHub(payload)
        time.sleep(sleep_seconds)




async def main():
    config = json.loads(os.getenv("IoTHubConfig"))
    connection = config["connection"]
    #Statement to send data to IoT Hub
    await initializeIoTHubConnection(connection)
    await generateData()



