window['runConfig'] = {    
    // BlobBaseUrl: "https://fsicdn.azureedge.net/webappassets/",
    BlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/",
    IconBlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/left-nav-icons/",
    BingMapKey: "AhBNZSn-fKVSNUE5xYFbW_qajVAZwWYc8OoSHlH8nmchGuDI6ykzYjrtbwuNSrR8",
    apiUrl: "https://#APP_NAME#.azurewebsites.net",
    
    /*
    Please follow below note before added any configurable variables
    All variables must be matching to the respective url. If url is world-map then variable will be world_map, and it has to be in small case
    */

    //All Dashboards
    ceo_dashboard_march :"",
    hof_before_dashboard : "",
    cro_before_dashboard: "",
    chief_customer_officer:"",
    customer_insight_dashboard:"",
    farmbeats_dashboard:"",
    cfo_dashboard:"",
    dash_head_financial_intelligence:"",
    chief_risk_officer: "",
    ceo_dashboard_predictive:"",
    cco_after_dashboard: "",
    ceo_dashboard_june :"",
    ceo_dashboard_september:"",
    ceo_dashboard_december: "",

    //Dashboard Top Section Report ids
    DashboardTopReportId:"#FSI_CEO_DASHBOARD#",
    DashboardTopReport_AfterName:"ReportSectionfd6f0d440865b0c1da0a",
    DashboardTopReport_AfterName2:"ReportSection68cb8066934630a72b53",
    DashboardTopReport_BeforeName:"ReportSection5f752c6bde03670c8284",


    //All Reports and there section names
    world_map: "#US_MAP_WITH_HEADER#",
    world_map_section: "15d27326-b103-4982-ac2b-84efde3fb9cb",
    msci_before:"#MSCI_REPORT#",
    msci_before_section:"ReportSection7b8f4104c68d5ee54610",
    esg_report:"#ESG_REPORT_SYNAPSE#",
    esg_report_section:"ReportSectioncfca52084a74580356b0",
    after_esg_report : "#ESG_METRICS_FOR_WOODGROVE#",
    after_esg_report_section : "ReportSection7fd0bb7d1b44be763c05",
    msci_after:"#MSCI_REPORT#",
    msci_after_section:"ReportSection5d233aa8c046ad27dce4",
    assets_management:"#GLOBAL_MARKETS#",
    assets_management_section:"ReportSection",
    revenue_and_profit : "#FINANCE_REPORT#",
    revenue_and_profit_section:"ReportSection5",
    twitter_report:"#FSI_TWITTER_REPORT#", //getting invalid access token response /twitter-report
    twitter_report_section:"ReportSection0678bfe0cde017e8e721",
    predictive_analytics:"#FSI_PREDICTIVE_ANALYTICS#",
    predictive_analytics_section:"ReportSection01004f62b9c010350168",
    geospatial_critical_risk:"ec267f7b-709c-4908-b59d-3ea27b73d4d3",
    geospatial_critical_risk_section:"ReportSectioncd5b224b435b12703bcc",
    geospatial_fraud_detect:"#GEOSPATIAL_FRAUD_DETECTION_MIAMI#", 
    geospatial_fraud_detect_section:"ReportSectionae306ab506fde7cdf01b",

    htap_report:"#FSI_HTAP#",
    htap_report_section:"ReportSectionc5acc60d2872b724db75",
    HTAP_Without_HTAPSectionName:"ReportSection7cb15bccee28f85ee6c5",
    HTAP_With_HTAPSectionName:"ReportSectionac43dfdb10c718d00489",
      
    // Used in app/pages/GlobalBing
    gb_reportId: "#GLOBAL_OVERVIEW_TILES#",
    gb_northamerica_ROA:"ReportSectionfc0fe53f7794aa89a3b1",
    gb_northamerica_CE:"ReportSectionaadeb7708656dd2b5082",
    gb_northamerica_OP:"ReportSection3cfec62c12b346a1037a",
    gb_europe_ROA:"ReportSection72e55f22cccdeab2cb7b",
    gb_europe_CE:"ReportSection17d45c25e4c0bc114dc7",
    gb_europe_OP:"ReportSection0aec011ba0895049c76e",
    gb_apac_ROA:"ReportSection8017c7243b47176352ae",
    gb_apac_CE:"ReportSectioncd40a1a6ddca5c21d659",
    gb_apac_OP:"ReportSection1be018e5d3e8518e00a8",

    // Used in GlobalOperations.tsx
    na_miami_ROA:"ReportSectionadbc2377f2c7b3656767",
    na_miami_CE:"ReportSection08315d1f93f102e213b0",
    na_miami_OP:"ReportSection5b59605333194e598a3b",
    na_phoenix_ROA:"ReportSectionba94b291ede4db000f97",
    na_phoenix_CE:"ReportSectionddb095ed184c1139b35c",
    na_phoenix_OP:"ReportSectionbc399dbd86c00588e223",
    na_newyork_ROA:"ReportSection7dfc3d09b1e1b35991c3",
    na_newyork_CE:"ReportSectionf53b9ba997d6ed1498fa",
    na_newyork_OP:"ReportSectionf770091f8866c737d416",
    na_charlotte_ROA:"ReportSection2ab692f593997a54fa33",
    na_charlotte_CE:"ReportSection365a5fc783b3142fa5dd",
    na_charlotte_OP:"ReportSection1348a6087741e32baa20",
    na_losangeles_ROA:"ReportSection214bcb5067045602c099",
    na_losangeles_CE:"ReportSection44ea72362b0346de8753",
    na_losangeles_OP:"ReportSection21a46adfb3bb5d6a429c",

    Fraud_Incident_ReportId: "#FSI_INCIDENT_REPORT#",

    //https://app.powerbi.com/groups/446dcb89-caab-4dfb-ae16-905bb8e9d05f/dashboards/c10850f3-474f-47b2-9f94-8b85318103c8?noSignUpCheck=1

    POWERAPPS_LINK: "https://apps.powerapps.com/play/6471b368-8248-446e-80d7-ed6d5285f535?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a&source=portal&screenColor=rgba(105%2C%20180%2C%2069%2C%201)",
    
    //#region  this is from health care app but updated for FSI Demo
    // Use in app/pages/PowerApps
    powerAppsSrcFormRecongnise: "https://apps.powerapps.com/play/959fc7ec-e0b8-4e05-bda9-cb62be28c416?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a&source=portal&screenColor=rgba(0%2C%20138%2C%200%2C%201)",
    
    // Used in azure form recognizer - this actually works with new data for FSI demo
    PDFblobInput: "https://#STORAGE_ACCOUNT_NAME#.blob.core.windows.net/incidentpdfs/",
    PDFblobOutput: "https://#STORAGE_ACCOUNT_NAME#.blob.core.windows.net/incidentjsons/",
    //#endregion
    SPEECH_KEY:"#SPEECH_KEY#",
    SPEECH_REGION:"#SPEECH_REGION#",
}
