Thermostats - EnqueuedTimeUTC: datetime, DeviceId: string, BatteryLevel: long, Temp: real, Humidity: real

Occupancy - EnqueuedTimeUTC: datetime, DeviceId: string, BatteryLevel: long, visitors_1: 1 - 10, visitors_2: 5 - 20, 
			visitors_3: 25 - 50, DwellTime_1: 5 - 15, DwellTime_2: 10 - 25, DwellTime_3: 20 - 30



date: 25 jan 2022


task: 	1)create a eventhub and 
	2)send telementry to it of 100 thermostats
