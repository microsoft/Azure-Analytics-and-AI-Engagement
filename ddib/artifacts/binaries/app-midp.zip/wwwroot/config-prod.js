window["runConfig"] = {
  BlobBaseUrl: "https://dreamdemoassets.blob.core.windows.net/analyticsdemo/",
  IconBlobBaseUrl:
    "https://dreamdemoassets.blob.core.windows.net/analyticsdemo/left-nav-icons/",
  apiUrl: "https://app-analytics-dream-demo.azurewebsites.net",
  // apiUrl: "https://localhost:5001",
  PAGE_ID_DASHBOARD: "36ee260a-bd01-4d65-b506-c2a7269c2a44",

  PageID_Twitter: "04494af9-fb7d-4174-944f-5ce8d2ae3cfa",
  TwitterReportSectionName: "ReportSectionec708ed167442bc760d1",

  CEO_BEFORE_DASHBOARD_ID: "af91c279-5d69-4a21-9b3b-d0af201c4028",
  ceo_dashboard_before_top_report_id: "6326fd95-02ab-4d7f-a7b0-f6614f5865b0",
  ceo_dashboard_before_top_report_sectionname:
    "ReportSection5f752c6bde03670c8284",
  ceo_dashboard_after_id: "3de83a78-f935-4e12-a33f-594bd65205e9",
  // PAGE_ID: "5e83e2f6-aac6-4bd4-a1eb-debaec14e261",

  CampaignAnylicsAfterReportId: "3ada562a-7890-4917-908d-0f5b8223c9af",
  CampaignAnylicsAfterReportSectionName: "ReportSection6b516ade5e3ee314d089",

  CampaignAnalyticDeepDiveReportId: "4256d209-7ef6-4888-853c-94ff69f1a3ef",
  CampaignAnalyticDeepDiveReportSectionName:
    "ReportSectionf2c099731dcd88ec8a6c",

  CampaignReportIdOld: "3ada562a-7890-4917-908d-0f5b8223c9af",
  CampaignReportOldSectionName: "ReportSection6b516ade5e3ee314d089",

  RetailstoreReportId: "4724e4c2-0120-407a-a0f6-99c07d9444f6",
  RetailstoreReportSectionName: "ReportSection",

  ADXHistoricalReportId: "5b4be799-375b-4052-90ea-04a7a630b352",
  ADXHistoricalReportSectionName: "ReportSection7d104fc7e0cb69ca682b",

  ADXDirectReportId: "81840a89-3f86-4987-b774-4a2939d38fff",
  ADXDirectReportSectionName: "ReportSectionb4cd1d334fe3b8497487",

  EamilAnalyticReportId: "4b9de275-01ec-404e-9c32-bac43d9fa728",
  EmailAnalyticReportSectionName: "ReportSection",

  WebSocialAnalyticReportId: "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
  WebSocialAnalyticReportSectionName: "ReportSection",

  RevenueBeforeReportId: "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
  RevenueBeforeReportSectionName: "ReportSection2493b5daafc4c9fc6116",

  RevenueAfterReportId: "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
  RevenueAfterReportSectionName: "ReportSection3fa1a88d36674bc10f9d",

  DecompReportId: "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
  DecompReportSectionName: "ReportSection8ad0b724a0cf2f7eaca4",

  ProductRecReportId: "08cb7843-3ea5-4271-b946-454c3c46c6c8",
  ProductRecReportSectionName: "ReportSectionb1db078f436c6df90c30",

  // POWERAPPS_LINK: "https://apps.powerapps.com/play/630d6be7-0070-48eb-8b27-8bab33c761d5?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
  POWERAPPS_LINK:
    "https://apps.powerapps.com/play/3de6c2f6-75b5-4877-a209-7fb8e27240a8?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
  USMapReportId: "b4d3b4fa-178f-4fcf-a8ca-961764b6ba87",
  USMapReportSectionName: "ReportSectione100aa1269c2d9800002",

  FinancialPlanningDashboardId: "378de635-c810-40ad-bba9-cca26dea1080",

  RevenueAndProfitReportId: "b081061c-f34f-40aa-8d5c-c09104e41e5c",
  RevenueSectionName: "ReportSectione6a195cc5df5faf3eb77",

  PredictiveAnatyticsReportId: "cfe4866e-edf2-4a4b-8848-39f2d9d14b5a",
  PredictiveAnatyticsReportSectionName: "ReportSection01004f62b9c010350168",

  CustomerSegmentationReportId: "a2599faa-bc02-487c-afe8-58321bee1209",
  CustomerSegmentationReportSectionName: "ReportSection8fc595c6c425617404c2",

  ESGDashboardID: "70dfd929-3875-4707-80c9-4371f5518b8c",
  CCODashboardBeforeID: "e00b2c85-ace6-4c2c-a950-704cb71b3f8c",
  search_app_url:
    "https://orange-rock-0bff3191e.1.azurestaticapps.net/search?q=drass",
  agolo_searchapp_url:
    "https://app-edgarretail-prod001.azurewebsites.net/#/search",
  agolo_searchapp_fred_url:
    "https://app-edgarretail-prod001.azurewebsites.net/#/searchforfred",
  ceo_dashboard_mid_id: "93e3185c-2ea0-4542-bde3-3e1a70c085ec",

  AcquisitionReportId: "8d2bb125-f48d-4948-954c-c5b086eafab2",
  AcquisitionReportSectionName: "ReportSectiond2bfd6ee84e5d52c5aa9",

  AcquisitionAfterDashboardId: "ebb3bb23-a4b9-42b2-980f-9dd78aa39d39",

  PostAcquisitionReportId: "8d2bb125-f48d-4948-954c-c5b086eafab2",
  PostAcquisitionReportSectionName: "ReportSection20dfb8c36bac84c37b61",

  ceo_dashboard_mid_top_report_id: "084aae93-e025-4742-834a-f82b950f281c",
  ceo_dashboard_mid_top_report_sectionname: "ReportSectionfd6f0d440865b0c1da0a",

  nov_dashboard_top_report_id: "084aae93-e025-4742-834a-f82b950f281c",
  nov_dashboard_top_report_sectionname: "ReportSection26246a2310d36c4d0ece",

  dec_dashboard_top_report_id: "6326fd95-02ab-4d7f-a7b0-f6614f5865b0",
  dec_dashboard_top_report_sectionname: "ReportSection68cb8066934630a72b53",

  ceo_dashboard_after_top_report_id: "084aae93-e025-4742-834a-f82b950f281c",
  ceo_dashboard_after_top_report_sectionname:
    "ReportSectiona691f7ffd10928c0e108",

  search_spencer_url:
    "https://retail-mediasearch-app-prod.azurewebsites.net/#/search-spencer",
  search_reta_url:
    "https://retail-mediasearch-app-prod.azurewebsites.net/#/search-reta",
  search_ryan_url:
    "https://retail-mediasearch-app-prod.azurewebsites.net/#/search-ryan",

  NOVDashboardID: "408349ef-7793-48e6-91af-d460c0a5b3a1",

  LocationAnatyticsReportId: "ee96ce52-7d29-4737-b321-8854a77884e2",
  LocationAnatyticsReportSectionName: "ReportSection46d80580e572ada4e609",

  ai_search_url: "https://orange-rock-0bff3191e.1.azurestaticapps.net",
  chat_bot_url:
    "https://webchat.botframework.com/embed/RetailBotv01/gemini?b=RetailBotv01&s=O-mEiqPttxE.Hkmh1X8ShHDpf0Kfd1taQf4DlrS7lB9iXDbtRXCdJnc&username=You",

  AfterDashboardDec: "53db44f2-2266-4a7e-9cdc-0cf9bbb7988d",

  IncidentReportID: "4b79273f-f609-42a9-8b98-eb409e42d34e",
  IncidentReportSectionName: "ReportSection1ee1dbf5b8dc07148713",

  PDFBaseLink: "https://stretailprod.blob.core.windows.net/incident-search/",
  IncidentSearchUrl:
    "https://stretailprod.blob.core.windows.net/incident-search/search.html",
  PDFBaseInvoiceLink: "https://stretailprod.blob.core.windows.net/idcard/",
  AIBuilderPowerApp_Link:
    "https://apps.powerapps.com/play/ba0a135b-c09f-4006-a8f8-bf721297ade1?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",

  TeaserVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/b839b56a-f72d-4869-b1cc-50ec02201aab/Analytics_Dream_Video_V02.ism/manifest",
  RetailStoreVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/9648425a-27c5-41f9-9708-9f83250e66dd/Ignite_Store Video_V04.ism/manifest",

  FinalVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/cf8ea61c-04e2-4e14-a1a4-bda85287684e/MIDP_Teaser_Video_V03.ism/manifest",

  ADXDirectDashboardId: "49198651-f078-4b32-ac6b-44ffd8c5e605",

  ADXDirectDashboard2Id: "bf3ca69c-92f4-4561-804d-9b108bb2716a",

  ADXDirectDashboardReport3Id: "73ec26a4-8d8e-4c58-a7be-e6c4eaec6673",
  ADXDirectDashboardReport3SectionName: "ReportSection6efc74dccd4775687467",

  with_htap_report: "42cb1f66-d0bc-4f1f-ae46-1bbde381d813",
  with_htap_report_section: "ReportSection5da67bdcb8966c1a8e9e",

  without_htap_report: "42cb1f66-d0bc-4f1f-ae46-1bbde381d813",
  without_htap_report_section: "ReportSectione651bdbd575dd0d3858d",

  CEO_AFTER_DASHBOARD_ID: "53db44f2-2266-4a7e-9cdc-0cf9bbb7988d",
};
