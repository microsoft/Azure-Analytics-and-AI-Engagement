window.config = {
  BlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/",
  IconBlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/left-nav-icons/",

  APIUrl: "https://#SERVER_NAME#.azurewebsites.net",
  BackendAPIUrl: "",
  // APIUrl: "https://localhost:5001",

  WorldMapReportID: "#World_Map_(Trident)#",
  WorldMapReportSectionName: "ReportSection",

  CDODashboardBeforeReportID: "#Score_Cards_Report#",
  CDODashboardBeforeReportName: "ReportSectiond6d964f1870c030ce211",

  CDODashboardAfterReportID: "#Score_Cards_Report#",
  CDODashboardAfterReportName: "ReportSectione32e6950e035b926e2e1",

  ExecutiveDashboardBeforeTopReportID: "#Retail_Group_CEO_KPI_(Trident)#",
  ExecutiveDashboardBeforeTopReportName: "ReportSection5f752c6bde03670c8284",
  ExecutiveDashboardBeforeDashboardID: "",

  ExecutiveDashboardAfterTopReportID: "#Retail_Group_CEO_KPI_(Trident)#",
  ExecutiveDashboardAfterTopReportName: "ReportSection68cb8066934630a72b53",
  ExecutiveDashboardAfterDashboardID: "",

  FinanceRevenueAndProfitabilityReportID:
    "#Contoso_Finance_Report#",
  FinanceRevenueAndProfitabilityReportSectionName: "ReportSection",

  CustomerChurnReportID: "#07_Campaign_Analytics_Report_with_Lakehouse#",
  CustomerChurnReportSectionName: "ReportSection05c28ac273e0d030e640",

  SalesPerformanceReportID: "#09_Sales_Analytics_Report_with_Warehouse#",
  SalesPerformanceReportSectionName: "ReportSection",

  CampaignAnalyticsReportID: "#Marketing_Report#",
  CampaignAnalyticsReportSectionName: "ReportSection",

  HRAnalyticsReportID: "#HR_Analytics_Report_Lakehouse#",
  HRAnalyticsReportSectionName: "ReportSection",

  OperationsReportID: "#Operations_Report#",
  OperationsReportSectionName: "ReportSection",

  ITReportID: "#IT_Report#",
  ITReportSectionName: "ReportSection",

  StoreVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/91dff02c-8b6a-4eb4-906b-1d8f224ca7e0/Fabric_StoreVideo_V06.ism/manifest",
  FinalVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/893e6cd7-b468-467c-a491-a062a85aa392/mfdb_MicrosoftFabric_WithDataBic.ism/manifest",
};
