window.environment = {
  IconBlobBaseUrl:
    "https://#STORAGE_ACCOUNT_NAME#.blob.core.windows.net/webappassets/left-nav-icons/",
  PersonaBlobBaseUrl:
    "https://#STORAGE_ACCOUNT_NAME#.blob.core.windows.net/personas/",
  BlobBaseUrl: "https://#STORAGE_ACCOUNT_NAME#.blob.core.windows.net/webappassets/",
  BackIconBlobBaseUrl:
    "https://#STORAGE_ACCOUNT_NAME#.blob.core.windows.net/webappassets/back-icons/",

  APIUrl: "https://#SERVER_NAME#.azurewebsites.net",

  WorkspaceId: "#WORKSPACE_ID#",

  WorldMapReportId: "#WORLD_MAP#",
  WorldMapReportSectionName: "ReportSection",

  ExecutiveDashboardTopReportId: "#Group_CEO_KPI_Fabric_AML#",
  ExecutiveDashboardTopReportSectionName: "ReportSection5f752c6bde03670c8284",
  ExecutiveDashboardId: "",

  CDOMetricsReportId: "#Score_Cards_Report#",
  CDOMetricsReportSectionName: "ReportSectiond6d964f1870c030ce211",

  ITDepartmentBeforeDashboardId: "",

  CustomerChurnReportId: "#07_Campaign_Analytics_Report_with_Lakehouse#",
  CustomerChurnReportSectionName: "ReportSection05c28ac273e0d030e640",

  SalesPerformanceReportId: "#09_Sales_Analytics_Report_with_Warehouse#",
  SalesPerformanceReportSectionName: "ReportSection",

  RevenueAndProfitabilityReportId: "#Contoso_Finance_Report#",
  RevenueAndProfitabilityReportSectionName: "ReportSection",

  CampaignAnalyticsReportId: "#Marketing_Report#",
  CampaignAnalyticsReportSectionName: "ReportSection",

  EmployeeManagementReportId: "#HR_Analytics_Report_Lakehouse#",
  EmployeeManagementReportSectionName: "ReportSection",

  WarehouseOperatingExpenseReportId: "#Operations_Report#",
  WarehouseOperatingExpenseReportSectionName: "ReportSection",

  ITOperationsReportId: "#IT_Report#",
  ITOperationsReportSectionName: "ReportSection",

  CDOMetricsAfterReportId: "#Score_Cards_Report#",
  CDOMetricsAfterReportSectionName: "ReportSectione32e6950e035b926e2e1",

  ITDepartmentAfterDashboardId: "",

  ExecutiveAfterDashboardTopReportId: "#Group_CEO_KPI_Fabric_AML#",
  ExecutiveAfterDashboardTopReportSectionName:
    "ReportSection68cb8066934630a72b53",
  ExecutiveAfterDashboardId: "",
};
