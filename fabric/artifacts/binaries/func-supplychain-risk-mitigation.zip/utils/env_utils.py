import os
from typing import Dict, Optional
from  dotenv import load_dotenv
load_dotenv()

def load_env_vars() -> Dict[str, Optional[str]]:
    """Load environment variables and return as a dictionary."""
    return {
        'interior_designer': os.environ.get("interior_designer"),
        'customer_loyalty': os.environ.get("customer_loyalty"),
        'inventory_agent': os.environ.get("inventory_agent"),
        'cora': os.environ.get("cora"),
        'phi_4_endpoint': os.environ.get("phi_4_endpoint"),
        'phi_4_deployment': os.environ.get("phi_4_deployment"),
        'phi_4_api_key': os.environ.get("phi_4_api_key"),
        'EUS_AZURE_OPENAI_ENDPOINT': os.environ.get("EUS_AZURE_OPENAI_ENDPOINT"),
        'EUS_AZURE_OPENAI_KEY': os.environ.get("EUS_AZURE_OPENAI_KEY"),
        'gpt4o_deployment': os.environ.get("gpt4o_deployment"),
        'AZURE_AI_AGENT_ENDPOINT': os.environ.get("AZURE_AI_AGENT_ENDPOINT")
    }

def validate_env_vars(env_vars: Dict[str, Optional[str]]) -> Dict[str, str]:
    """Validate that required environment variables are set and return validated dict."""
    required_vars = [
        'phi_4_endpoint', 'phi_4_api_key', 'phi_4_deployment'
    ]
    missing_vars = [var for var in required_vars if not env_vars.get(var)]
    if missing_vars:
        raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
    validated_vars = {}
    for key, value in env_vars.items():
        if key in required_vars:
            validated_vars[key] = value  # type: ignore - we know it's not None after validation
        else:
            validated_vars[key] = value
    return validated_vars 