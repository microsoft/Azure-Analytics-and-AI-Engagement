import azure.functions as func
import logging
import os
import json
from dotenv import load_dotenv
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential
from azure.ai.inference.models import SystemMessage, UserMessage
# from src.agents.agent_processor import AgentProcessor
from azure.ai.inference import ChatCompletionsClient
from azure.core.credentials import AzureKeyCredential
from collections import deque
from typing import Deque, Tuple, Optional, Dict
import orjson  # Faster JSON library
from openai import AzureOpenAI
from src.tools.aiSearchTools import product_recommendations
from src.tools.inventoryCheck import inventory_check
from azure.core.credentials import AzureKeyCredential
import datetime
import time
from utils.history_utils import format_chat_history, clean_conversation_history
from utils.response_utils import extract_bot_reply, parse_agent_response
from functools import lru_cache
import random
from concurrent.futures import ThreadPoolExecutor

# Import modularized utilities and services
from utils.env_utils import load_env_vars, validate_env_vars

from services.agent_service import get_or_create_agent_processor
from services.router_service import call_router, select_agent
from services.fallback_service import call_fallback
import json
import random
import os
import logging

load_dotenv()
env_vars = load_env_vars()
validated_env_vars = validate_env_vars(env_vars)

project_endpoint = validated_env_vars["AZURE_AI_AGENT_ENDPOINT"]
gpt4o_deployment=validated_env_vars['gpt4o_deployment']
if not project_endpoint:
    raise ValueError("AZURE_AI_AGENT_ENDPOINT environment variable is required")
project_client = AIProjectClient(
    endpoint=project_endpoint,
    credential=DefaultAzureCredential(),
)


app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

def extract_product_names_from_response(response_data) -> str:
    """Extract product names from response data and format them."""
    try:
        # Handle string response data
        if isinstance(response_data, str):
            try:
                response_data = orjson.loads(response_data)
            except (orjson.JSONDecodeError, TypeError):
                return ""
        
        # Handle dictionary response
        if isinstance(response_data, dict):
            products = response_data.get("products")
            if products:
                # Handle products as string (JSON)
                if isinstance(products, str):
                    try:
                        products_list = orjson.loads(products)
                    except (orjson.JSONDecodeError, TypeError):
                        return ""
                # Handle products as list
                elif isinstance(products, list):
                    products_list = products
                else:
                    return ""
                
                # Extract names from products
                if products_list and isinstance(products_list, list):
                    names = []
                    for product in products_list:
                        if isinstance(product, dict) and "name" in product:
                            names.append(product["name"])
                    if names:
                        return f" [Products Mentioned: {', '.join(names)}]"
        
        return ""
    except Exception:
        return ""

def format_chat_history(chat_history: Deque[Tuple[str, str]]) -> str:
    """Format chat history for the router prompt."""
    return "\n".join([
        f"user: {msg}" if role == "user" else f"bot: {msg}"
        for role, msg in chat_history
    ])

# Optimized JSON serialization function
def fast_json_dumps(obj, **kwargs):
    """Use orjson for faster JSON serialization."""
    return orjson.dumps(obj, **kwargs).decode('utf-8')

# Optimized string template for user message formatting
def format_user_message_with_products(image_data: str, video_summary: str, 
                                   formatted_history: str, products) -> str:
    """Optimized string formatting for user messages with products."""
    parts = [
        f'"image_description": "{image_data or ""}",',
        f'"video_description": "{video_summary or ""}",',
        f'"conversation_history": "{formatted_history}",',
        f'"products_available": {fast_json_dumps(products)}'
    ]
    return "{" + ", ".join(parts) + "}"


def select_agent(router_reply: str, env_vars: Dict[str, str]) -> Tuple[Optional[str], Optional[str]]:
    """Select agent and agent_name based on router reply."""
    start_time = time.time()
    reply = router_reply.lower()
    if "interior_designer" in reply:
        result = env_vars.get('interior_designer'), "interior_designer"
    elif "inventory_agent" in reply:
        result = env_vars.get('inventory_agent'), "inventory_agent"
    elif "customer_loyalty" in reply:
        result = env_vars.get('customer_loyalty'), "customer_loyalty"
    else:
        result = None, None
    return result

def call_router(router_client: ChatCompletionsClient, router_prompt: str, user_message: str, phi_4_deployment: str) -> str:
    """Call the router model and return its reply. Handles content filter errors."""
    start_time = time.time()  
    try:
        router_response = router_client.chat.completions.create(
            messages=[
                SystemMessage(content=router_prompt),
                UserMessage(content=user_message),
            ],
            max_tokens=2048,
            temperature=0.8,
            top_p=0.1,
            presence_penalty=0.0,
            frequency_penalty=0.0,
            model=phi_4_deployment
        )
        result = router_response.choices[0].message.content
        return result
    except Exception as e:
        # Check for content filter error
        err_str = str(e)
        if "content_filter" in err_str or "ResponsibleAIPolicyViolation" in err_str:
            # Return a special marker string so the caller can handle it 
            result = "__CONTENT_FILTER_ERROR__" + err_str
            return result
        # Otherwise, re-raise
        raise

def call_fallback(llm_client, fallback_prompt: str, gpt4o_deployment = gpt4o_deployment):
    """Call the fallback model and return its reply."""
    start_time = time.time()
    
    chat_prompt = [    
        {
            "role": "system",      
            "content": 
            [           
                {               
                    "type": "text",               
                    "text": fallback_prompt           
                }       
            ]   
        }]

    messages = chat_prompt
    completion = llm_client.chat.completions.create(
        model="gpt-4o",
        messages=messages,
        temperature=0.7,
        stream=False)
    result = completion.choices[0].message.content
    return result

def get_similar_product(llm_client, dynamic_offer_prompt: str,details, gpt4o_deployment = gpt4o_deployment):
    
    chat_prompt = [    
        {
            "role": "system",      
            "content": 
            [           
                {               
                    "type": "text",               
                    "text": dynamic_offer_prompt           
                }       
            ]   
        },
        {
            "role": "user",      
            "content": 
            [           
                {               
                    "type": "text",               
                    "text": details           
                }       
            ]   
        }
        ]

    messages = chat_prompt
    completion = llm_client.chat.completions.create(
        model="gpt-4o",
        messages=messages,
        temperature=0.7,
        stream=False)
    result = completion.choices[0].message.content
    return result

def cart_update(llm_client, cart_update_prompt: str):
    """Call the cart update model and return its reply."""
    start_time = time.time()
    
    chat_prompt = [    
        {
            "role": "system",      
            "content": 
            [           
                {               
                    "type": "text",               
                    "text": cart_update_prompt           
                }       
            ]   
        }]

    messages = chat_prompt
    completion = llm_client.chat.completions.create(
        model="gpt-4o",
        messages=messages,
        temperature=0.7,
        top_p=0.95,
        frequency_penalty=0,
        presence_penalty=0,
        stop=None,
        stream=False)
    result = completion.choices[0].message.content
    return result

ROUTER_PROMPT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prompts', 'routerPrompt.txt')
FALLBACK_PROMPT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prompts', 'fallBackPrompt.txt')
CART_UPDATE_PROMPT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prompts', 'addToCartPrompt.txt')
DYNAMIC_OFFER_PROMPT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prompts', 'dynamicOffersAgentPrompt.txt')

with open(ROUTER_PROMPT_PATH, 'r', encoding="utf-8") as file:
    ROUTER_PROMPT = file.read()

with open(FALLBACK_PROMPT_PATH, 'r', encoding="utf-8") as file:
    FALLBACK_PROMPT = file.read()

with open(CART_UPDATE_PROMPT_PATH, 'r', encoding="utf-8") as file:
    CART_UPDATE_PROMPT = file.read()

with open(DYNAMIC_OFFER_PROMPT_PATH, 'r', encoding="utf-8") as file:
    DYNAMIC_OFFER_PROMPT = file.read()
from openai import OpenAI
router_client = OpenAI(
    base_url=validated_env_vars['phi_4_endpoint'],
    api_key=validated_env_vars['phi_4_api_key']
)

llm_client = AzureOpenAI(
    azure_endpoint=validated_env_vars['EUS_AZURE_OPENAI_ENDPOINT'],
    api_key=validated_env_vars['EUS_AZURE_OPENAI_KEY'],
    api_version="2024-12-01-preview")


@app.route(route="supply_chain_risk_mitigation")
async def supply_chain_risk_mitigation(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    chat_history: Deque[Tuple[str, str]] = deque(maxlen=5)
    
    # Session-level variable to track discount_percentage
    session_discount_percentage = ""

    # Session-level variable to track persistent cart state
    persistent_cart = []
    # Track bad prompts (those that triggered content filter)
    bad_prompts = set()
    # Session-level variable to track discount_percentage
    session_discount_percentage = ""

    # Use deque with maxlen for raw_io_history to prevent unbounded growth
    raw_io_history = deque(maxlen=100)

    def redact_bad_prompts_in_history(history):
        # Returns a new deque with bad prompts replaced by <redacted>
        redacted = deque(maxlen=history.maxlen)
        for role, msg in history:
            if role == "user" and msg in bad_prompts:
                redacted.append((role, "<redacted>"))
            else:
                redacted.append((role, msg))
        return redacted
    try:
        while True:
            try:
                req_body=req.get_json()
                user_message = req_body.get("question")
                raw_io_history=req_body.get("raw_io_history")

                if raw_io_history:
                    for entry in reversed(raw_io_history):  # start from latest
                        output = entry.get("output", {})
                        if isinstance(output, dict):
                            cart_in_output = output.get("cart", [])
                            if isinstance(cart_in_output, list) and cart_in_output:
                                persistent_cart = cart_in_output
                                logging.info(f"Persistent cart updated from raw_io_history, items={len(persistent_cart)}")
                                break
            except Exception as e:
                logging.error("Error parsing message", exc_info=True)
                user_message = req_body if 'data' in locals() else ''
                conversation_history = ""

            if 'cart' in user_message.lower():
                cart_prompt = CART_UPDATE_PROMPT + "\nRAW_IO_HISTORY:\n" + fast_json_dumps(list(raw_io_history), option=orjson.OPT_INDENT_2)+ "input question" + user_message
                result = cart_update(llm_client, cart_prompt)
                return func.HttpResponse(
                            result,
                            status_code=200,
                            mimetype="application/json"
                        )
        
            try:
                if 'checkout' in user_message.lower():
                    router_reply= "inventory_agent"
                else:
                    formatted_history = format_chat_history(redact_bad_prompts_in_history(chat_history))
                    router_reply = call_router(
                        router_client,
                        ROUTER_PROMPT,
                        user_message,
                        validated_env_vars['phi_4_deployment']
                    )
                
            except Exception as e:
                logging.info(fast_json_dumps({"answer": "Error during router call", "error": str(e), "cart": persistent_cart}))
                continue
                
            
            try:
                if 'checkout' in user_message.lower():
                    agent_selected = validated_env_vars.get('inventory_agent')
                    agent_name = "inventory_agent"
                else:
                    agent_selected, agent_name = select_agent(router_reply, validated_env_vars)
                    if not agent_selected or not agent_name:
                        logging.info(fast_json_dumps({"answer": "Sorry, I could not determine the right agent.", "agent": None, "cart": persistent_cart}))
                        continue
                    logging.info(f"Agent selection protocol completed - {agent_name} agent designated for task execution")
            except Exception as e:
                logging.info(fast_json_dumps({"answer": "Error during agent selection", "error": str(e), "cart": persistent_cart}))
                continue
            
            try:
            
                if agent_name == "interior_designer":
                    logging.info("Interior Designer agent execution initiated - commencing design consultation protocol")
                    image_data = None
                    video_summary = None
                    products = None
                    products = product_recommendations(user_message)
                    user_message = f"{user_message}\n\nProducts: {fast_json_dumps(products)}"
                    user_message = format_user_message_with_products(
                        image_data or "", video_summary or "", 
                        formatted_history, products
                    )

                    fallback_prompt = FALLBACK_PROMPT + f"\n\n {user_message}"
                    fallback_reply = call_fallback(
                        llm_client,
                        fallback_prompt,
                    )
                    
                    msg = fallback_reply
                    logging.info(f"here the msg is {msg}")
                    bot_reply = extract_bot_reply(msg)
                
                elif agent_name == "inventory_agent":
                    try:
                        logging.info("Inventory Agent execution initiated - commencing stock verification protocol")
                        selected_item = random.choice(persistent_cart)
                        # Assign to variables
                        product_id = selected_item['id']
                        product_name = selected_item['name']
                        price= selected_item['price']
                        result= inventory_check(product_id, product_name)
                        persistent_cart = [p for p in persistent_cart if not (p["id"] == product_id and p["name"] == product_name)]
                        answer = f"We’re sorry, but the item you selected, {product_name}, is currently out of stock."
                        answer = fast_json_dumps({
                            "answer": answer,
                            "agent": "inventory_check_agent",
                            "cart": persistent_cart,
                            "out_of_stock": result['out_of_stock']
                        })
                        answer = json.loads(answer)

                        dynamic_offer_prompt = DYNAMIC_OFFER_PROMPT
                        details = (
                            f"The out of stock item is {product_name} "
                            f"and price is {price}. "
                            f"Suggested similar products from the following: {result['similar_products']}"
                        )

                        result = get_similar_product(llm_client, dynamic_offer_prompt, details, gpt4o_deployment=gpt4o_deployment)
                        result = json.loads(result)

                        combined_response = {"out_of_stock_product": answer, "similar_products": result}
                        return func.HttpResponse(
                            body=json.dumps(combined_response),
                            status_code=200,
                            mimetype="application/json"
                        )

                    except Exception as e:
                        try:
                            return func.HttpResponse(
                                fast_json_dumps({
                                    "answer": "Internal server error",
                                    "error": str(e),
                                    "cart": persistent_cart
                                }),
                                status_code=500,
                                mimetype="application/json"
                            )
                        except Exception:
                            pass
                
                else:
                    thread = project_client.agents.threads.create()
                    processor = get_or_create_agent_processor(
                        agent_id=agent_selected,
                        agent_type=agent_name,
                        thread_id=thread.id,
                        project_client=project_client
                    )
                    logging.info(f"{agent_name} agent execution terminated - specialized task protocol completed")
                    bot_reply = ""
                    async for msg in processor.run_conversation_with_text_stream(input_message=user_message):
                        bot_reply = extract_bot_reply(msg)
            
                
                # Parse the response first to get products
                parsed_response = parse_agent_response(bot_reply)
                parsed_response["agent"] = agent_name  # Override agent field
                
                # Add the bot reply to chat history with products if available
                bot_answer = parsed_response.get("answer", bot_reply or "")
                product_names = extract_product_names_from_response(parsed_response)
                chat_history.append(("bot", bot_answer + product_names))
                
                # Clean the conversation history to remove large product data
                chat_history = clean_conversation_history(chat_history)
                
                # Update session discount_percentage if a new one is received
                if parsed_response.get("discount_percentage"):
                    session_discount_percentage = parsed_response["discount_percentage"]
                
                # Include session discount_percentage in all responses if available
                if session_discount_percentage and not parsed_response.get("discount_percentage"):
                    parsed_response["discount_percentage"] = session_discount_percentage
                
                # When sending any other response, also append to raw_io_history
                response_json = fast_json_dumps({**parsed_response, "cart": persistent_cart})
                raw_io_history.append({"output": response_json, "cart": persistent_cart})
                return func.HttpResponse(response_json)
            except Exception as e:
                try:
                    return func.HttpResponse(fast_json_dumps({"answer": "Internal server error", "error": str(e), "cart": persistent_cart}))
                except Exception:
                    pass
    except Exception as e:
        logging.error(f"Fatal error in main loop: {e}", exc_info=True)
        return func.HttpResponse(fast_json_dumps({"answer": "Fatal server error", "error": str(e), "cart": []}))