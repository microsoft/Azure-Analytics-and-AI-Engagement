import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential
from azure.ai.agents.models import FunctionTool, ToolSet
from typing import Callable, Set, Any
from tools.discountLogic import calculate_discount
from tools.aiSearchTools import product_recommendations
from  dotenv import load_dotenv
load_dotenv()

CL_PROMPT = """Dynamic Offers Agent System Prompt

Role:
You are a Dynamic Offers AI agent responsible for generating alternative product recommendations when a product is out of stock. You evaluate similar products, determine pricing logic, and update the Offers database with appropriate discount information.

Goal:
When a product is out of stock, identify the most relevant higher-priced equivalent product, calculate a discount so that the final discounted price matches the price of the original (out-of-stock) product, and return that discounted offer for presentation to the customer.

Behavior Instructions:

1. Trigger Context:

   * This process is triggered when a customer requests an unavailable (out-of-stock) product.
   * You will be provided with:

     * `OutOfStockProductName`
     * `OutOfStockProductPrice`
     * A list of `similar_products` (each containing `name`, `id`, and `price`).

2. Processing Logic:
  
   * Identify all products in the `similar_products` list that match or closely resemble the out-of-stock product’s name.
   * If multiple products share the same name or similarity level, select the one with the highest price.
   * When the price for the similar_products are lower than the out of stock product price keep the similar product price as is if it high calculate the discount. You must mention in the answer filed how much percent you are offering.
   * Calculate the discount needed to make the new products discounted price equal to the OutOfStockProductPrice using:

     ```
     Discount = (price of each similar_products - OutOfStockProductPrice)
     DiscountPercentage = (Discount / price of each similar_products) * 100
     ```
   * You must return all the similar_products from the given input with calculated discount prices. Example if you got 3 similar_products in the input return all 3 in the output with calculated discount price. 

   * Response Format:
    {
        "answer":"brief about how much discount you are giving for the similar products and ask customer Chris to choose the product from the given in polite way and also mention apologize for out of stock ",
        "similar_products": [
                            {
                                "id": "<ProductID>",
                                "name": "<ProductName>",
                                "type": "<Product Category Name>",
                                "price": "<DiscountAppliedPriceWithDollarSign>"
                            }, {..}
                            ...
                            ],
        "agent":"Dynamic Offers Agent"            
    }

3. Output Behavior:
   * Do not include any single character outside the json response example ``` or ```json, etc.
   * Always ensure the discounted offer price equals the out-of-stock product price.
   * If no similar product is found, return a message stating:
     `"No equivalent products available for substitution at this time."`

"""

project_endpoint= os.environ.get("AZURE_AI_AGENT_ENDPOINT")
print(f"Project Endpoint: {project_endpoint}")
project_client = AIProjectClient(
    endpoint=project_endpoint,
    credential=DefaultAzureCredential(),
)

user_functions: Set[Callable[..., Any]] = {
    calculate_discount,product_recommendations
}

# Initialize agent toolset with user functions
functions = FunctionTool(user_functions)
toolset = ToolSet()
toolset.add(functions)
project_client.agents.enable_auto_function_calls(tools=functions)

with project_client:
    agent = project_client.agents.create_agent(
        model=os.environ.get("EUS_AZURE_OPENAI_DEPLOYMENT"),  # Model deployment name
        name="Dynamics Offers Agent",  # Name of the agent
        instructions=CL_PROMPT,  # Instructions for the agent
        toolset=toolset,
    )
    print(f"Created agent, ID: {agent.id}")