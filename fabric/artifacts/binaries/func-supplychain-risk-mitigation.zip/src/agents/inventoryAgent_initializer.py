import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential
from azure.ai.agents.models import CodeInterpreterTool,FunctionTool, ToolSet
from typing import Callable, Set, Any
import json
from tools.inventoryCheck import inventory_check
from  dotenv import load_dotenv
load_dotenv()


# IA_PROMPT_TARGET = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'prompts', 'InventoryAgentPrompt.txt')
# with open(IA_PROMPT_TARGET, 'r') as file:
IA_PROMPT = """Inventory Agent Guidelines
========================================
- Your task is check the inventory status and format the response as given.
 You will get the out of stock item and also similar products in the response but you should return the response in the following format

 Response Format:
 {
    "answer":"keep short message like the selected product is out of stock in polite way"
    "agent":"inventory_check_agent"
    "out
 }"""

project_endpoint=os.environ.get("AZURE_AI_AGENT_ENDPOINT")    

project_client = AIProjectClient(
    endpoint=project_endpoint,
    credential=DefaultAzureCredential(),
)

user_functions: Set[Callable[..., Any]] = {
    inventory_check,
}

# Initialize agent toolset with user functions
functions = FunctionTool(user_functions)
toolset = ToolSet()
toolset.add(functions)
project_client.agents.enable_auto_function_calls(tools=functions)

with project_client:
    # Create an agent with the Bing Grounding tool
    agent = project_client.agents.create_agent(
        model=os.environ.get("EUS_AZURE_OPENAI_DEPLOYMENT"),  # Model deployment name
        name="Inventory Check Agent",  # Name of the agent
        instructions=IA_PROMPT,  # Instructions for the agent
        toolset=toolset
    )
    print(f"Created agent, ID: {agent.id}")