def calculate_discount():
    return "10% discount applied"