import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from  dotenv import load_dotenv
import os.path
env_path = os.path.join(os.path.dirname(__file__), "..", "parameters.env")

load_dotenv(env_path)

# Initialize Azure OpenAI and Azure Cognitive Search credentials
SEARCH_ENDPOINT = os.getenv("SEARCH_ENDPOINT")
print(f"Search Endpoint: {SEARCH_ENDPOINT}")
SEARCH_KEY = os.getenv("SEARCH_KEY")
INDEX_NAME = os.getenv("INDEX_NAME")

# Validate that required environment variables are set
if not SEARCH_ENDPOINT:
    raise ValueError("SEARCH_ENDPOINT environment variable is not set")
if not SEARCH_KEY:
    raise ValueError("SEARCH_KEY environment variable is not set")
if not INDEX_NAME:
    raise ValueError("INDEX_NAME environment variable is not set")

# Initialize Azure Cognitive Search client
credential = AzureKeyCredential(SEARCH_KEY)
search_client = SearchClient(
    endpoint=SEARCH_ENDPOINT,
    index_name=INDEX_NAME,
    credential=credential
)

# Main function to provide product recommendations with inventory check


def product_recommendations(question):
    """
    Input: 
        question (str): Natural language user query
    Output:
        products_with_inventory (list): Product json with product information
    """

    #add painters tape for narrative
    question = question
    
    # Step 1: Search
    search_results = search_client.search(
        search_text=question,
        query_type="semantic",
        semantic_configuration_name="product-catalog-index-semantic-configuration",
        top=10
    )

    print(search_results)

    # Step 2: Build response (optimized)
    get = dict.get
    response = [
        {
            "id": get(item, "ProductID", None),
            "name": get(item, "ProductName", None),
            "type": get(item, "ProductCategory", None),
            "price": get(item, "Price", None)
        }
        for item in search_results
    ]
    return response
