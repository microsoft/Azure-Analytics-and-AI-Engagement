import json
import random
import os
# from dotenv import load_dotenv
from azure.identity import DefaultAzureCredential
from azure.kusto.data import KustoClient, KustoConnectionStringBuilder
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from azure.kusto.ingest import QueuedIngestClient, IngestionProperties
from azure.kusto.data import DataFormat
from azure.kusto.data.helpers import dataframe_from_result_table
import pandas as pd
import datetime
from  dotenv import load_dotenv
import os.path
env_path = os.path.join(os.path.dirname(__file__), "..", "parameters.env")

load_dotenv(env_path)


# Load environment variables from .env file

cluster = os.getenv("cluster")
database3 = os.getenv("database3")
tablename= os.getenv("tablename")

credential = DefaultAzureCredential()
token = credential.get_token("https://help.kusto.windows.net/.default")
kcsb = KustoConnectionStringBuilder.with_aad_application_token_authentication(cluster, token.token)
client = KustoClient(kcsb)


ingest_client = QueuedIngestClient(kcsb)

#AI Search credentials
SEARCH_ENDPOINT = os.getenv("SEARCH_ENDPOINT")
SEARCH_KEY = os.getenv("SEARCH_KEY")
INDEX_NAME = os.getenv("INDEX_NAME")

# Initialize Azure Cognitive Search client
credential = AzureKeyCredential(SEARCH_KEY)
search_client = SearchClient(
    endpoint=SEARCH_ENDPOINT,
    index_name=INDEX_NAME,
    credential=credential
)

# Mock function for AI Search – replace with actual logic if needed
def search_similar_products(product_name, category):
    # Step 1: Search
    question = f"Find similar products to {product_name} in the {category} category."
    print(f"Searching for similar products with question: {question}")
    search_results = search_client.search(
            search_text=question,
            query_type="semantic",
            semantic_configuration_name="product-catalog-index-semantic-configuration",
            top=6
        )
    print("Search results obtained.")
    # Step 2: Build response
    response = [
        {
            "id": item["ProductID"],
            "name": item["ProductName"],
            "type": "Paint Accessory",
            "price": item["Price"]
        }
        for item in search_results
        if item["ProductName"] != product_name
    ]
    print(f"Similar products response: {response}")
    return response

def inventory_check(product_id, product_name):
    print(f"Checking inventory for ProductID: {product_id}, ProductName: {product_name}")
    print(f"Using table: {tablename}")
    # Step 1: Query to fetch existing row(s)
    query = f"""
    let targetProductID = "{product_id}";
    let targetProductName = "{product_name}";
    {tablename}
    | where ProductID == targetProductID and ProductName == targetProductName
    """
    response = client.execute(database3, query)
    table = response.primary_results[0]
    print(f"Query executed. Number of rows fetched: {table.rows}")
    if not table:
        print("No matching records found.")
        return None

    # Extract the row
    columns = [col.column_name for col in table.columns]
    print(f"Columns found: {columns}")
    row_dict = None
    for row in table:
        row_dict = dict(zip(columns, row))
        print(f"Row fetched from Kusto: {row_dict}")
        break  # Keep this if you only want the first row

    # Step 2: Soft-delete old record (mark as deleted if supported)
    delete_command = f""".delete table {tablename} records <| {tablename} | where ProductName == "{product_name}" and ProductID == "{product_id}"
    """
    print(f"Executing delete command: {delete_command}")
    client.execute_mgmt(database3, delete_command)


    # Step 3: Prepare updated row
    updated_row = {
        "ProductID": row_dict["ProductID"],
        "ProductName": row_dict["ProductName"],
        "ProductCategory": row_dict["ProductCategory"],
        "StoreLocation": row_dict["StoreLocation"],
        "InventorySKU": row_dict["InventorySKU"],
        "StockAvailabilityStatus": "Out of Stock",
        "LastRestockDateTime": row_dict["LastRestockDateTime"],
        "EventProcessedUtcTime": datetime.datetime.utcnow().isoformat(),
        "PartitionId": row_dict["PartitionId"],
        "EventEnqueuedUtcTime": row_dict["EventEnqueuedUtcTime"]
    }
    print(f"Updated row to ingest: {updated_row}")
    df = pd.DataFrame([updated_row])
    print(f"DataFrame to ingest:\n{df}")
    # Step 4: Ingest updated row
    ingest_client.ingest_from_dataframe(
        df,
        ingestion_properties=IngestionProperties(
            database=database3,
            table=tablename,
            data_format=DataFormat.CSV
        )
    )
    similar_products = search_similar_products(updated_row["ProductName"], updated_row["ProductCategory"])
    print(f"Similar products found: {similar_products}")

    result = {
        "out_of_stock": updated_row,
        "similar_products": similar_products
    }
    print(f"Inventory check result: {result}")
    return result

