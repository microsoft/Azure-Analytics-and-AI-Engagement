window.environment = {
  APIUrl: "https://#BackendURL#.azurewebsites.net",

  // Power BI report variables
  // world Map

  worldMapReportID: "#worldMapReportID#", //"96509277-2e13-4365-a31d-24405cc351bf",
  worldMapReportSectionName: "ReportSectionae2d438d3737f6ada513", // "ReportSectionae2d438d3737f6ada513",
  worldMapWorkSpaceId: "#WorkspaceID#", //"f94bb87b-e748-4eae-9ed6-01313579d374",

  //CEO Dashboard Before
  ceoDashboardBeforeReportID: "#ceoDashboardBeforeReportID#", //"f1e2b11f-798a-4507-aed9-2702f2a16a44",
  ceoDashboardBeforeSectionName: "#worldMapWorkSpaceId#", //"ffce5ed4a1a06d5fc7c9",
  ceoDashboardBeforeWorkSpaceID: "#WorkspaceID#", //"f94bb87b-e748-4eae-9ed6-01313579d374",

  //Contact Center - Before
  contactCenterBeforeReportID: "#contactCenterBeforeReportID#", //"6ba5d503-ba1f-4a95-aa9f-13660db3134c",
  contactCenterBeforeSectionName: "ReportSectionda209890a7f0f9e42736", //"ReportSectionda209890a7f0f9e42736",
  contactCenterBeforeWorkSpaceID: "#WorkspaceID#", //"e798f66a-a55c-42e7-aa5c-d426d3367cba",

  // Contact Center - After
  contactCenterAfterReportID: "#contactCenterAfterReportID#",
  contactCenterAfterSectionName: "ReportSectionda209890a7f0f9e42736",
  contactCenterAfterWorkSpaceID: "#WorkspaceID#",

  // Campaign Analytics Report
  campaignAnalyticsReportReportID: "#campaignAnalyticsReportReportID#", //"311a1785-b790-4987-8f9b-2777e3fb8e42",
  campaignAnalyticsReportSectionName: "2ec3641121d4103a81f",
  campaignAnalyticsReportWorkSpaceID: "#WorkspaceID#", //"374d73e5-299e-457e-9890-9614e20396e7",

  // Finance Report
  financeReportReportID: "#financeReportReportID#", //"5e08fcaa-280f-4679-97e0-7eca9dcfeaaa",
  financeReportSectionName: "ReportSection",
  financeReportWorkSpaceID: "#WorkspaceID#", //"f497565b-323a-44bb-a07e-6e4024284753",

  // Operations Report
  operationsReportReportID: "#operationsReportReportID#", //"dcf1e734-99f2-4c9d-9091-332cf652d5dd",
  operationsReportSectionName: "ReportSection",
  operationsReportWorkSpaceID: "#WorkspaceID#", //"99c30eaa-3f08-47f3-942c-d208aef797e3",

  // Network Report
  networkReportReportID: "#networkReportReportID#", //"4a8d768d-9ecc-49c9-96de-c721d82a70bf",
  networkReportSectionName: "ReportSection",
  networkReportWorkSpaceID: "#WorkspaceID#", // "0aa53d12-2996-4d09-ae83-d0a5984912db",

  // Executive Dashboard - After
  executiveDashboardAfterReportID: "#executiveDashboardAfterReportID#", //"f1e2b11f-798a-4507-aed9-2702f2a16a44",
  executiveDashboardAfterSectionName: "6f0f2d6c9b170a8d6531",
  executiveDashboardAfterWorkSpaceID: "#WorkspaceID#", //"f94bb87b-e748-4eae-9ed6-01313579d374",

  // landing page images
  // left side Icon
  IconBlobBaseUrl: "#IconBlobBaseUrl#", // "https://dreamdemoassets.blob.core.windows.net/nrf"
  // persona blob url
  personaUrl: "#personaUrl#", //"https://openaidemoassets.blob.core.windows.net/personas",
};
