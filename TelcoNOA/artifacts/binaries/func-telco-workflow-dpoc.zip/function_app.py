import azure.functions as func
import logging
import os
from azure.ai.projects import AIProjectClient
from dotenv import load_dotenv
from azure.identity import DefaultAzureCredential, get_bearer_token_provider  
import re
import json  
from openai import OpenAI

load_dotenv()

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

PROJECT_ENDPOINT = os.getenv("PROJECT_ENDPOINT")
endpoint = os.getenv("ENDPOINT_URL")
deployment = os.getenv("DEPLOYMENT_NAME")

# Get token provider for Azure OpenAI
token_provider = get_bearer_token_provider(DefaultAzureCredential(), "https://cognitiveservices.azure.com/.default")

client = OpenAI(
    base_url=endpoint,
    api_key=token_provider
)

# Function to call the telco noa workflow 
def call_workflow_agent(query: str) -> dict:
    """
    Calls a Foundry workflow agent with conversation handling,
    returns first and last output_text messages.
    """

    project_client = AIProjectClient(
        endpoint=PROJECT_ENDPOINT,
        credential=DefaultAzureCredential()
    )

    with project_client:
        workflow = {
            "name": "TelcoNoa-Workflow",
            "version": "1",
        }

        openai_client = project_client.get_openai_client()

        conversation = openai_client.conversations.create()

        response = openai_client.responses.create(
            conversation=conversation.id,
            extra_body={"agent": {"name": workflow["name"], "type": "agent_reference"}},
            input=query,
            metadata={"x-ms-debug-mode-enabled": "1"},
        )

        output_texts = []

        # Traverse in natural order (important)
        for item in response.output:
            if item.type == "message":
                for content in item.content:
                    if content.type == "output_text":
                        output_texts.append(content.text)

        first_output = output_texts[0] if output_texts else None
        last_output = output_texts[-1] if output_texts else None
        logging.info(f"here is the last output{last_output}")


        return {
            "first_output": first_output,
            "last_output": last_output
        }
    
# Helper function to safely parse JSON from model output
def safe_json_parse(content: str):
    """
    Extracts the first valid JSON object from model output.
    """
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", content, re.DOTALL)
        if match:
            return json.loads(match.group())
        raise

# Function to summarize history
def summarize_history(history):
    """
    Summarizes the history entries into a concise string in very short.
    """
    system_prompt = """
    You are a strict JSON generator.

    Task:
    - Summarize prior questions and answers into a very short context-preserving paragraph without repeating text or adding explanations, and return only valid JSON.
    Rules:
    - Do NOT repeat raw text.
    - Do NOT add explanations or markdown.
    - Output MUST be valid JSON and NOTHING ELSE.

    Required JSON format:
    {
      "history": "..."
    }
    """

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"{history}"}
    ]

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=messages,
        temperature=0
    )

    content = response.choices[0].message.content.strip()
    logging.info(f"Summary response content: {content}")
    parsed = safe_json_parse(content)
    return parsed.get("history", "")

@app.route(route="telco_workflow")
def telco_workflow(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')


    try:
        req_body = req.get_json()
    except ValueError:
        pass
    else:
        query = req_body.get('query')
        history = req_body.get('history', [])   

    # if history ==[]:
    #     history_summary = ""
    # else:
    #     history_summary = summarize_history(history)
    if query:
        # query = f"{history_summary}\n\n{query}"
        result = call_workflow_agent(query)
        return func.HttpResponse(
        body=json.dumps(result),
        status_code=200,
        mimetype="application/json"
    )

    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a query in the request body for a personalized response.",
             status_code=200
        )