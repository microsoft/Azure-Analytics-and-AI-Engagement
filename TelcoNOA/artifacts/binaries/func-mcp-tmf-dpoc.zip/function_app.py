"""
MCP Server – TMF621 Trouble Ticket (ServiceNow-backed)
Custom table: u_ticket
"""

import json
import logging
from datetime import datetime
import os
import azure.functions as func
import requests
import uuid
from requests.auth import HTTPBasicAuth
from azure.cosmos import CosmosClient, PartitionKey
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------
# Azure Function App
# ---------------------------------------------------------
app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

def now():
    return datetime.utcnow().isoformat() + "Z"


# ---------------------------------------------------------
# Option 1: If you don’t have ServiceNow credentials, use the Cosmos DB configuration.
# ---------------------------------------------------------
COSMOS_ENDPOINT = os.getenv("COSMOS_ENDPOINT")
COSMOS_KEY = os.getenv("COSMOS_KEY")
DATABASE_NAME = os.getenv("DATABASE_NAME")
CONTAINER_NAME = os.getenv("CONTAINER_NAME")

client = CosmosClient(COSMOS_ENDPOINT, COSMOS_KEY)
logging.info(f"Connected to Cosmos DB: {COSMOS_ENDPOINT}")
database = client.get_database_client(DATABASE_NAME)
container = database.get_container_client(CONTAINER_NAME)

# ---------------------------------------------------------
# Option 2: If you have a ServiceNow instance, uncomment the ServiceNow configuration section and comment out the Cosmos DB configuration.
# ---------------------------------------------------------
# SERVICENOW_INSTANCE = os.getenv("SERVICENOW_INSTANCE")
# SERVICENOW_USER = os.getenv("SERVICENOW_USER")
# SERVICENOW_PASS = os.getenv("SERVICENOW_PASS")

# SN_TABLE_URL = f"{SERVICENOW_INSTANCE}/api/now/table/u_ticket"

# SN_HEADERS = {
#     "Content-Type": "application/json",
#     "Accept": "application/json"
# }

# ---------------------------------------------------------
# Allowed Values & Transitions
# ---------------------------------------------------------
ALLOWED_STATUS = {"New", "inProgress", "onHold", "resolved", "closed"}
ALLOWED_PRIORITY = {"Low", "Medium", "High", "Critical"}

ALLOWED_STATUS_TRANSITIONS = {
    "New": {"inProgress", "onHold"},
    "inProgress": {"resolved", "onHold"},
    "onHold": {"inProgress"},
    "resolved": {"closed"}
}

# ---------------------------------------------------------
# MCP Tool Metadata
# ---------------------------------------------------------
def tool_props(props):
    return json.dumps(props)

CREATE_PROPS = tool_props([
    {"propertyName": "title", "propertyType": "string"},
    {"propertyName": "customerId", "propertyType": "string"},
    {"propertyName": "serviceId", "propertyType": "string"},
    {"propertyName": "priority", "propertyType": "string"},

    {"propertyName": "deviceId", "propertyType": "string"},
    {"propertyName": "deviceType", "propertyType": "string"},
    {"propertyName": "symptom", "propertyType": "string"},
    {"propertyName": "observedSignal", "propertyType": "string"},
    {"propertyName": "suspectedCause", "propertyType": "string"},
    {"propertyName": "recommendation", "propertyType": "string"}
])

GET_PROPS = tool_props([
    {"propertyName": "ticketId", "propertyType": "string"}
])

SEARCH_PROPS = tool_props([
    {"propertyName": "status", "propertyType": "string"},
    {"propertyName": "priority", "propertyType": "string"}
])

UPDATE_STATUS_PROPS = tool_props([
    {"propertyName": "ticketId", "propertyType": "string"},
    {"propertyName": "status", "propertyType": "string"}
])

# ---------------------------------------------------------
# MCP TOOL 1 — Create Trouble Ticket
# ---------------------------------------------------------
@app.generic_trigger(
    arg_name="context",
    type="mcpToolTrigger",
    toolName="create_trouble_ticket",
    description="Create a TMF621 trouble ticket",
    toolProperties=CREATE_PROPS,
)
def create_trouble_ticket(context: str) -> str:

    ctx = json.loads(context)
    args = ctx.get("arguments", {})
    title = args.get("title", "").strip() 
    status = args.get("status", "New").lower()
    priority = args.get("priority", "Medium").lower()
    # =====================================================
    # OPTION 1 — COSMOS DB (ACTIVE)
    # =====================================================

    ticket_id = f"TT-{uuid.uuid4().hex[:8]}"
    timestamp = now()

    ticket = {
        "id": ticket_id,
        "title": title,
        "status": status,
        "priority": priority,
        "customerId": args.get("customerId"),
        "serviceId": args.get("serviceId"),
        "created": timestamp
    }
    container.create_item(ticket)
    return json.dumps(ticket, indent=2)

    # =====================================================
    # OPTION 2 — Uncomment to use SERVICENOW and comment out COSMOS DB
    # =====================================================
    
    
    # args = json.loads(context).get("arguments", {})

    # priority = args.get("priority", "Medium")
    # if priority not in ALLOWED_PRIORITY:
    #     return json.dumps({"error": "Invalid priority"}, indent=2)

    # payload = {
    #     "u_title": args.get("title", "Trouble Ticket"),
    #     "u_status": "New",
    #     "u_priority": priority,

    #     "u_customer_id": args.get("customerId"),
    #     "u_service_id": args.get("serviceId"),

    #     "u_device_id": args.get("deviceId"),
    #     "u_device_type": args.get("deviceType"),
    #     "u_symptom": args.get("symptom"),
    #     "u_observed_signal": args.get("observedSignal"),
    #     "u_suspected_cause": args.get("suspectedCause"),
    #     "u_recommendation": args.get("recommendation")
    # }

    # logging.info(f"[CREATE] Payload: {payload}")

    # resp = requests.post(
    #     SN_TABLE_URL,
    #     auth=HTTPBasicAuth(SERVICENOW_USER, SERVICENOW_PASS),
    #     headers=SN_HEADERS,
    #     json=payload
    # )
    # resp.raise_for_status()

    # sn = resp.json()["result"]

    # return json.dumps({
    #     "id": sn["sys_id"],
    #     "title": sn.get("u_title"),
    #     "status": sn.get("u_status"),
    #     "priority": sn.get("u_priority"),
    #     "deviceId": sn.get("u_device_id"),
    #     "serviceId": sn.get("u_service_id"),
    #     "customerId": sn.get("u_customer_id"),
    #     "created": sn["sys_created_on"]
    # }, indent=2)



# ---------------------------------------------------------
# MCP TOOL 2 — Get Trouble Ticket
# ---------------------------------------------------------
@app.generic_trigger(
    arg_name="context",
    type="mcpToolTrigger",
    toolName="get_trouble_ticket",
    description="Get a trouble ticket by ID",
    toolProperties=GET_PROPS,
)
def get_trouble_ticket(context: str) -> str:
    # =====================================================
    # OPTION 1 — COSMOS DB (ACTIVE)
    # =====================================================
    ticket_id = json.loads(context)["arguments"]["ticketId"]

    try:
        ticket = container.read_item(
            item=ticket_id,
            partition_key=ticket_id
        )
        return json.dumps(ticket, indent=2)
    except Exception:
        return json.dumps(
            {"error": "Ticket not found", "ticketId": ticket_id},
            indent=2
        )
    # =====================================================
    # OPTION 2 — Uncomment to use SERVICENOW and comment out COSMOS DB
    # =====================================================

    # ticket_id = json.loads(context)["arguments"]["ticketId"]

    # resp = requests.get(
    #     f"{SN_TABLE_URL}/{ticket_id}",
    #     auth=HTTPBasicAuth(SERVICENOW_USER, SERVICENOW_PASS),
    #     headers=SN_HEADERS
    # )
    # resp.raise_for_status()

    # return json.dumps(resp.json()["result"], indent=2)

# ---------------------------------------------------------
# MCP TOOL 3 — Search Trouble Tickets
# ---------------------------------------------------------
@app.generic_trigger(
    arg_name="context",
    type="mcpToolTrigger",
    toolName="search_trouble_tickets",
    description="Search trouble tickets",
    toolProperties=SEARCH_PROPS,
)
def search_trouble_tickets(context: str) -> str:
    # =====================================================
    # OPTION 1 — COSMOS DB (ACTIVE)
    # =====================================================
    args = json.loads(context)["arguments"]

    query = "SELECT * FROM c WHERE 1=1"
    parameters = []

    if "status" in args:
        query += " AND c.status = @status"
        parameters.append({"name": "@status", "value": args["status"]})

    if "priority" in args:
        query += " AND c.priority = @priority"
        parameters.append({"name": "@priority", "value": args["priority"]})

    items = list(container.query_items(
        query=query,
        parameters=parameters,
        enable_cross_partition_query=True
    ))

    return json.dumps(items, indent=2)
    # =====================================================
    # OPTION 2 — Uncomment to use SERVICENOW and comment out COSMOS DB
    # =====================================================
    
    # args = json.loads(context)["arguments"]
    # query = []

    # if "status" in args:
    #     query.append(f"u_status={args['status']}")

    # if "priority" in args:
    #     query.append(f"u_priority={args['priority']}")

    # qs = "^".join(query)

    # resp = requests.get(
    #     f"{SN_TABLE_URL}?sysparm_query={qs}",
    #     auth=HTTPBasicAuth(SERVICENOW_USER, SERVICENOW_PASS),
    #     headers=SN_HEADERS
    # )
    # resp.raise_for_status()

    # return json.dumps(resp.json()["result"], indent=2)

# ---------------------------------------------------------
# MCP TOOL 4 — Update Trouble Ticket Status
# ---------------------------------------------------------
@app.generic_trigger(
    arg_name="context",
    type="mcpToolTrigger",
    toolName="update_trouble_ticket_status",
    description="Update trouble ticket status",
    toolProperties=UPDATE_STATUS_PROPS,
)
def update_trouble_ticket_status(context: str) -> str:
    # =====================================================
    # OPTION 1 — COSMOS DB (ACTIVE)
    # =====================================================
    args = json.loads(context)["arguments"]
    ticket_id = args["ticketId"]
    new_status = args["status"]

    try:
        ticket = container.read_item(
            item=ticket_id,
            partition_key=ticket_id
        )
    except Exception:
        return json.dumps({"error": "Ticket not found"}, indent=2)

    current_status = ticket["status"]
    allowed = ALLOWED_STATUS_TRANSITIONS.get(current_status, set())

    if new_status not in allowed:
        return json.dumps({
            "error": "Invalid status transition",
            "currentStatus": current_status,
            "allowedNext": list(allowed)
        }, indent=2)

    ticket["status"] = new_status
    ticket["lastUpdate"] = now()

    container.replace_item(
        item=ticket_id,
        body=ticket
    )

    logging.info(f"Updated Ticket {ticket_id} to {new_status}")
    return json.dumps(ticket, indent=2)
    # =====================================================
    # OPTION 2 — Uncomment to use SERVICENOW and comment out COSMOS DB
    # =====================================================
    
    
    # args = json.loads(context)["arguments"]
    # ticket_id = args["ticketId"]
    # new_status = args["status"]

    # if new_status not in ALLOWED_STATUS:
    #     return json.dumps({"error": "Invalid status"}, indent=2)

    # resp = requests.get(
    #     f"{SN_TABLE_URL}/{ticket_id}",
    #     auth=HTTPBasicAuth(SERVICENOW_USER, SERVICENOW_PASS),
    #     headers=SN_HEADERS
    # )
    # resp.raise_for_status()

    # current = resp.json()["result"]["u_status"]
    # allowed = ALLOWED_STATUS_TRANSITIONS.get(current, set())

    # if new_status not in allowed:
    #     return json.dumps({
    #         "error": "Invalid status transition",
    #         "currentStatus": current,
    #         "allowedNext": list(allowed)
    #     }, indent=2)

    # resp = requests.patch(
    #     f"{SN_TABLE_URL}/{ticket_id}",
    #     auth=HTTPBasicAuth(SERVICENOW_USER, SERVICENOW_PASS),
    #     headers=SN_HEADERS,
    #     json={"u_status": new_status}
    # )
    # resp.raise_for_status()

    # return json.dumps(resp.json()["result"], indent=2)