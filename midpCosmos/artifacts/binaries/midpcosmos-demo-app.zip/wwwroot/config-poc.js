window.config = {
  BlobBaseUrl: "https://nrfcdn.azureedge.net/",
  IconBlobBaseUrl: "https://nrfcdn.azureedge.net/left-nav-icons/",

  // APIUrl: "https://app-nrf.azurewebsites.net",
  APIUrl: "https://#SERVER_NAME#.azurewebsites.net",
  // APIUrl: "https://localhost:5001",

  //CEO Dashboard DEC
  CEODashboardMayDashboardID: "",
  CEODashboardBeforeReportID: "#Retail Group CEO KPI#",
  CEODashboardBeforeReportName: "ReportSection5f752c6bde03670c8284",

  //ADX Report New York 8 AM
  ADXDirectReportReportID: "#ADX dashboard 8AM#",
  ADXDirectReportReportSectionName: "ReportSectionb4cd1d334fe3b8497487",

  //Power Apps
  PowerApps:
    "https://apps.powerapps.com/play/619f6853-114b-4faf-817b-895668b614d3?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",

  //World Map
  WorldMapReportID: "#World Map#",
  WorldMapReportSectionName: "ReportSection",
  //Revenue and Customer Churn
  RevenueAndCustomerChurnReportID: "#Revenue and Profitability#",
  RevenueAndCustomerChurnReportSectionName: "ReportSection",

  //Ceo Dashboard Dec
  CEODashboardAfterDashboardID: "",
  CEODashboardAfterReportID: "#Retail Group CEO KPI#",
  CEODashboardAfterReportSectionName: "ReportSection68cb8066934630a72b53",

  //Location Analytics
  LocationAnalyticsReportID: "#Location Analytics#",
  LocationAnalyticsReportSectionName: "ReportSection46d80580e572ada4e609",

  //Dream Video
  CEODreamVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/6babe832-5810-4b06-baa9-81f01f472a31/NRF_Dream_Video_V08.ism/manifest",
  //Store Overview Video
  StoreVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/440da69f-c3e4-4537-ae28-8d05458c7e0b/NRF_Store_Video_V12.ism/manifest",
  //Final Video
  FinalVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/0defed2d-2acb-46cc-97f6-13b1e993f8e3/NRF_Finale_Video_V16.ism/manifest",

  //Real-time In-store Analytics
  RealTimeInStoreAnalyticsReportID: "#Realtime In Store Analytics#",
  RealTimeInStoreAnalyticsReportSectionName:
    "ReportSection6efc74dccd4775687467",

  //North America Metrics
  gb_reportId: "#Global overview tiles#",
  na_miami_ROA: "ReportSectionadbc2377f2c7b3656767",
  na_miami_CE: "ReportSection08315d1f93f102e213b0",
  na_miami_OP: "ReportSection5b59605333194e598a3b",
  na_Phoenix_ROA: "ReportSectionba94b291ede4db000f97",
  na_Phoenix_CE: "ReportSectionddb095ed184c1139b35c",
  na_Phoenix_OP: "ReportSectionbc399dbd86c00588e223",
  na_newyork_ROA: "ReportSection7dfc3d09b1e1b35991c3",
  na_newyork_CE: "ReportSectionf53b9ba997d6ed1498fa",
  na_newyork_OP: "ReportSectionf770091f8866c737d416",
  na_charlotte_ROA: "ReportSection2ab692f593997a54fa33",
  na_charlotte_CE: "ReportSection365a5fc783b3142fa5dd",
  na_charlotte_OP: "ReportSection1348a6087741e32baa20",
  na_losangeles_ROA: "ReportSection214bcb5067045602c099",
  na_losangeles_CE: "ReportSection44ea72362b0346de8753",
  na_losangeles_OP: "ReportSection21a46adfb3bb5d6a429c",

  //Stock Levels-ECO Department
  EcoDepartmentPageUrl: "https://app-nrf-zarmada-demo.azurewebsites.net/",

  //Demand By Location
  DemandByLocationReportID: "#WideWorldImporters#",
  DemandByLocationReportSectionName: "ReportSection",

  //Product Recommendations San Diego
  ProductRecommendationReportID: "#Product Recommendation#",
  ProductRecommendationReportSectionName: "ReportSectionb1db078f436c6df90c30",
};
