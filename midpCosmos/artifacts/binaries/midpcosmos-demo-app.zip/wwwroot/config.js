window.config = {
  BlobBaseUrl: "https://nrfcdn.azureedge.net/",
  IconBlobBaseUrl: "https://nrfcdn.azureedge.net/left-nav-icons/",

  APIUrl: "https://app-nrf.azurewebsites.net",
  // APIUrl: "https://localhost:5001",

  //CEO Dashboard DEC
  CEODashboardMayDashboardID: "4f9e5c14-b26d-4b26-8a39-c49e3710e6ab",
  CEODashboardBeforeReportID: "3fc0abc4-2e52-4c70-89a6-8bcc85127b07",
  CEODashboardBeforeReportName: "ReportSection5f752c6bde03670c8284",

  //ADX Report New York 8 AM
  ADXDirectReportReportID: "40c90e64-d83b-4c16-97b9-9e67910de635",
  ADXDirectReportReportSectionName: "ReportSectionb4cd1d334fe3b8497487",

  //Power Apps
  PowerApps:
    "https://apps.powerapps.com/play/619f6853-114b-4faf-817b-895668b614d3?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",

  //World Map
  WorldMapReportID: "88dddb2f-abc0-43fe-8640-ac115e373d9b",
  WorldMapReportSectionName: "ReportSection",
  //Revenue and Customer Churn
  RevenueAndCustomerChurnReportID: "4937a269-35ae-4083-82e9-417e2e29136a",
  RevenueAndCustomerChurnReportSectionName: "ReportSection",

  //Ceo Dashboard Dec
  CEODashboardAfterDashboardID: "47f28151-741a-47ff-b884-2bf19e7473ac",
  CEODashboardAfterReportID: "3fc0abc4-2e52-4c70-89a6-8bcc85127b07",
  CEODashboardAfterReportSectionName: "ReportSection68cb8066934630a72b53",

  //Location Analytics
  LocationAnalyticsReportID: "125545e3-f0a7-4e51-823d-ebef928d7cb1",
  LocationAnalyticsReportSectionName: "ReportSection46d80580e572ada4e609",

  //Dream Video
  CEODreamVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/6babe832-5810-4b06-baa9-81f01f472a31/NRF_Dream_Video_V08.ism/manifest",
  //Store Overview Video
  StoreVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/440da69f-c3e4-4537-ae28-8d05458c7e0b/NRF_Store_Video_V12.ism/manifest",
  //Final Video
  FinalVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/0defed2d-2acb-46cc-97f6-13b1e993f8e3/NRF_Finale_Video_V16.ism/manifest",

  //Real-time In-store Analytics
  RealTimeInStoreAnalyticsReportID: "adffccc8-eb71-4792-a149-85772fd53982",
  RealTimeInStoreAnalyticsReportSectionName:
    "ReportSection6efc74dccd4775687467",

  //North America Metrics
  gb_reportId: "86599efb-df63-4fe7-8ea4-480cf7de928b",
  na_miami_ROA: "ReportSectionadbc2377f2c7b3656767",
  na_miami_CE: "ReportSection08315d1f93f102e213b0",
  na_miami_OP: "ReportSection5b59605333194e598a3b",
  na_Phoenix_ROA: "ReportSectionba94b291ede4db000f97",
  na_Phoenix_CE: "ReportSectionddb095ed184c1139b35c",
  na_Phoenix_OP: "ReportSectionbc399dbd86c00588e223",
  na_newyork_ROA: "ReportSection7dfc3d09b1e1b35991c3",
  na_newyork_CE: "ReportSectionf53b9ba997d6ed1498fa",
  na_newyork_OP: "ReportSectionf770091f8866c737d416",
  na_charlotte_ROA: "ReportSection2ab692f593997a54fa33",
  na_charlotte_CE: "ReportSection365a5fc783b3142fa5dd",
  na_charlotte_OP: "ReportSection1348a6087741e32baa20",
  na_losangeles_ROA: "ReportSection214bcb5067045602c099",
  na_losangeles_CE: "ReportSection44ea72362b0346de8753",
  na_losangeles_OP: "ReportSection21a46adfb3bb5d6a429c",

  //Stock Levels-ECO Department
  EcoDepartmentPageUrl: "https://app-nrf-zarmada-demo.azurewebsites.net/",

  //ECommerce Product page
  ECommerceProductPageUrl:
    "https://nice-tree-0168e6b1e.2.azurestaticapps.net/product/6",

  //Demand By Location
  DemandByLocationReportID: "385bb636-2e3c-4910-b1dd-802b8b677015",
  DemandByLocationReportSectionName: "ReportSection",

  //Product Recommendations San Diego
  ProductRecommendationReportID: "56bdc325-4934-4557-992e-b0e77f3d4d5f",
  ProductRecommendationReportSectionName: "ReportSectionb1db078f436c6df90c30",
};
