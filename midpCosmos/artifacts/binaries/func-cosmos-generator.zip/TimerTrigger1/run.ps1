param($Timer)
$URI="sb://#NAMESPACE_THERMOSTAT_OCCUPANCY#.servicebus.windows.net/inventory"
$Access_Policy_Name="inventory"
$Access_Policy_Key="#EVENTHUB_ACCESS_POLICY_KEY#"
#Token expires now+3000
$Expires=([DateTimeOffset]::Now.ToUnixTimeSeconds())+3000
$SignatureString=[System.Web.HttpUtility]::UrlEncode($URI)+ "`n" + [string]$Expires
$HMAC = New-Object System.Security.Cryptography.HMACSHA256
$HMAC.key = [Text.Encoding]::ASCII.GetBytes($Access_Policy_Key)
$Signature = $HMAC.ComputeHash([Text.Encoding]::ASCII.GetBytes($SignatureString))
$Signature = [Convert]::ToBase64String($Signature)
$SASToken = "SharedAccessSignature sr=" + [System.Web.HttpUtility]::UrlEncode($URI) + "&sig=" + [System.Web.HttpUtility]::UrlEncode($Signature) + "&se=" + $Expires + "&skn=" + $Access_Policy_Name
$SASToken

$method = "POST"
$URI = "https://#NAMESPACE_THERMOSTAT_OCCUPANCY#.servicebus.windows.net/inventory/messages"
$signature = $sastoken

# API headers
$headers = @{
            "Authorization"=$signature;
            "Content-Type"="application/atom+xml;type=entry;charset=utf-8";
            }

$EventHubTimer = new-timespan -Minutes 30
$StopWatch = [diagnostics.stopwatch]::StartNew()
#While ($StopWatch.elapsed -lt $EventHubTimer){
$id=new-guid
$id=$id.guid
$AvailableInventory = Get-Random -minimum 685 -maximum 999
$strarry = @("Africa", "Europe", "North America")
$random=Get-Random -minimum 0 -maximum 2
$billingid = Get-Random -minimum 1234 -maximum 4321
$orderQuantity = Get-Random -minimum 15 -maximum 96
$lastupdate=get-date
$body = "{'id':'$id', 'ModelId':'Relecloud 100', 'Region':'$($strarry[$random])', 'AvailableInventory':$AvailableInventory,'BillingId': $billingid,'LastUpdate':'$lastupdate','orderQuantity':'$orderQuantity'}"

# execute the Azure REST API
Invoke-RestMethod -Uri $URI -Method $method -Headers $headers -Body $body
Start-Sleep -seconds 2
#}