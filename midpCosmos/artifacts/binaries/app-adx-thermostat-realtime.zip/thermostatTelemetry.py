import os
import json
from datetime import datetime, timedelta
import random 
import time
from azure.eventhub import EventHubProducerClient, EventData
from data import data_dict
from utilityFunctions import sendDataToPowerBI,curr_est_offset_with_utc


def thermostatData():
    configs = json.loads(os.getenv("thermostatTelemetryConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    data = configs['data']
    url_dev = configs["urlPowerBIDev"]
    counter = 0
    #url_prod = configs["urlPowerBIProd"]
    connection_str = configs["urlStringEventhub"]
    eventhub_name = configs["EventhubName"]
    client = EventHubProducerClient.from_connection_string(connection_str, eventhub_name=eventhub_name)
    store_list = ["S"+"{:03d}".format(i) for i in range(1,11)]
    cities =["Miami","San Diego","New York","San Francisco","Atlanta","Boston","Philadelphia","Singapore","Tokyo","Chicago"]
    store_list_cities_mapping = list(zip(store_list,cities))
    store_and_thermostat_mapping = []
    j = 0
    for i in range(1,101):
        store_and_thermostat_mapping.append(("TH"+"{:03d}".format(i),store_list_cities_mapping[j][0],store_list_cities_mapping[j][1]))
        if(i%10) == 0:
            j=j+1
    
    while True:
        curr_est_offset = curr_est_offset_with_utc()
        start_time = time.time()    
        event_data_batch = client.create_batch()
        payloadBatch = []
        recordedOn = str(datetime.utcnow()+timedelta(hours = curr_est_offset))
        recordedOnUTC = str(datetime.utcnow())
        for thermostatId,storeId,city in store_and_thermostat_mapping:
            payload = {}
            payload["DeviceId"] = thermostatId
            payload["City"] = city
            payload["StoreID"] = storeId
            payload["EnqueuedTimeUTC"] = recordedOn
            payload["RecordedonUTC"] = recordedOnUTC
            if(city == "New York"):
                payload["BatteryLevel"] = round(random.uniform(1,100 ), 1)
                payload["Temp"]=data_dict["Temp"][counter]
                payload["Temp_UoM"] = "F"
                counter =counter + 1 
                counter = counter%180
                #print(f"{counter} in thrmostat")
                payloadBatch.append(payload)
                continue
                            
            for index in range(len(data)):
                for key in data[index]:
                    # if(counter == 0 or (counter!=0 and (key in key_list))):
                    if type(data[index][key]["minValue"]) == int:
                        currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                        
                    elif type(data[index][key]["minValue"]) == float:
                        currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                    else:
                        currVal = random.choice(data[index][key]['minValue'])
                    payload[key]=currVal
            payloadBatch.append(payload)
        mainPayloadStr = json.dumps(payloadBatch)
        print(mainPayloadStr)
        print(time.time()-start_time)
        event_data_batch.add(EventData(mainPayloadStr))
        
        # Send list of payload to PowerBI...need to check will it work or not 
        #sendDataToPowerBI(url_dev,mainPayloadStr)
        #sendDataToPowerBI(url_prod,mainPayloadStr)
        

        # Send the batch of events to the event hub.
        client.send_batch(event_data_batch)
        time.sleep(sleep_seconds)


def occupancyData():
    configs = json.loads(os.getenv("occupancyDataConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    data = configs['data']
    url_dev = configs["urlPowerBIDev"]
    #url_prod = configs["urlPowerBIProd"]
    connection_str = configs["urlStringEventhub"]
    counter = 0

    eventhub_name = configs["EventhubName"]
    store_list = ["S"+"{:03d}".format(i) for i in range(1,11)]
    cities =["Miami","San Diego","New York","San Francisco","Atlanta","Boston","Philadelphia","Singapore","Tokyo","Chicago"]
    #["Miami","San Diego","New York","San Francisco","Las Vegas","London","Dubai","Singapore","Tokyo","Chicago"]
    store_list_cities_mapping = list(zip(store_list,cities))
    store_and_thermostat_mapping = []
    j = 0
    for i in range(1,101):
        store_and_thermostat_mapping.append(("TH"+"{:03d}".format(i),store_list_cities_mapping[j][0],store_list_cities_mapping[j][1]))
        if(i%10) == 0:
            j=j+1
    
    client = EventHubProducerClient.from_connection_string(connection_str, eventhub_name=eventhub_name)
    
    while True:
        curr_est_offset = curr_est_offset_with_utc()
        start_time = time.time()
        event_data_batch = client.create_batch()
        payloadBatch = []
        recordedOn = str(datetime.utcnow()+timedelta(hours = curr_est_offset))
        recordedOnUTC = str(datetime.utcnow())
        for thermostatId,storeId,city in store_and_thermostat_mapping:
            payload = {}
            payload["DeviceId"] = thermostatId
            payload["City"] = city
            payload["StoreID"] = storeId
            payload["EnqueuedTimeUTC"] = recordedOn
            payload["RecordedonUTC"] = recordedOnUTC
            if(city == "New York"):
                payload["visitors_cnt"]=data_dict["visitors_cnt"][counter]
                payload["avg_aisle_time_spent"]=data_dict["avg_aisle_time_spent"][counter]
                payload["avg_dwell_time"]=data_dict["avg_dwell_time"][counter]
                counter =counter + 1 
                counter = counter%180
                payload["visitors_in"] = random.randint(0, 10)
                payload["visitors_out"] = random.randint(0, 10)
                payloadBatch.append(payload)
                continue   
            for index in range(len(data)):
                for key in data[index]:
                    # if(counter == 0 or (counter!=0 and (key in key_list))):
                    if type(data[index][key]["minValue"]) == int:
                        currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                        
                    elif type(data[index][key]["minValue"]) == float:
                        currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                    else:
                        currVal = random.choice(data[index][key]['minValue'])
                    payload[key]=currVal
            payloadBatch.append(payload)
        mainPayloadStr = json.dumps(payloadBatch)
        print(mainPayloadStr)
        #print(inspect.getouterframes( inspect.currentframe() )[1][3])
        print(time.time()-start_time)
        event_data_batch.add(EventData(mainPayloadStr))
        
        # Send list of payload to PowerBI...need to check will it work or not
        #sendDataToPowerBI(url_dev,mainPayloadStr)
        #sendDataToPowerBI(url_prod,mainPayloadStr)
        
        # Send the batch of events to the event hub.
        client.send_batch(event_data_batch)        
        time.sleep(sleep_seconds)
