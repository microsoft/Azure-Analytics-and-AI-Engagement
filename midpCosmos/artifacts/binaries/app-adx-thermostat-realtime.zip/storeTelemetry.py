import os
import json
from datetime import datetime,timedelta
import random 
import time
from utilityFunctions import sendDataToPowerBI,curr_est_offset_with_utc


def storeTelemetry():
    configs = json.loads(os.getenv("storeTelemetryConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    url_dev = configs["urlPowerBIDev"]
    #url_prod = configs["urlPowerBIProd"]

    data_NY = configs["dataNY"]
    data_sanDiego = configs["dataSanDiego"]
    cities = ["New York","San Diego"]
    while True:
        PayloadBatch = []
        start_time = time.time()
        curr_est_offset = curr_est_offset_with_utc() 
        print(curr_est_offset)  
        for city in cities:
            if city == "New York":
                data = data_NY
            else:
                data = data_sanDiego
            Payload = {}
            Payload['city'] = city
            Payload["RecordedonUTC"] = str(datetime.utcnow()) 
            Payload["EnqueuedTimeUTC"] = str(datetime.utcnow()+timedelta(hours=curr_est_offset))
            
            for index in range(len(data)):
                for key in data[index]:
                    # if(counter == 0 or (counter!=0 and (key in key_list))):
                    if type(data[index][key]["minValue"]) == int:
                        currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                        
                    elif type(data[index][key]["minValue"]) == float:
                        currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                    else:
                        currVal = random.choice(data[index][key]['minValue'])
                    Payload[key]=currVal
            PayloadBatch.append(Payload)
        mainPayloadStr = json.dumps(PayloadBatch)
        print(mainPayloadStr)
        #print(inspect.getouterframes( inspect.currentframe() )[1][3])
        print(time.time()-start_time)
        
        # Send list of payload to PowerBI...need to check will it work or not
        sendDataToPowerBI(url_dev,mainPayloadStr)
        #sendDataToPowerBI(url_prod,mainPayloadStr)
        
        # Send the batch of events to the event hub.
        time.sleep(sleep_seconds)
