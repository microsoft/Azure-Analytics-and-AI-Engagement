import requests
from datetime import datetime,timedelta
import pytz

def curr_est_offset_with_utc():
    tz_est = pytz.timezone('US/Eastern')
    offset = tz_est.utcoffset(datetime.utcnow())
    offset_seconds = (offset.days * 86400) + offset.seconds
    offset_hours = offset_seconds // 3600

    return offset_hours # -4 or -5

def sendDataToPowerBI(url,data):
    try:
        x = requests.post(url, data=data)
        print(x.text)
        x.close()
        print()
    except Exception as e:
        print(e)