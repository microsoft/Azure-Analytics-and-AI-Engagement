import threading 
from flask import Flask
from storeTelemetry import storeTelemetry
from thermostatTelemetry import thermostatData,occupancyData
from storeTelemetry import storeTelemetry
from twitterKPI import twitterkpi
from BeforeScenarioCCORealtime import generateDataForBeforeScenarioCCO
from WebsiteData import WebsiteData
app = Flask(__name__)

t1 = threading.Thread(target=thermostatData).start()
t2 = threading.Thread(target=occupancyData).start() 
t3 = threading.Thread(target =storeTelemetry).start()
#t4 = threading.Thread(target=twitterkpi).start()
t5 = threading.Thread(target=generateDataForBeforeScenarioCCO).start()
t6 = threading.Thread(target=WebsiteData).start()

if __name__ =='__main__':
    
    app.run()
    

