from utilityFunctions import sendDataToPowerBI
from data import data_dict_twitter
import json
import time 
from datetime import datetime
import os 

def twitterkpi():
    configs = json.loads(os.getenv("twitterKPIConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    data = configs['data']
    url_dev = configs["urlPowerBIDev"]
    counter = 0
    while True:
        payload = {}
        payload["RecordedOn"] = str(datetime.utcnow())
        payload["TargetEngagementRate"] = 30.0
        payload["TargetRetweets"] = 25000
        payload["TargetTweets"] = 10000
        for key in data_dict_twitter.keys():
            payload[key] = data_dict_twitter[key][counter]
        counter = counter+1
        counter = counter%120
        mainPayloadStr = json.dumps([payload])
        print(mainPayloadStr)
        sendDataToPowerBI(url_dev,mainPayloadStr)
        time.sleep(sleep_seconds)