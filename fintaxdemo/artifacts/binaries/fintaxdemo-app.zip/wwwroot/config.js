window['runConfig'] = {    
    BlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/fintaxdemo",
    IconBlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/left-nav-icons/",
    BingMapKey: "Aluu4nF0kGXNCaaLiA_Y0LNnp7QPYvw0ej5DjptMTRq5xeWfbBfWSviT7n5Y2aHV",
    apiUrl: "https://#APP_NAME#.azurewebsites.net",
    FormRecognizerVideo: "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/97e59726-bbb0-412c-b4c6-ca8ea11d41db/Form_Recognizer_v1.ism/manifest",
    ImmersiveReader:"https://#IMMERSIVE_READER_FINTAX_NAME#.azurewebsites.net/",
    ChatBotUrl:"https://webchat.botframework.com/embed/#BOT_QNAMAKER_FINTAX_NAME#?s=#BOT_KEY#",
	SearchAppUrl:"",
    TeaserVideo:"https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/51c748c9-6989-4e17-924a-818bec99767f/Teaser_Video_V6.ism/manifest",
    EventVideo:"https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/c396de6a-8c02-4dfa-a4c1-a21d0ef39029/TRF_Final_V12.ism/manifest",
    FinaleVideo:"https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/a9dd0041-ee54-4770-9f4d-e0b98e26874f/Firework_Video_V7.ism/manifest",
    PowerAppLink: "",

    /*
    Please follow below note before added any configurable variables
    All variables must be matching to the respective url. If url is world-map then variable will be world_map, and it has to be in small case
    */

    //All Dashboards


    //All Reports and there section names
    tax_collection_before: "#REPORT_TAX_FINANCE#",
    tax_collection_before_section : "ReportSection57e103fb1142b2cf1349",
    tax_collections_mid:"#REPORT_TAX_FINANCE#",
    tax_collections_mid_section:"ReportSection3cbd5f7634568ebd6571",
    vat_lookup_before:"#AMAZON_MAP#",
    vat_lookup_before_section:"ReportSection0f9c62367392a4095d26",
    tax_collections_mid_wlookup:"#REPORT_TAX_FINANCE#",
    tax_collections_mid_wlookup_section:"ReportSection3cbd5f7634568ebd6571",
    vat_lookup_before1:"#AMAZON_MAP#",
    vat_lookup_before1_section:"ReportSection0f9c62367392a4095d26",
    tax_compliance_before:"#TAX_COMPLIANCE_COMISSIONER_REPORT#",
    tax_compliance_before_section:"ReportSectionaee65aedc8efa5fe7090",
    fraud_investigator_before:"#FRAUD_INVESTIGATOR_REPORT#",
    fraud_investigator_before_section:"ReportSection2f2cab987319f83177b7",
    tax_auditor_before:"#VAT_AUDITOR_REPORT#",
    tax_auditor_before_section:"ReportSection50ab0173c347ab87adc4",
    tax_auditor_after:"#VAT_AUDITOR_REPORT#",
    tax_auditor_after_section:"ReportSectionf55f602aa3c27c446106",
    fraud_investigator_after:"#FRAUD_INVESTIGATOR_REPORT#",
    fraud_investigator_after_section:"ReportSectionca9e87ce431645cd2200",
    anti_corruption_unit_before:"#ANTI_CORRUPTION_REPORT#",
    anti_corruption_unit_before_section:"ReportSection3e322a75ea7d8c573f4f",
    anti_corruption_unit_after:"#ANTI_CORRUPTION_REPORT#",
    anti_corruption_unit_after_section:"ReportSection7ed629d2a5afdc3d8473",
    tax_compliance_after:"#TAX_COMPLIANCE_COMISSIONER_REPORT#",
    tax_compliance_after_section:"ReportSection3e322a75ea7d8c573f4f",
    power_app_report:"6680c085-3c95-4e7e-bc07-b2dbe8016476",
    power_app_report_section:"ReportSection"
}
