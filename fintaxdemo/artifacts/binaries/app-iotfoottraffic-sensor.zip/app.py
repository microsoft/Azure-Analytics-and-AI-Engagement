from flask import Flask
from BeforeAndAfterScenarioGroupCEORealtime import generateData
from IoTSimulator import main
from BeforeScenario_FinanceHeadAndChiefRiskRealtime import generateDataForBeforeScenarioFinanceHeadAndChiefRisk
from AfterScenario_FinanceHeadAndChiefRiskRealtime import generateDataForAfterScenarioFinanceHeadAndChiefRisk
from BeforeScenarioCCORealtime import generateDataForBeforeScenarioCCO


import threading
import asyncio

def callIoMTSimulator():
    asyncio.run(main())


app = Flask(__name__)

t1 = threading.Thread(target=callIoMTSimulator)
# t2 = threading.Thread(target=generateData)
# t3 = threading.Thread(target=generateDataForBeforeScenarioFinanceHeadAndChiefRisk)
# t4 = threading.Thread(target=generateDataForAfterScenarioFinanceHeadAndChiefRisk)
# t5 = threading.Thread(target=generateDataForBeforeScenarioCCO)

t1.start()
# t2.start()
# t3.start()
# t4.start()
# t5.start()

if __name__ == '__main__':
    app.run()


