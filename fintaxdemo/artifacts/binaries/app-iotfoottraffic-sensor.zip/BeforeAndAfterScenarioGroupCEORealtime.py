import json
import random
import time
import requests, datetime
import os

def generateData():

    configs = json.loads(os.getenv("BeforeAndAfterScenarioGroupCEORealtimeConfigs"))
    sleep_seconds = configs['main_data_frequency_seconds']
    url = configs['urlString']
    print(url)
    data = configs['data']
    
    toConvertFloatKeys = set()
    payload = {}
    IncDecFlag = False
    while True:
        payload["RecordedOn"] = str(datetime.datetime.utcnow())
        for index in range(len(data)):
            for key in data[index]:

                if 'Behaviour' in data[index][key]:
                
                    if data[index][key]["Behaviour"] == 'increament':
                        if key in payload.keys() and payload[key] < data[index][key]["maxValue"]:
                            currVal = round(payload[key] + data[index][key]["SpikeValue"],3)
                        else:
                            currVal = data[index][key]["minValue"]
                
                    elif data[index][key]['Behaviour'] == 'increament-decreament':
                        if key in payload.keys() :
                            if not bool(data[index][key]['Flag']) :
                                randomIncreamentValue = random.uniform(data[index][key]["randomMin"],data[index][key]["randomMax"])
                                currVal = round(payload[key] + (data[index][key]["SpikeValue"]*randomIncreamentValue),3)
                                
                                if "relatableTo" in data[index][key].keys() :
                                    relatableData = data[index][key]["relatableTo"]
                                    for refIndex in range(len(relatableData)):
                                        for refKey in relatableData[refIndex]:
                                            payload[refKey] = round(payload[refKey] + (relatableData[refIndex][refKey]["SpikeValue"]*randomIncreamentValue),3)
                                        
                                
                                if currVal >= data[index][key]["maxValue"]:
                                    data[index][key]['Flag'] = int(True)
                                    currVal = data[index][key]["maxValue"]
                                    if "relatableTo" in data[index][key].keys() :
                                        relatableData = data[index][key]["relatableTo"]
                                        for refIndex in range(len(relatableData)):
                                            for refKey in relatableData[refIndex]:
                                                payload[refKey] = relatableData[refIndex][refKey]["maxValue"]
                                
                                                    
                            else :
                                randomDecreamentValue = random.uniform(data[index][key]["randomMin"],data[index][key]["randomMax"])
                                currVal = round(payload[key] - (data[index][key]["ReleaseValue"]*randomDecreamentValue),3)
                                # currVal = round(payload[key] - data[index][key]["ReleaseValue"],3)
                                if "relatableTo" in data[index][key].keys() :
                                    relatableData = data[index][key]["relatableTo"]
                                    for refIndex in range(len(relatableData)):
                                        for refKey in relatableData[refIndex]:
                                            payload[refKey] = round(payload[refKey] - (relatableData[refIndex][refKey]["ReleaseValue"]*randomDecreamentValue),3)
                                            # payload[refKey] = round(payload[refKey] - relatableData[refIndex][refKey]["ReleaseValue"],3)
                                            if "SmallerNumber" == relatableData[refIndex][refKey]["relationship"]:
                                                if payload[refKey] > currVal:
                                                    # print("Relationship broken between ",key," -> ",refKey, "with value ",payload[refKey])
                                                    currVal = round(payload[key] + payload[key]*random.uniform(0.01,0.02),3)
                                                    # print("Relationship restored between ",key," -> ",refKey, "with value ",payload[refKey])

                                if currVal <= data[index][key]["minValue"]:
                                    data[index][key]['Flag'] = int(False)                    
                                    currVal = data[index][key]["minValue"]
                                    if "relatableTo" in data[index][key].keys() :
                                        relatableData = data[index][key]["relatableTo"]
                                        for refIndex in range(len(relatableData)):
                                            for refKey in relatableData[refIndex]:
                                                payload[refKey] = relatableData[refIndex][refKey]["minValue"]
                                    
                                                    
                        else:
                            currVal = data[index][key]["minValue"]
                            if "relatableTo" in data[index][key].keys() :
                                        relatableData = data[index][key]["relatableTo"]
                                        for refIndex in range(len(relatableData)):
                                            for refKey in relatableData[refIndex]:
                                                payload[refKey] = relatableData[refIndex][refKey]["minValue"]

                elif type(data[index][key]["minValue"]) == int:
                    currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                
                elif type(data[index][key]["minValue"]) == float:
                    currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                
                else:
                    currVal = random.choice(data[index][key]['minValue'])
                
                payload[key]=currVal
        
        payload["CSAT"]=str(payload["CSAT"]) + ' / 5'
        print(payload)
        mainPayloadStr = json.dumps([payload])
        try:
            x = requests.post(url, data=mainPayloadStr)
            print(x.text)
            x.close()
            print()
        except Exception as e:
            print(e)
        time.sleep(sleep_seconds)  
