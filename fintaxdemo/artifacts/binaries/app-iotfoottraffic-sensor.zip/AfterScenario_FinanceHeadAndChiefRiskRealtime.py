import json
import random
import time
import requests, datetime
import os

def generateDataForAfterScenarioFinanceHeadAndChiefRisk():
    
    configs = json.loads(os.getenv("AfterScenarioFinancialHeadAndChiefRislRealtimeConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    url = configs['urlString']
    data = configs['data']

    toConvertFloatKeys = set()
    payload = {}
    while True:
        payload["RecordedOn"] = str(datetime.datetime.utcnow())
        for index in range(len(data)):
            for key in data[index]:
                if 'Behaviour' in data[index][key]:
                    if data[index][key]["Behaviour"] == 'increament':
                        if key in payload.keys() and payload[key] < data[index][key]["maxValue"]:
                                currVal = int(payload[key] + data[index][key]["SpikeValue"])
                        else:
                            currVal = data[index][key]["minValue"]
                if type(data[index][key]["minValue"]) == int:
                    currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                elif type(data[index][key]["minValue"]) == float:
                    currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                else:
                    currVal = random.choice(data[index][key]['minValue'])
                payload[key]=currVal
        payload['KYCScreenAlertRate'] = str(payload['KYCAlertinSanctions']) + ' / ' + str(payload['KYCAlertinPEP']) + ' / ' + str(payload['KYCAlertinMedia'])
        print(payload)

        mainPayloadStr = json.dumps([payload])
        try:
            x = requests.post(url, data=mainPayloadStr)
            print(x.text)
            x.close()
            print()
        except Exception as e:
            print(e)
        time.sleep(sleep_seconds)  


