import asyncio
import json
import os
from datetime import datetime
import random 
import time
from azure.eventhub import EventHubProducerClient, EventData

async def fintaxEventhub():
    configs = json.loads(os.getenv("fintaxEventhubReportConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    data = configs['data']
    connection_str = configs["urlStringEventhub"]
    eventhub_name = configs["EventhubName"]
    client = EventHubProducerClient.from_connection_string(connection_str, eventhub_name=eventhub_name)
    payload = {}
    with client:
        while True:
            # Create a batch.
            event_data_batch =  client.create_batch()
            payload["RecordedOn"] = str(datetime.utcnow())
            for index in range(len(data)):
                for key in data[index]:
                    # if(counter == 0 or (counter!=0 and (key in key_list))):
                    if type(data[index][key]["minValue"]) == int:
                        currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                        
                    elif type(data[index][key]["minValue"]) == float:
                        currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                    else:
                        currVal = random.choice(data[index][key]['minValue'])
                    payload[key]=currVal
                    # else:
                    #     continue       
            print(payload)
            mainPayloadStr = json.dumps(payload)
            # Add events to the batch.
            event_data_batch.add(EventData(mainPayloadStr))

            # Send the batch of events to the event hub.
            # print(event_data_batch.size_in_bytes)
            try:
                client.send_batch(event_data_batch)
            except Exception as e:
                print(e)
            await asyncio.sleep(sleep_seconds)


