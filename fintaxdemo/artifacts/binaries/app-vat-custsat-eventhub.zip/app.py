from flask import Flask
from fintaxEventhub import fintaxEventhub

import threading
import asyncio


def callE():
    asyncio.run(fintaxEventhub())
    
app = Flask(__name__)


t1 = threading.Thread(target=callE)


t1.start()

if __name__ == '__main__':
    app.run()


