const translator_key = "b68c849dec2e471ba71ebaca96a1541d";

module.exports = {
    translator_key: translator_key
};