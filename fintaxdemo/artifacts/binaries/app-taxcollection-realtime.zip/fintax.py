import json
import random
import time
import requests
from datetime import datetime,timedelta
import os


def fintax():
    configs = json.loads(os.getenv("fintaxReportsConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    url = configs['urlStringPowerBI']
    print(url)
    data = configs['data']
    #key_list = ['RecordedOn','TaxPayerSatisfactionBefore', 'TaxPayerSatisfactionMid', 'TaxPayerSatisfactionAfter', 'TaxpayersBefore', 'TaxpayersMid', 'TaxpayersAfter', 'VATMax', 'VATTargetBefore', 'VATTargetMid', 'VATTargetAfter', 'TaxpayersTargetBefore', 'TaxpayersTargetMid', 'TaxpayersTargetAfter', 'TaxPayerSatisfactionTarget', 'TaxPayerSatisfactionMax']
    #key_list = ["TaxPayerSatisfactionBefore","TaxPayerSatisfactionMid","TaxPayerSatisfactionAfter"]
    #key_list = ["TaxPayerSatisfactionBefore","TaxPayerSatisfactionMid","TaxPayerSatisfactionAfter","TaxpayersBefore","TaxpayersMid","TaxpayersAfter"]
    payload = {}
    #counter = 0
    while True:
        payload["RecordedOn"] = str(datetime.utcnow())
        for index in range(len(data)):
            for key in data[index]:
                # if(counter == 0 or (counter!=0 and (key in key_list))):
                if type(data[index][key]["minValue"]) == int:
                    currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                    
                elif type(data[index][key]["minValue"]) == float:
                    currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                else:
                    currVal = random.choice(data[index][key]['minValue'])
                payload[key]=currVal
                # else:
                #     continue       
        print(payload)
        
        # counter += 1
        # counter %= 5
        mainPayloadStr = json.dumps([payload])
        try:
            x = requests.post(url, data=mainPayloadStr)
            print(x.text)
            x.close()
            print()
        except Exception as e:
            print(e)
        time.sleep(sleep_seconds)