
import random
import datetime
import json, time
import asyncio
import os
from azure.iot.device.aio import IoTHubDeviceClient
from azure.iot.device import Message


device_client = None

async def initializeIoTHubConnection(connection):
    global device_client

    device_client = None

    device_client = IoTHubDeviceClient.create_from_connection_string(connection['IoTHubConnectionString'])

    await device_client.connect()

async def sendDataToIoTHub(data):
    global device_client
    msg = Message(json.dumps(data))
    await device_client.send_message(msg)

async def generateData():
    
    configs = json.loads(os.getenv("IoTSimulatorConfigs"))
    sleep_seconds = configs['main_data_frequency_seconds']
    data = configs['data']
    mean_AQI_Target=configs["mean_AQI_Target"] 
    mean_PM1_Target=configs["mean_PM1_Target"]
    mean_PM10_Target=configs["mean_PM10_Target"]
    mean_PM25_Target=configs["mean_PM25_Target"]

    diff_After_Mid_AQI = configs["diff_After_Mid_AQI"]
    diff_After_Mid_PM1 = configs["diff_After_Mid_PM1"]
    diff_After_Mid_PM10 = configs["diff_After_Mid_PM10"]
    diff_After_Mid_PM25 =configs["diff_After_Mid_PM25"]

    diff_After_Before_AQI = configs["diff_After_Before_AQI"]
    diff_After_Before_PM1 = configs["diff_After_Before_PM1"]
    diff_After_Before_PM10 =configs["diff_After_Before_PM10"]
    diff_After_Before_PM25 = configs["diff_After_Before_PM25"]

    toConvertFloatKeys = set()
    payload = {}
    while True:
        payload["RecordedOn"] = str(datetime.datetime.utcnow())
        for index in range(len(data)):
            for key in data[index]:
                if type(data[index][key]["minValue"]) == int:
                    currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                else:
                    currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                payload[key]=currVal
        mean_AQI =payload["mean_AQI"]
        mean_PM1 = payload["mean_PM1"]
        mean_PM10 = payload["mean_PM10"]
        mean_PM25 = payload["mean_PM25"]
        
        payload["mean_PM25_before"] = round(mean_PM25+diff_After_Before_PM25,1) 
        payload["mean_PM1_before"]  = round(mean_PM1+diff_After_Before_PM1,1)
        payload["mean_PM10_before"] = round(mean_PM10+diff_After_Before_PM10,1)
        payload["mean_AQI_before"]  = round(mean_AQI+diff_After_Before_AQI,1)


        payload["mean_PM25_mid"] = round(mean_PM25+diff_After_Mid_PM25,1) 
        payload["mean_PM1_mid"]  = round(mean_PM1+diff_After_Mid_PM1,1)
        payload["mean_PM10_mid"] = round(mean_PM10+diff_After_Mid_PM10,1) 
        payload["mean_AQI_mid"]  = round(mean_AQI+diff_After_Mid_AQI,1) 

        payload["mean_AQI_Target"] = mean_AQI_Target  
        payload["mean_PM1_Target"] = mean_PM1_Target           
        payload["mean_PM10_Target"] = mean_PM10_Target
        payload["mean_PM25_Target"] = mean_PM25_Target
        
        print(payload)
        mainPayloadStr = json.dumps(payload)
        await sendDataToIoTHub(payload)
        time.sleep(sleep_seconds)




async def main():
    config = json.loads(os.getenv("IoTHubConfig"))
    connection = config["connection"]
    #Statement to send data to IoT Hub
    await initializeIoTHubConnection(connection)
    await generateData()



