window.environment = {
  SPEECH_KEY: "#SPEECH_SERVICE_KEY#",
  SPEECH_REGION: "#REGION#",
  BlobBaseUrl: "https://#STORAGE_ACCOUNT_NAME#.blob.core.windows.net/sustainability",
  IconBlobBaseUrl:
    "https://#STORAGE_ACCOUNT_NAME#.blob.core.windows.net/sustainability/left-nav-icons",

  //   APIUrl: "https://app-common-powerbi-server.azurewebsites.net",
  APIUrl: "https://#SERVER_NAME#.azurewebsites.net",

  WorkspaceID: "#WORKSPACE_ID#",

  WorldMapReportID: "#01_World Map KPIs Sustainability#",
  WorldMapReportSectionName: "ReportSection4c536d8414c082fc5c49",

  CEODashboardBeforeReportID: "#15_Group CEO KPI#",
  CEODashboardBeforeReportSectionName: "ReportSection5f752c6bde03670c8284",

  CEODashboardBeforeID: "",

  ProjectPlanReportID: "#03_Carbon Emission Assessment Plan#",
  ProjectPlanReportSectionName: "ReportSectionbbeaf503902e69bb5611",

  FacilityManagementBeforeDashboardID: "",

  SalesDemandReportID: "#05_Sales Demand and Greenhouse Gas Emissions Report#",
  SalesDemandReportSectionName: "ReportSectionae2997831bfa33b8ebcc",

  FacilityManagementDeepDiveReportID: "#06_Transport Deep Dive#",
  FacilityManagementDeepDiveReportSectionName:
    "ReportSection35deda360748c0a02bd7",

  FacilityManagementAfterDashboardID: "",

  WasteESGContosoReportID: "#08_ESG Waste Contoso#",
  WasteESGContosoReportSectionName: "ReportSection",

  WasteESGLitwareReportID: "#20_ESGWaste_Litware#",
  WasteESGLitwareReportSectionName: "ReportSection",

  WasteESGAfterAcquisitionReportID: "#09_ESG Waste Litware Acquisition#",
  WasteESGAfterAcquisitionReportSectionName: "ReportSection",

  WasteESGReportID: "#10_ESG Water Litware#",
  WasteESGReportSectionName: "ReportSectionc5e8ac3526a9f4e3547f",

  SocialGovernanceReportID: "#11_Social & Governance Training#",
  SocialGovernanceReportSectionName: "ReportSection",

  WorkforceHealthSafetyReportID: "#12_Workforce Health & Safety#",
  WorkforceHealthSafetyReportSectionName: "ReportSection",

  MCFSReportID: "#05_Sales Demand and Greenhouse Gas Emissions Report#",
  MCFSReportSectionName: "ReportSectione5a3676a84dc85ead454",

  CO2EmissionForecastingReportID: "#13_Co2 Emissions Forecast#",
  CO2EmissionForecastingReportSectionName: "ReportSection",

  CEODashboardAfterReportID: "#15_Group CEO KPI#",
  CEODashboardAfterReportSectionName: "ReportSection68cb8066934630a72b53",

  CEODashboardAfterID: "",

  pdfUploadApi: "",
  florenceAdApi: "",
  florenceDallEApi: "",
  dalleRegenerateAPI: "",
  summarizeConversationAPI: "",
  summarizeConversationAPIKey: "",
  endPointURL: "",
  index: "",
  container: "",
};
