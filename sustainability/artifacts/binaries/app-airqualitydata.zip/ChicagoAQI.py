
import json
import time
import requests
from datetime import datetime
import pandas as pd
import os
import random



def ChicagoAQI():
    configs = json.loads(os.getenv("ChicagoAQIReportsConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    url = configs['urlStringPowerBI']
    data = configs["data"]
    mean_AQI_Target=configs["mean_AQI_Target"] 
    mean_PM1_Target=configs["mean_PM1_Target"]
    mean_PM10_Target=configs["mean_PM10_Target"]
    mean_PM25_Target=configs["mean_PM25_Target"]

    diff_After_Mid_AQI = configs["diff_After_Mid_AQI"]
    diff_After_Mid_PM1 = configs["diff_After_Mid_PM1"]
    diff_After_Mid_PM10 = configs["diff_After_Mid_PM10"]
    diff_After_Mid_PM25 =configs["diff_After_Mid_PM25"]

    diff_After_Before_AQI = configs["diff_After_Before_AQI"]
    diff_After_Before_PM1 = configs["diff_After_Before_PM1"]
    diff_After_Before_PM10 =configs["diff_After_Before_PM10"]
    diff_After_Before_PM25 = configs["diff_After_Before_PM25"]


    while True:
        # beginDateTime  = (datetime.utcnow() - timedelta(minutes= 5)).strftime('%d-%m-%Y %H:%M:%S')
        # endDateTime  =  datetime.utcnow().strftime('%d-%m-%Y %H:%M:%S')
        # beginDateTime = beginDateTime.replace(" ","%20")
        # endDateTime = endDateTime.replace(" ","%20")
        
        # Pull the data with the help of API
        try:
            

            #x = requests.get(f'https://eclipseprowebapi.azurewebsites.net/EclipseData/GetReadings?CustomerName=Chicago&BeginDateTime={beginDateTime}&EndDateTime={endDateTime}')
            # x = requests.get(f'https://eclipseprowebapi.azurewebsites.net/EclipseData/GetLatestReadings?CustomerName=Chicago')
           
            # # Load the JSON request
            # #print(x)
            # json_obj = json.loads(x.text)
            # values = ['Good', 'Moderate', 'Unhealthy for Sensitive Groups', 'Unhealthy', 'Very Unhealthy', 'Hazardous' ]
            
            # # Create a dataframe from a JSON object
            # df = pd.DataFrame(json_obj)
            payload = {}
            for index in range(len(data)):
                for key in data[index]:
                    # if(counter == 0 or (counter!=0 and (key in key_list))):
                    if type(data[index][key]["minValue"]) == int:
                        currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                        
                    elif type(data[index][key]["minValue"]) == float:
                        currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                    else:
                        currVal = random.choice(data[index][key]['minValue'])
                    payload[key]=currVal
                       
            
            mean_AQI =payload["mean_AQI"]
            mean_PM1 = payload["mean_PM1"]
            mean_PM10 = payload["mean_PM10"]
            mean_PM25 = payload["mean_PM25"]
            
            payload["mean_PM25_before"] = round(mean_PM25+diff_After_Before_PM25,1) 
            payload["mean_PM1_before"]  = round(mean_PM1+diff_After_Before_PM1,1)
            payload["mean_PM10_before"] = round(mean_PM10+diff_After_Before_PM10,1)
            payload["mean_AQI_before"]  = round(mean_AQI+diff_After_Before_AQI,1)


            payload["mean_PM25_mid"] = round(mean_PM25+diff_After_Mid_PM25,1) 
            payload["mean_PM1_mid"]  = round(mean_PM1+diff_After_Mid_PM1,1)
            payload["mean_PM10_mid"] = round(mean_PM10+diff_After_Mid_PM10,1) 
            payload["mean_AQI_mid"]  = round(mean_AQI+diff_After_Mid_AQI,1) 

            payload["mean_AQI_Target"] = mean_AQI_Target  
            payload["mean_PM1_Target"] = mean_PM1_Target           
            payload["mean_PM10_Target"] = mean_PM10_Target
            payload["mean_PM25_Target"] = mean_PM25_Target
            payload["ReadingDateTimeUTC"] = str(datetime.utcnow())

            payload_send=json.dumps([payload])
            
        except Exception as e:
            print(e)
        
        
        print(payload)
        print()
    
        try:
            x = requests.post(url, data=payload_send)
            print(x.text)
            x.close()
            print()
        except Exception as e:
            print(e)
        time.sleep(sleep_seconds)