from flask import Flask
from ChicagoAQI import ChicagoAQI

import threading
#import asyncio


app = Flask(__name__)

t1 = threading.Thread(target=ChicagoAQI)


t1.start()

if __name__ == '__main__':
    app.run()
