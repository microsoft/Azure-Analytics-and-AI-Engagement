window["runConfig"] = {
  BlobBaseUrl:
    "https://dreamdemoassets.blob.core.windows.net/sustainability/images/",
  ArrowBlobBaseUrl:
    "https://dreamdemoassets.blob.core.windows.net/sustainability/arrows/",
  // IconBlobBaseUrl: "https://stcriticalinfradev.blob.core.windows.net/webappassets/left-nav-icons/",
  apiUrl: "https://app-sustainabilitydemo-dev.azurewebsites.net",
  //apiUrl: "https://localhost:5001",
  PAGE_ID_DASHBOARD: "36ee260a-bd01-4d65-b506-c2a7269c2a44",

  PageID_Twitter: "d9c4bb0b-317c-4a82-a882-87165b35e27f",
  TwitterReportSectionName: "ReportSection",

  CEO_BEFORE_DASHBOARD_ID: "6252c7ed-50b7-45bf-800a-569caf5923e9",
  ceo_dashboard_before_top_report_id: "460d7156-523e-4743-b4d9-0057b12dc5c2",
  ceo_dashboard_before_top_report_sectionname:
    "ReportSection5f752c6bde03670c8284",
  ceo_dashboard_after_id: "ebb3bb23-a4b9-42b2-980f-9dd78aa39d39",
  // PAGE_ID: "5e83e2f6-aac6-4bd4-a1eb-debaec14e261",

  CampaignAnalyticDeepDiveReportId: "5e83e2f6-aac6-4bd4-a1eb-debaec14e261",
  CampaignAnalyticDeepDiveReportSectionName:
    "ReportSectionf2c099731dcd88ec8a6c",

  CampaignReportIdOld: "e28d7c71-ea92-4d2d-bd2e-30f83bcdf386",
  CampaignReportOldSectionName: "ReportSection92fdb1cb740d8014a463",

  CampaignAnylicsAfterReportId: "e28d7c71-ea92-4d2d-bd2e-30f83bcdf386",
  CampaignAnylicsAfterReportSectionName: "ReportSection6b516ade5e3ee314d089",

  RetailstoreReportId: "4724e4c2-0120-407a-a0f6-99c07d9444f6",
  RetailstoreReportSectionName: "ReportSection",

  ADXHistoricalReportId: "6b2766d1-c3da-4311-b090-5e47758d4a36",
  ADXHistoricalReportSectionName: "ReportSection7d104fc7e0cb69ca682b",

  ADXDirectReportId: "3f623655-f789-48bb-8089-a6680f847fca",
  ADXDirectReportSectionName: "ReportSectionb4cd1d334fe3b8497487",

  EamilAnalyticReportId: "4b9de275-01ec-404e-9c32-bac43d9fa728",
  EmailAnalyticReportSectionName: "ReportSection",

  WebSocialAnalyticReportId: "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
  WebSocialAnalyticReportSectionName: "ReportSection",

  RevenueBeforeReportId: "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
  RevenueBeforeReportSectionName: "ReportSection2493b5daafc4c9fc6116",

  RevenueAfterReportId: "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
  RevenueAfterReportSectionName: "ReportSection3fa1a88d36674bc10f9d",

  DecompReportId: "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
  DecompReportSectionName: "ReportSection8ad0b724a0cf2f7eaca4",

  ProductRecReportId: "84eaf34a-8293-41fa-839e-977285e3018f",
  ProductRecReportSectionName: "ReportSectionb1db078f436c6df90c30",

  // POWERAPPS_LINK: "https://apps.powerapps.com/play/630d6be7-0070-48eb-8b27-8bab33c761d5?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
  POWERAPPS_LINK:
    "https://apps.powerapps.com/play/78ceff4d-9881-4840-850f-87fa72db763a?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
  USMapReportId: "dad799a7-e156-45cc-9c7e-08d72c444792",
  USMapReportSectionName: "ReportSectione100aa1269c2d9800002",

  FinancialPlanningDashboardId: "68cfe577-58a9-425f-9286-e991b5665030",

  RevenueAndProfitReportId: "14f547a7-111b-4878-a3ab-2d47bc430a3f",
  RevenueSectionName: "ReportSection5",

  PredictiveAnatyticsReportId: "54f429fc-1538-4c61-b85a-ea3271ee6f68",
  PredictiveAnatyticsReportSectionName: "ReportSection01004f62b9c010350168",

  CustomerSegmentationReportId: "a2599faa-bc02-487c-afe8-58321bee1209",
  CustomerSegmentationReportSectionName: "ReportSection8fc595c6c425617404c2",

  CCODashboardBeforeID: "c25a4237-2bff-4ba0-9ecd-60971fa09ec7",
  search_app_url: "https://purple-grass-07d210d1e.azurestaticapps.net",
  agolo_searchapp_url: "https://fsisearchapp.azurewebsites.net/",
  agolo_searchapp_fred_url:
    "https://app-retailedgarsearch-dev001.azurewebsites.net/#/searchforfred",
  ceo_dashboard_mid_id: "c1a72671-03d3-4129-8f26-062b9eb424df",

  AcquisitionReportId: "36f8fad5-2e79-4656-b76b-4ed3128747aa",
  AcquisitionReportSectionName: "ReportSectiond2bfd6ee84e5d52c5aa9",

  AcquisitionAfterDashboardId: "ebb3bb23-a4b9-42b2-980f-9dd78aa39d39",

  PostAcquisitionReportId: "36f8fad5-2e79-4656-b76b-4ed3128747aa",
  PostAcquisitionReportSectionName: "ReportSection20dfb8c36bac84c37b61",

  ceo_dashboard_mid_top_report_id: "460d7156-523e-4743-b4d9-0057b12dc5c2",
  ceo_dashboard_mid_top_report_sectionname: "ReportSectionfd6f0d440865b0c1da0a",

  nov_dashboard_top_report_id: "460d7156-523e-4743-b4d9-0057b12dc5c2",
  nov_dashboard_top_report_sectionname: "ReportSection26246a2310d36c4d0ece",

  dec_dashboard_top_report_id: "460d7156-523e-4743-b4d9-0057b12dc5c2",
  dec_dashboard_top_report_sectionname: "ReportSection68cb8066934630a72b53",

  ceo_dashboard_after_top_report_id: "460d7156-523e-4743-b4d9-0057b12dc5c2",
  ceo_dashboard_after_top_report_sectionname:
    "ReportSectiona691f7ffd10928c0e108",

  search_spencer_url:
    "https://retail-mediasearch-app-dev.azurewebsites.net/#/search-spencer",
  search_reta_url:
    "https://retail-mediasearch-app-dev.azurewebsites.net/#/search-reta",
  search_ryan_url:
    "https://retail-mediasearch-app-dev.azurewebsites.net/#/search-ryan",

  NOVDashboardID: "adeeb11b-d834-4a26-98a7-1a8a6d0cbcfc",

  LocationAnatyticsReportId: "883f295c-d53d-4362-b3e7-42985df16a86",
  LocationAnatyticsReportSectionName: "ReportSection2",

  ai_search_url:
    "https://purple-grass-07d210d1e.azurestaticapps.net/search?q=drass",
  chat_bot_url:
    "https://webchat.botframework.com/embed/RetailBotv01/gemini?b=RetailBotv01&s=O-mEiqPttxE.Hkmh1X8ShHDpf0Kfd1taQf4DlrS7lB9iXDbtRXCdJnc&username=You",

  AfterDashboardDec: "14987a97-b733-464a-99e1-bd5dd3082121",

  IncidentReportID: "ba65e430-0e78-4a30-b595-ca6b3fc8da4d",
  IncidentReportSectionName: "ReportSection1ee1dbf5b8dc07148713",

  PDFBaseLink: "https://stretailprod.blob.core.windows.net/incident-search/",

  IncidentSearchUrl:
    "https://stretailprod.blob.core.windows.net/incident-search/search.html",

  PDFBaseInvoiceLink: "https://stretailprod.blob.core.windows.net/idcard/",

  AIBuilderPowerApp_Link:
    "https://apps.powerapps.com/play/ba0a135b-c09f-4006-a8f8-bf721297ade1?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",

  TeaserVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/ffc1c8c3-d711-4814-b791-5c4de21951fc/Sustainability_DreamVideo_V04.ism/manifest",
  RetailStoreVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/b88e73b0-71f0-4897-8165-c94ba3f46d09/Retail_Store_Video_V19.ism/manifest",
  FinalVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/ef356f7f-79c5-4e92-901d-a82207123ee7/Sustainability_Finale_V18.ism/manifest",

  ADXDirectDashboardId: "7086ca7a-0aaf-48ad-9b0a-1dc16cc14a06",

  ADXDirectDashboard2Id: "c6ad3d58-9718-4dd3-bf70-a519d01dbae8",

  ADXDirectDashboardReport3Id: "6b2766d1-c3da-4311-b090-5e47758d4a36",
  ADXDirectDashboardReport3SectionName: "ReportSection6efc74dccd4775687467",

  CityMapReportId: "cefe38f4-3d82-4399-8a15-1433408b70ca",
  CityMapReportSectionName: "ReportSectionf9faaa1180b790051a02",
  MidDashboardId: "e5d82457-1797-4eb2-bcbd-3704afd46c31",
  MayorDashboardBeforeID: "fa7e0dfd-9720-49fe-9239-bede1b08ceb0",

  AfterDashboardId: "9eefb0bc-ec7f-4f60-9f29-40671ef08310",
  ESGDashboardID: "50d1b69e-5d44-4d3f-b7d8-af77376520a5",

  ESGSynapsReportID: "5260c2bf-7375-4345-9034-1b26035d5dfb",
  ESGSynapsReportSectionname: "ReportSectioncfca52084a74580356b0",

  ESGMatrixReportID: "cd782520-70b1-491c-9a71-d3550821d79d",
  ESGMatrixReportSectionname: "ReportSection9d6eb777813b36c4d",

  PredictionApiForUrl:
    "https://customvisionaidreamdemo-prediction.cognitiveservices.azure.com/customvision/v3.0/Prediction/97c96b4d-8383-48f3-97a4-7a127f7ea7eb/classify/iterations/Bird-Species-Recognization/url",
  PredictionApiForImage:
    "https://customvisionaidreamdemo-prediction.cognitiveservices.azure.com/customvision/v3.0/Prediction/97c96b4d-8383-48f3-97a4-7a127f7ea7eb/classify/iterations/iteration-2%20with%20104%20species/image",
  PredictionKey: "e66746f001c5447ebb8c98cb124a4192",
  ContentTypeForUrl: "application/json",
  ContentTypeForImage: "application/octet-stream",

  BirdRecognitionReportId: "f6afe497-3a83-47e0-a302-6b22825ad9c0",
  BirdRecognitionReportSectionname: "ReportSection160938048145c9eb44b5",

  PowerManagementBeforeDashboardID: "a0c85c63-0cbe-40dc-9d5f-4ec18b0d388c",
  FleetManagementM6DashboardID: "b2c99369-c668-4960-b1cc-287cde24f8d5",

  FleetManagementM6ReportID: "66bf3700-5743-4153-bddc-8c4f9fd52403",
  FleetManagementM6ReportSectionname: "ReportSection0c5bbe8a2205d2870d9b",

  TransportationHeadDashboardM6ID: "db1c86d8-d500-4418-80c0-d632570591c1",
  TransportationHeadDashboardM24ID: "fb4b18ac-f516-4dcd-8622-1aa7740b5a32",

  FleetManagementM18DashboardID: "8e7ac2a6-974e-4146-a249-5962d3f8975f",
  FleetManagementM12ReportID: "66bf3700-5743-4153-bddc-8c4f9fd52403",
  FleetManagementM12ReportSectionname: "ReportSectionaffd300e14a301bd8900",

  CityMapM12ReportID: "cefe38f4-3d82-4399-8a15-1433408b70ca",
  CityMapM12ReportSectionName: "ReportSection98c0d9ab928506c4e0e2",

  PowerManagementAfterDashboardID: "c9279794-e58c-4053-b5fc-6a04a069adf0",
  MayorDashboardM18ID: "",
  MayorDashboardM24ID: "3f887317-d968-42c8-a76a-7d406da56f80",

  CityMapM24ReportID: "cefe38f4-3d82-4399-8a15-1433408b70ca",
  CityMapM24ReportSectionName: "ReportSection0491f4103c2370474a64",

  RevenueCostAnalysisM3ReportID: "23b15b8a-4e17-4083-b78b-d207d0a60224",
  RevenueCostAnalysisM3Sectionname: "ReportSection0c5bbe8a2205d2870d9b",
  RevenueCostAnalysisM24ReportID: "23b15b8a-4e17-4083-b78b-d207d0a60224",
  RevenueCostAnalysisM24Sectionname: "ReportSection5e69cc0dc108eb2a8726",

  TransportationDeepDiveReportID: "3e465146-c3ef-418f-97e1-080a975cdfba",
  TransportationDeepDiveReportSectionName: "ReportSection050f7644bf1b15a6369e",

  PowerManagementDeepDiveReportID: "3e465146-c3ef-418f-97e1-080a975cdfba",
  PowerManagementDeepDiveReportSectionName: "ReportSectiona9713acb7b17073ac33d",

  FleetDeepDiveReportID: "3e465146-c3ef-418f-97e1-080a975cdfba",
  FleetDeepDiveReportSectionName: "ReportSectione572dee1e38af4978227",

  TransportationDeepDiveAfterReportID: "3e465146-c3ef-418f-97e1-080a975cdfba",
  TransportationDeepDiveAfterReportSectionName:
    "ReportSection07be473882bf8580e5c7",

  PowerManagementDeepDiveAfterReportID: "3e465146-c3ef-418f-97e1-080a975cdfba",
  PowerManagementDeepDiveAfterReportSectionName:
    "ReportSection35deda360748c0a02bd7",

  FleetDeepDiveAfterReportID: "3e465146-c3ef-418f-97e1-080a975cdfba",
  FleetDeepDiveAfterReportSectionName: "ReportSection291040d111d0a96e37a2",

  with_htap_report: "1b122ab7-6a81-4b4b-bd91-4cf34e1bd1f1",
  with_htap_report_section: "ReportSection4adf334dde371401d096",

  without_htap_report: "1b122ab7-6a81-4b4b-bd91-4cf34e1bd1f1",
  without_htap_report_section: "ReportSectionad843fcd88a1bad59953",
};
