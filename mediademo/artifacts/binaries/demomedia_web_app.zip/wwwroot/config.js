window['runConfig'] = {
    BlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/",
    MediaDashboardId : "ce63372d-053a-4c0a-9176-a2ef00030763",
    AfterMediaDashboardId: "b4f6526e-a0ea-46dc-b7ed-5964da4be616",
    MediaKeywordReportId : "#MEDIA_KEYWORD_REPORT#",
    MediaKeywordReportSectionName : "ReportSection",
    MediaBrandReportId : "#MEDIA_BRAND_REPORT#",
    MediaBrandReportSectionName : "ReportSection87278b318ca8f3e657f2",
    MediaTwitterReportId:"#TWITTER_REPORT#",
    RevenueDashboardId:"65896ad1-a6c5-40c4-8779-e2898c1cc06c",
    RevenueReportId : "#REVENUE_REPORT#",
    RevenueReportSectionName : "ReportSection5",
    RealtimeAnalyticsReportId : "#REALTIME_ANALYTICS_REPORT#",
    RealtimeAnalyticsReportSectionName : "ReportSectionae493ed8d7c2b9e96837",

    // Used in app/pages/ecommerce
    ecommercIframeSrc: "https://stmediademo.blob.core.windows.net/webappassets/hospital.html",

    // Use in app/pages/PowerApps
    powerAppsSrc: "https://apps.powerapps.com/play/0e2f8720-20aa-4228-8095-5cb51ccb46b8?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a&source=portal&screenColor=rgba(76%2C%2074%2C%2072%2C%201)",

    apiUrl: "https://#SERVER_NAME#.azurewebsites.net",
    apiUrl2: "https://manufacturingdemopoc.azurewebsites.net",
    MediaSearchApp:"https://#SEARCH_APP_NAME#.azurewebsites.net/",
    Search_Spencer: "#/search-spencer",
    Search_Ryan: "#/search-ryan",
    Search_Reta: "#/search-reta",
    
}