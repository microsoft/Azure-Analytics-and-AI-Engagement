import logging
from azure.storage.blob import BlobClient,ContainerClient
import azure.functions as func
import nltk
from nltk.corpus import stopwords
import string
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import find
from sklearn.metrics.pairwise import cosine_similarity
import json
import pandas as pd
from io import BytesIO
import os

def main(myblob: func.InputStream):
    CONTAINERNAME = os.environ["CONTAINER_WITH_VIDEO_JSONS"]
    CONNECTIONSTRING=  os.environ["CONNECTIONSTRING"]
    container_client = ContainerClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME)


    js_objs= []
    
    for blob in container_client.list_blobs():

        blob_client = BlobClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME, blob_name=blob.name)
        blob_data = blob_client.download_blob()
        js_obj = json.load(BytesIO(blob_data.content_as_bytes()))
        js_objs.append(js_obj)


  
    nltk.download("stopwords")
    nltk.download('punkt')
    nltk.download('wordnet')
    raw_text = []
    ids = []
    for js in js_objs:
        transcript = js['transcript']
        words = transcript.split()
        raw_text.append(words)
        ids.append(js['video_id'])

    cleaned_text= clean_text(raw_text)
    sim_matrix =  train_model(data=cleaned_text)
    upload_csv(sim_matrix,ids)


def upload_csv(sim_matrix,ids): 
    CONNECTION_STRING = os.environ["CONNECTIONSTRING"]
    CONTAINER_NAME = os.environ["CONTAINER_WITH_MODELS"]

    container_client = ContainerClient.from_connection_string(conn_str=CONNECTION_STRING, container_name=CONTAINER_NAME)
    file_name = "similarity.csv"

    blob_client = container_client.upload_blob(name =file_name,data= pd.DataFrame(sim_matrix).to_csv(header=ids,index=False),overwrite=True)


def clean_text(text): 
    stopwords_english = stopwords.words('english')
    cleaned = text.copy()
    for i in range(len(text)): 
        cleaned[i] = [word.lower() for word in text[i]]
        cleaned[i] = [word for word in text[i] if word not in string.punctuation]
        cleaned[i] = [word for word in text[i] if word not in stopwords_english]
    cleaned = [' '.join(i) for i in cleaned]
    return cleaned


    
def tokenize(text):
    tokens = nltk.word_tokenize(text)
    stems = []
    for item in tokens:
        stems.append(nltk.PorterStemmer().stem(item))
    return stems

def train_model(data):
    tfidf = TfidfVectorizer(tokenizer=tokenize)
    video_tfidf = tfidf.fit_transform(data)
    cos_sim = cosine_similarity(video_tfidf, video_tfidf)
    return cos_sim


