import logging
from azure.storage.blob import BlobClient,BlobServiceClient,ContainerClient
import azure.functions as func
import json
import pandas as pd
from io import BytesIO
import requests
import os

def main(myblob: func.InputStream):
    CONTAINERNAME = os.environ["CONTAINER_WITH_VIDEO_JSONS"]
    CONNECTIONSTRING=  os.environ["CONNECTIONSTRING"]
    container_client = ContainerClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME)
    
    js_objs = []
    for blob in container_client.list_blobs():

        blob_client = BlobClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME, blob_name=blob.name)
        blob_data = blob_client.download_blob()
        js_obj = json.load(BytesIO(blob_data.content_as_bytes()))
        url = os.environ["VIDEO_INDEXER_URL"].format(js_obj['video_id'])
        try: 
            resp = requests.get(url)
            resp = resp.json()
            relevant_fields = ['name','id','privacyMode','duration','thumbnailVideoId','thumbnailId']
            temp_dict = {}
            for field in relevant_fields: 
                temp_dict[field] = resp['summarizedInsights'][field]
            js_obj['data'] = temp_dict    
        except:
            js_obj['data'] = {}
        js_objs.append(js_obj)
        blob_client.upload_blob(data=json.dumps(js_obj),overwrite=True)
