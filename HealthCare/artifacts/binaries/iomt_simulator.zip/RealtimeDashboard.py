import json
import random
import time
import requests, datetime

import http.client


def generateData():
    configFilename = 'config.json'
    f = open(configFilename, "r")

    configuration = json.loads(f.read())
    f.close()

    sleep_seconds = configuration["main_data_frequency(sec)"]
    url = configuration["url"]

    data = configuration["data"]

    toConvertFloatKeys = set()
    curr_time = 0
    payload = {}
    while True:
        payload["recordedOn"] = str(datetime.datetime.utcnow())
        for key in data.keys():
            if 'increment' in data[key]:
                toConvertFloatKeys.add(key)
                minVal = data[key]["minValue"]
                maxVal = data[key]["maxValue"]
                param_sleep_time = data[key]["data_frequency(sec)"]
                # minimum_increment = data[key]["minimum_increment"]
                # maximum_increment = data[key]["maximum_increment"]
                increment = data[key]["increment"]
                if curr_time % param_sleep_time == 0:
                    if key in payload:
                        payload[key] = payload[key] + increment
                        if payload[key] >= maxVal:
                            payload[key] = minVal
                    else:
                        payload[key] = minVal
            else:
                minVal = data[key]["minValue"]
                maxVal = data[key]["maxValue"]
                param_sleep_time = data[key]["data_frequency(sec)"]

                if curr_time % param_sleep_time == 0:
                    if type(minVal) == int:
                        currVal = random.randint(minVal, maxVal)
                    else:
                        currVal = round(random.uniform(minVal, maxVal), 2)

                    payload[key] = currVal

        payload["ratingPositivePercentage"] = 100 - payload["ratingNegativePercentage"] - payload["ratingNeutralPercentage"]
        payload["appointmentStats"] = str(int(payload["inPersonAppointment"])) + ' / ' + str(int(payload["virtualAppointment"])) + ' / ' + str(int(payload["missedAppointment"]))
        payload["waittimeStats"] = str(int(payload["averageERWaitingTime"])) + ' / ' + str(int(payload["currentERWaitingTime"]))
        payload["surgeriesStats"] = str(int(payload["inpatientSurgery"])) + ' / ' + str(int(payload["outpatientSurgery"]))
        payload["prescriptionStats"] = str(int(payload["inPersonPrescription"])) + ' / ' + str(int(payload["onlinePrescription"]))

        payload["currentRegularBedOccupancyRate"] = payload["currentBedOccupancyRate"] - payload["currentICUBedOccupancyRate"]

        payload['currentbedOccupancyRateStats'] = str(int(payload["currentRegularBedOccupancyRate"])) + ' / ' + str(int(payload["currentICUBedOccupancyRate"]))

        if 'activeSensors' in payload:
            payload['activeSensors'] = str(payload['activeSensors'])
        finalPayload = {}
        for key in payload.keys():
            if key in toConvertFloatKeys:
                finalPayload[key] = int(payload[key])
            else:
                finalPayload[key] = payload[key]

        mainPayload = [finalPayload]
        # if "currentBedOccupancyRate" in mainPayload:
        #     del mainPayload["currentBedOccupancyRate"]
        print(mainPayload)
        print()

        #url = 'https://api.powerbi.com/beta/f94768c8-8714-4abe-8e2d-37a64b18216a/datasets/fd3dc0ac-e138-4e4f-8f61-2b180aed5296/rows?noSignUpCheck=1&key=QgJB7ahszsFMzGauxxoQC%2BddQZwKdDw2lvlnhZA4RFHUPGEkgdk%2BOzzylGT5W3liXJR1qRbfqAIq9fYUwrBapQ%3D%3D'

        mainPayloadStr = json.dumps(mainPayload)


        try:
            x = requests.post(url, data=mainPayloadStr)
            print(x.text)
            x.close()
        except Exception as e:
            print(e)
        time.sleep(sleep_seconds)
        curr_time = curr_time + sleep_seconds