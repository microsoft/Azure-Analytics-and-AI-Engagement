import uuid
import random
import datetime
import csv, json, time
import asyncio
from azure.iot.device.aio import ProvisioningDeviceClient
import os
from azure.iot.device.aio import IoTHubDeviceClient
from azure.iot.device import Message

def createPatientIds():
    patientDict = {}
    for i in range(0, noOfPatients):
        currPatientId = str(uuid.uuid1())
        patientDict[currPatientId] = random.randint(40, 60)
    return patientDict


def generatePhaseData(currPatientId, patientAge, data):

    newData = {}
    newData["patientId"] = str(currPatientId)
    newData["patientAge"] = patientAge
    newData["datetime"] = None
    for parameter in data.keys():
        if "bodyTemperature" in parameter:
            newData[parameter] = round(random.uniform(data[parameter][0], data[parameter][1]), 1)
        else:
            newData[parameter] = random.randint(data[parameter][0], data[parameter][1])

    newData["diastolicPressure"] = int(newData["systolicPressure"] * 2.0 / 3.0)

    return newData

def generateActivityPhaseData(currPatientId, patientAge, data):

    newData = {}
    newData["patientId"] = str(currPatientId)
    newData["patientAge"] = patientAge
    newData["datetime"] = None

    for parameter in data.keys():
        newData[parameter] = random.randint(data[parameter][0], data[parameter][1])

    return newData

def generateHistoricalData(patientDict):
    f = open('configHealth.json', "r")

    config = json.loads(f.read())
    finalData = {}
    for currPatientId in patientDict.keys():
        patientAge = patientDict[currPatientId]["age"]
        healthType = patientDict[currPatientId]["healthType"]
        dataDict = generatePhaseData(currPatientId, patientAge,
                                     config[healthType])

        finalData[currPatientId] = dataDict

    #print("finalData = " + str(finalData))
    return finalData

def generateHistoricalActivityData(patientDict):
    f = open('configActivity.json', "r")

    config = json.loads(f.read())
    finalData = {}
    for currPatientId in patientDict.keys():
        patientAge = patientDict[currPatientId]["age"]
        phaseType = patientDict[currPatientId]["phaseType"]
        dataDict = generateActivityPhaseData(currPatientId, patientAge,
                                     config[phaseType])

        finalData[currPatientId] = dataDict

    return finalData


device_client_list = []

async def sendDataToIoTCentral(data, device_client):
    msg = Message(json.dumps(data))
    await device_client.send_message(msg)

async def initializeIoTCentralConnection(connection, patientDict, currPatientId):
    global device_client_list

    device_client = None

    provisioning_host = connection["provisioning_host"]
    id_scope = connection["id_scope"]
    registration_id = connection["registration_id"]
    symmetric_key = connection["symmetric_key"]

    provisioning_device_client = ProvisioningDeviceClient.create_from_symmetric_key(
        provisioning_host=provisioning_host,
        registration_id=registration_id,
        id_scope=id_scope,
        symmetric_key=symmetric_key,
    )

    registration_result = await provisioning_device_client.register()

    print("The complete registration result is")
    print(registration_result.registration_state)

    if registration_result.status == "assigned":
        print("Will send telemetry from the provisioned device")
        device_client = IoTHubDeviceClient.create_from_symmetric_key(
            symmetric_key=symmetric_key,
            hostname=registration_result.registration_state.assigned_hub,
            device_id=registration_result.registration_state.device_id,
        )
    # Connect the client.
    device_client_list.append(device_client)
    patientDict[currPatientId]["device_client"] = len(device_client_list) - 1
    await device_client_list[len(device_client_list) - 1].connect()

async def main():
    global device_client_list
    f = open('configMain.json', "r")

    config = json.loads(f.read())
    frequency = config["frequency"]

    #patientDict = {"0058a52a-235c-11eb-be74-70b5e8b8edbb": 42}
    patientDict = config["patient"]

    for currPatientId in patientDict.keys():
        connection = patientDict[currPatientId]["connection"]
        await initializeIoTCentralConnection(connection, patientDict, currPatientId)

    while True:
        healthDataDict = generateHistoricalData(patientDict)


        activityDataDict = generateHistoricalActivityData(patientDict)

        for currPatientId in healthDataDict.keys():
            dataDict = {}
            healthDataCurrDict = healthDataDict[currPatientId]
            #print(str(healthDataCurrDict))
            for parameter in healthDataCurrDict.keys():
                dataDict[parameter] = healthDataCurrDict[parameter]

            activityDataCurrDict = activityDataDict[currPatientId]
            #print(str(activityDataCurrDict))
            for parameter in activityDataCurrDict.keys():
                 dataDict[parameter] = activityDataCurrDict[parameter]

            #print(str(dataDict))


            dataDict["datetime"] = str(datetime.datetime.now())

            print(json.dumps(dataDict))
            await sendDataToIoTCentral(dataDict, device_client_list[patientDict[currPatientId]["device_client"]])

        time.sleep(frequency)


