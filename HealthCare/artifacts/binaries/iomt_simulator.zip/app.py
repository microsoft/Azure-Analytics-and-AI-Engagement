import multiprocessing
from flask import Flask
import json
import random
import time
import requests, datetime
import http.client
from IoMTSimulator import main
from RealtimeDashboard import generateData
import asyncio
import threading




def callIoMTSimulator():
    asyncio.run(main())


app = Flask(__name__)

t1 = threading.Thread(target=callIoMTSimulator)
t2 = threading.Thread(target=generateData)
t1.start()
t2.start()

if __name__ == '__main__':
    app.run()





