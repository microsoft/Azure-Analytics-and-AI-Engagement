product_search_name = "funcdreamdemodev001"
bot_url="https://webchat.botframework.com/embed/RetailBotv01/gemini?b=RetailBotv01&s=O-mEiqPttxE.Hkmh1X8ShHDpf0Kfd1taQf4DlrS7lB9iXDbtRXCdJnc&username=You"
window['runConfig'] ={"search_url":"https://${product_search_name}.azurewebsites.net/api/search",
"suggest_url":"https://${product_search_name}.azurewebsites.net/api/suggest",
"lookup_url":"https://${product_search_name}.azurewebsites.net/api/lookup",
"bot_url": bot_url
}

