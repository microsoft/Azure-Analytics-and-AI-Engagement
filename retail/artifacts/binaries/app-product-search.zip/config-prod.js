product_search_name = "#FUNCTION_PRODUCT_SEARCH#"
bot_url="https://webchat.botframework.com/embed/#BOT_NAME#/gemini?b=#BOT_NAME#&s=#BOT_KEY#&username=You"
window['runConfig'] ={"search_url":"https://${product_search_name}.azurewebsites.net/api/search",
"suggest_url":"https://${product_search_name}.azurewebsites.net/api/suggest",
"lookup_url":"https://${product_search_name}.azurewebsites.net/api/lookup",
"bot_url": bot_url
}

