window['runConfig'] = {    
    BlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/retail20/",
    IconBlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/retail20/left-nav-icons/",
    apiUrl: "https://#SERVER_NAME#.azurewebsites.net",
    MediaSearchApp:"https://#SEARCH_APP_NAME#.azurewebsites.net/",
    //apiUrl: "https://localhost:5001",
    PAGE_ID_DASHBOARD: "36ee260a-bd01-4d65-b506-c2a7269c2a44",

    PageID_Twitter: "#Twitter_Sentiment_Analytics#",
    TwitterReportSectionName: "ReportSectionec708ed167442bc760d1",

    CEO_BEFORE_DASHBOARD_ID: "",
    ceo_dashboard_before_top_report_id:"#Retail_Group_CEO_KPI#",
    ceo_dashboard_before_top_report_sectionname:"ReportSection5f752c6bde03670c8284",
    ceo_dashboard_after_id: "",
    // PAGE_ID: "5e83e2f6-aac6-4bd4-a1eb-debaec14e261",

    CampaignAnylicsAfterReportId : "#Campaign_Analytics#",
    CampaignAnylicsAfterReportSectionName : "ReportSection6b516ade5e3ee314d089",

    CampaignAnalyticDeepDiveReportId: "#Campaign_Analytics_Deep_Dive#",
    CampaignAnalyticDeepDiveReportSectionName: "ReportSectionf2c099731dcd88ec8a6c",

    CampaignReportIdOld: "#Campaign_Analytics#",
    CampaignReportOldSectionName: "ReportSection92fdb1cb740d8014a463",

    RetailstoreReportId : "4724e4c2-0120-407a-a0f6-99c07d9444f6",
    RetailstoreReportSectionName: "ReportSection",

    ADXHistoricalReportId:"#ADX_Thermostat_and_Occupancy#",
    ADXHistoricalReportSectionName:"ReportSection7d104fc7e0cb69ca682b",

    ADXDirectReportId:"#ADX_dashboard_8AM#",
    ADXDirectReportSectionName:"ReportSectionb4cd1d334fe3b8497487",

    EamilAnalyticReportId : "4b9de275-01ec-404e-9c32-bac43d9fa728",
    EmailAnalyticReportSectionName: "ReportSection",

    WebSocialAnalyticReportId : "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
    WebSocialAnalyticReportSectionName: "ReportSection",

    RevenueBeforeReportId : "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
    RevenueBeforeReportSectionName: "ReportSection2493b5daafc4c9fc6116",

    RevenueAfterReportId : "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
    RevenueAfterReportSectionName: "ReportSection3fa1a88d36674bc10f9d",

    DecompReportId : "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
    DecompReportSectionName: "ReportSection8ad0b724a0cf2f7eaca4",

    ProductRecReportId : "#Product_Recommendation#",
    ProductRecReportSectionName: "ReportSectionb1db078f436c6df90c30",

    // POWERAPPS_LINK: "https://apps.powerapps.com/play/630d6be7-0070-48eb-8b27-8bab33c761d5?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
    POWERAPPS_LINK: "https://apps.powerapps.com/play/3de6c2f6-75b5-4877-a209-7fb8e27240a8?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
    USMapReportId : "#World_Map#",
    USMapReportSectionName : "ReportSectione100aa1269c2d9800002",

    FinancialPlanningDashboardId : "",
    
    RevenueAndProfitReportId : "#Revenue_and_Profiability#",
    RevenueSectionName : "ReportSectione6a195cc5df5faf3eb77",

    PredictiveAnatyticsReportId : "#Retail_Predictive_Analytics#",
    PredictiveAnatyticsReportSectionName : "ReportSection01004f62b9c010350168",

    CustomerSegmentationReportId : "a2599faa-bc02-487c-afe8-58321bee1209",
    CustomerSegmentationReportSectionName : "ReportSection8fc595c6c425617404c2",


    ESGDashboardID : "",
    CCODashboardBeforeID: "",
    search_app_url:"https://orange-rock-0bff3191e.1.azurestaticapps.net/search?q=drass",
    agolo_searchapp_url:"",
    agolo_searchapp_fred_url:"https://app-edgarretail-prod001.azurewebsites.net/#/searchforfred",
    ceo_dashboard_mid_id:"",

    AcquisitionReportId:"#Acquisition_Impact_Report#",
    AcquisitionReportSectionName:"ReportSectiond2bfd6ee84e5d52c5aa9",

    AcquisitionAfterDashboardId: "ebb3bb23-a4b9-42b2-980f-9dd78aa39d39",

    PostAcquisitionReportId:"#Acquisition_Impact_Report#",
    PostAcquisitionReportSectionName:"ReportSection20dfb8c36bac84c37b61",

    ceo_dashboard_mid_top_report_id : "#Retail_Group_CEO_KPI#",
    ceo_dashboard_mid_top_report_sectionname : "ReportSectionfd6f0d440865b0c1da0a",

    nov_dashboard_top_report_id:"#Retail_Group_CEO_KPI#",
    nov_dashboard_top_report_sectionname:"ReportSection26246a2310d36c4d0ece",

    dec_dashboard_top_report_id:"#Retail_Group_CEO_KPI#",
    dec_dashboard_top_report_sectionname:"ReportSection68cb8066934630a72b53",

    ceo_dashboard_after_top_report_id : "#Retail_Group_CEO_KPI#",
    ceo_dashboard_after_top_report_sectionname : "ReportSectiona691f7ffd10928c0e108",

    search_spencer_url:"https://#SEARCH_APP_NAME#.azurewebsites.net/#/search-spencer",
    search_reta_url:"https://#SEARCH_APP_NAME#.azurewebsites.net/#/search-reta",
    search_ryan_url:"https://#SEARCH_APP_NAME#.azurewebsites.net/#/search-ryan",
    
    NOVDashboardID : "",

    LocationAnatyticsReportId : "#Location_Analytics#",
    LocationAnatyticsReportSectionName : "ReportSection46d80580e572ada4e609",


    ai_search_url : "https://orange-rock-0bff3191e.1.azurestaticapps.net",
    chat_bot_url : "https://webchat.botframework.com/embed/#BOT_QNAMAKER_RETAIL_NAME#/gemini?b=#BOT_QNAMAKER_RETAIL_NAME#&s=#BOT_KEY#&username=You",

    AfterDashboardDec : "",
    
    IncidentReportID : "#Global_Occupational_Safety_Report#",
    IncidentReportSectionName : "ReportSection1ee1dbf5b8dc07148713",

    PDFBaseLink: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/incident-search/",
    IncidentSearchUrl : "https://#STORAGE_ACCOUNT#.blob.core.windows.net/incident-search/search.html",
    PDFBaseInvoiceLink: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/idcard/",
    AIBuilderPowerApp_Link : "https://apps.powerapps.com/play/ba0a135b-c09f-4006-a8f8-bf721297ade1?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
   
    TeaserVideoUrl:"https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/9d282803-9cc5-4343-b4dc-e6154c060817/Retail_Teaser_Video_V19.ism/manifest",
    RetailStoreVideoUrl:"https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/b88e73b0-71f0-4897-8165-c94ba3f46d09/Retail_Store_Video_V19.ism/manifest",

    FinalVideoUrl: "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/2eff7e5f-eb8f-471a-a028-6eaab7c6acbe/Retail_Finale_Video_V20.ism/manifest",
    
    ADXDirectDashboardId:"49198651-f078-4b32-ac6b-44ffd8c5e605",

    ADXDirectDashboard2Id:"bf3ca69c-92f4-4561-804d-9b108bb2716a",

    ADXDirectDashboardReport3Id:"#ADX_Thermostat_and_Occupancy#",
    ADXDirectDashboardReport3SectionName:"ReportSection6efc74dccd4775687467",

    with_htap_report:"#Retail_HTAP#",
    with_htap_report_section:"ReportSection5da67bdcb8966c1a8e9e",

    without_htap_report:"#Retail_HTAP#",
    without_htap_report_section:"ReportSectione651bdbd575dd0d3858d",

    SPEECHKEY: "#SPEECH_KEY#",
    SPEECHREGION : "#LOCATION#"
}
