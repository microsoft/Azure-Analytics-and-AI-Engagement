window['runConfig'] = {    
    BlobBaseUrl: "https://dreamdemoassets.blob.core.windows.net/retail20/",
    IconBlobBaseUrl: "https://dreamdemoassets.blob.core.windows.net/retail20/left-nav-icons/",
    apiUrl: "https://app-retaildemo.azurewebsites.net",
    //apiUrl: "https://localhost:5001",
    PAGE_ID_DASHBOARD: "36ee260a-bd01-4d65-b506-c2a7269c2a44",

    PageID_Twitter: "d9c4bb0b-317c-4a82-a882-87165b35e27f",
    TwitterReportSectionName: "ReportSection",

    CEO_BEFORE_DASHBOARD_ID: "6252c7ed-50b7-45bf-800a-569caf5923e9",
    ceo_dashboard_before_top_report_id:"460d7156-523e-4743-b4d9-0057b12dc5c2",
    ceo_dashboard_before_top_report_sectionname:"ReportSection5f752c6bde03670c8284",
    ceo_dashboard_after_id: "ebb3bb23-a4b9-42b2-980f-9dd78aa39d39",
    // PAGE_ID: "5e83e2f6-aac6-4bd4-a1eb-debaec14e261",

    CampaignAnalyticDeepDiveReportId: "5e83e2f6-aac6-4bd4-a1eb-debaec14e261",
    CampaignAnalyticDeepDiveReportSectionName: "ReportSectionf2c099731dcd88ec8a6c",

    CampaignReportIdOld: "e28d7c71-ea92-4d2d-bd2e-30f83bcdf386",
    CampaignReportOldSectionName: "ReportSection92fdb1cb740d8014a463",

    CampaignAnylicsAfterReportId : "e28d7c71-ea92-4d2d-bd2e-30f83bcdf386",
    CampaignAnylicsAfterReportSectionName : "ReportSection6b516ade5e3ee314d089",

    
    RetailstoreReportId : "4724e4c2-0120-407a-a0f6-99c07d9444f6",
    RetailstoreReportSectionName: "ReportSection",

    ADXHistoricalReportId:"6b2766d1-c3da-4311-b090-5e47758d4a36",
    ADXHistoricalReportSectionName:"ReportSection7d104fc7e0cb69ca682b",

    ADXDirectReportId:"3f623655-f789-48bb-8089-a6680f847fca",
    ADXDirectReportSectionName:"ReportSectionb4cd1d334fe3b8497487",

    EamilAnalyticReportId : "4b9de275-01ec-404e-9c32-bac43d9fa728",
    EmailAnalyticReportSectionName: "ReportSection",

    WebSocialAnalyticReportId : "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
    WebSocialAnalyticReportSectionName: "ReportSection",

    RevenueBeforeReportId : "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
    RevenueBeforeReportSectionName: "ReportSection2493b5daafc4c9fc6116",

    RevenueAfterReportId : "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
    RevenueAfterReportSectionName: "ReportSection3fa1a88d36674bc10f9d",

    DecompReportId : "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
    DecompReportSectionName: "ReportSection8ad0b724a0cf2f7eaca4",

    ProductRecReportId : "84eaf34a-8293-41fa-839e-977285e3018f",
    ProductRecReportSectionName: "ReportSectionb1db078f436c6df90c30",

    // POWERAPPS_LINK: "https://apps.powerapps.com/play/630d6be7-0070-48eb-8b27-8bab33c761d5?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
    POWERAPPS_LINK: "https://apps.powerapps.com/play/3de6c2f6-75b5-4877-a209-7fb8e27240a8?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
    USMapReportId : "dad799a7-e156-45cc-9c7e-08d72c444792",
    USMapReportSectionName : "ReportSectione100aa1269c2d9800002",

    FinancialPlanningDashboardId : "68cfe577-58a9-425f-9286-e991b5665030",

    RevenueAndProfitReportId : "14f547a7-111b-4878-a3ab-2d47bc430a3f",
    RevenueSectionName : "ReportSection5",

    PredictiveAnatyticsReportId : "54f429fc-1538-4c61-b85a-ea3271ee6f68",
    PredictiveAnatyticsReportSectionName : "ReportSection01004f62b9c010350168",

    CustomerSegmentationReportId : "a2599faa-bc02-487c-afe8-58321bee1209",
    CustomerSegmentationReportSectionName : "ReportSection8fc595c6c425617404c2",


    ESGDashboardID : "4d56bcf8-76df-4239-92e7-9bc4236ac035",
    CCODashboardBeforeID: "c25a4237-2bff-4ba0-9ecd-60971fa09ec7",
    search_app_url:"https://purple-grass-07d210d1e.azurestaticapps.net",
    agolo_searchapp_url:"https://app-retailedgarsearch-dev001.azurewebsites.net",
    agolo_searchapp_fred_url:"https://app-retailedgarsearch-dev001.azurewebsites.net/#/searchforfred",
    ceo_dashboard_mid_id:"c1a72671-03d3-4129-8f26-062b9eb424df",

    AcquisitionReportId:"36f8fad5-2e79-4656-b76b-4ed3128747aa",
    AcquisitionReportSectionName:"ReportSectiond2bfd6ee84e5d52c5aa9",

    AcquisitionAfterDashboardId: "ebb3bb23-a4b9-42b2-980f-9dd78aa39d39",

    PostAcquisitionReportId:"36f8fad5-2e79-4656-b76b-4ed3128747aa",
    PostAcquisitionReportSectionName:"ReportSection20dfb8c36bac84c37b61",

    ceo_dashboard_mid_top_report_id : "460d7156-523e-4743-b4d9-0057b12dc5c2",
    ceo_dashboard_mid_top_report_sectionname : "ReportSectionfd6f0d440865b0c1da0a",

    nov_dashboard_top_report_id:"460d7156-523e-4743-b4d9-0057b12dc5c2",
    nov_dashboard_top_report_sectionname:"ReportSection26246a2310d36c4d0ece",

    dec_dashboard_top_report_id:"460d7156-523e-4743-b4d9-0057b12dc5c2",
    dec_dashboard_top_report_sectionname:"ReportSection68cb8066934630a72b53",

    ceo_dashboard_after_top_report_id : "460d7156-523e-4743-b4d9-0057b12dc5c2",
    ceo_dashboard_after_top_report_sectionname : "ReportSectiona691f7ffd10928c0e108",

    search_spencer_url:"https://retail-mediasearch-app-dev.azurewebsites.net/#/search-spencer",
    search_reta_url:"https://retail-mediasearch-app-dev.azurewebsites.net/#/search-reta",
    search_ryan_url:"https://retail-mediasearch-app-dev.azurewebsites.net/#/search-ryan",

    NOVDashboardID : "adeeb11b-d834-4a26-98a7-1a8a6d0cbcfc",

    LocationAnatyticsReportId : "883f295c-d53d-4362-b3e7-42985df16a86",
    LocationAnatyticsReportSectionName : "ReportSection2",

    
    ai_search_url : "https://purple-grass-07d210d1e.azurestaticapps.net/search?q=drass",
    chat_bot_url : "https://webchat.botframework.com/embed/RetailBotv01/gemini?b=RetailBotv01&s=O-mEiqPttxE.Hkmh1X8ShHDpf0Kfd1taQf4DlrS7lB9iXDbtRXCdJnc&username=You",

    AfterDashboardDec : "14987a97-b733-464a-99e1-bd5dd3082121",
    
    IncidentReportID : "ba65e430-0e78-4a30-b595-ca6b3fc8da4d",
    IncidentReportSectionName : "ReportSection1ee1dbf5b8dc07148713",

    PDFBaseLink: "https://stretailprod.blob.core.windows.net/incident-search/",

    IncidentSearchUrl : "https://stretailprod.blob.core.windows.net/incident-search/search.html",

    PDFBaseInvoiceLink: "https://stretailprod.blob.core.windows.net/idcard/",

    AIBuilderPowerApp_Link : "https://apps.powerapps.com/play/ba0a135b-c09f-4006-a8f8-bf721297ade1?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",

    TeaserVideoUrl:"https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/9d282803-9cc5-4343-b4dc-e6154c060817/Retail_Teaser_Video_V19.ism/manifest",
    RetailStoreVideoUrl:"https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/b88e73b0-71f0-4897-8165-c94ba3f46d09/Retail_Store_Video_V19.ism/manifest",
    FinalVideoUrl:"https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/259c6704-fbc3-4412-b946-f181a5818b2f/Retail_Finale_Video_V25.ism/manifest",
    
    ADXDirectDashboardId:"7086ca7a-0aaf-48ad-9b0a-1dc16cc14a06",

    ADXDirectDashboard2Id:"c6ad3d58-9718-4dd3-bf70-a519d01dbae8",

    ADXDirectDashboardReport3Id:"6b2766d1-c3da-4311-b090-5e47758d4a36",
    ADXDirectDashboardReport3SectionName:"ReportSection6efc74dccd4775687467",
}
