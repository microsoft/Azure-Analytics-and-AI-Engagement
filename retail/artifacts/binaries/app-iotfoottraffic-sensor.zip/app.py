from flask import Flask
from BeforeAndAfterScenarioGroupCEORealtime import generateData
from IoTSimulator import main


import threading
import asyncio

def callIoMTSimulator():
    asyncio.run(main())


app = Flask(__name__)

t1 = threading.Thread(target=callIoMTSimulator).start()

if __name__ == '__main__':
    app.run()


