window['runConfig'] = {
    VideoIndexerId: "#VI_ACCOUNT_ID#",
    TokenUrl: "https://api.videoindexer.ai/Auth/#VI_LOCATION#/Accounts/#VI_ACCOUNT_ID#/AccessToken?allowEdit=False",
    OcpApimSubscriptionKey: "#VI_API_KEY#",
    VidoIndexSearchApi:"https://api.videoindexer.ai/#VI_LOCATION#/Accounts/#VI_ACCOUNT_ID#/Videos/Search?",
    Location: "#VI_LOCATION#",
    MainRecommenderUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/recommendermodel/RecommenderCache.json",
    PersonalisedRecommenderUrl : "https://#STORAGE_ACCOUNT#.blob.core.windows.net/recommendermodel/PersonalisedRecommenderCache.json",
}
