window['runConfig'] = {    
    BlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/retail20/",
    IconBlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/retail20/left-nav-icons/",
    apiUrl: "https://#SERVER_NAME#.azurewebsites.net",
    //apiUrl: "https://localhost:5001",
    PAGE_ID_DASHBOARD: "36ee260a-bd01-4d65-b506-c2a7269c2a44",

    PageID_Twitter: "d9c4bb0b-317c-4a82-a882-87165b35e27f",
    TwitterReportSectionName: "ReportSection",

    CEO_BEFORE_DASHBOARD_ID: "",
    ceo_dashboard_after_id: "",
    FinancialPlanningDashboardId : "",
    CCODashboardBeforeID: "",
    ESGDashboardID : "4d56bcf8-76df-4239-92e7-9bc4236ac035",

    ceo_dashboard_before_top_report_id:"#Retail_Group_CEO_KPI#",
    ceo_dashboard_before_top_report_sectionname:"ReportSection5f752c6bde03670c8284",
    
    // PAGE_ID: "5e83e2f6-aac6-4bd4-a1eb-debaec14e261",

    CampaignAnalyticDeepDiveReportId: "#Campaign_Analytics#",
    CampaignAnalyticDeepDiveReportSectionName: "ReportSectionf2c099731dcd88ec8a6c",

    CampaignReportIdOld: "e28d7c71-ea92-4d2d-bd2e-30f83bcdf386",
    CampaignReportOldSectionName: "ReportSection92fdb1cb740d8014a463",

    RetailstoreReportId : "4724e4c2-0120-407a-a0f6-99c07d9444f6",
    RetailstoreReportSectionName: "ReportSection",

    EamilAnalyticReportId : "4b9de275-01ec-404e-9c32-bac43d9fa728",
    EmailAnalyticReportSectionName: "ReportSection",

    WebSocialAnalyticReportId : "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
    WebSocialAnalyticReportSectionName: "ReportSection",

    RevenueBeforeReportId : "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
    RevenueBeforeReportSectionName: "ReportSection2493b5daafc4c9fc6116",

    RevenueAfterReportId : "ff44c46e-8e41-4c10-b96a-9f66d1a464c9",
    RevenueAfterReportSectionName: "ReportSection3fa1a88d36674bc10f9d",

    DecompReportId : "c9e757e1-df40-49f3-b9c1-40cd3a55dc89",
    DecompReportSectionName: "ReportSection8ad0b724a0cf2f7eaca4",

    ProductRecReportId : "f960cf45-c83f-4750-8842-75ff7b51ffdb",
    ProductRecReportSectionName: "ReportSection",

    // POWERAPPS_LINK: "https://apps.powerapps.com/play/630d6be7-0070-48eb-8b27-8bab33c761d5?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
    POWERAPPS_LINK: "https://apps.powerapps.com/play/3693f2cd-ae48-426a-86cf-a8bb77143306?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",
    USMapReportId : "#US_Map_with_header#",
    USMapReportSectionName : "ReportSectione100aa1269c2d9800002",

    

    RevenueAndProfitReportId : "#Finance_Report#",
    RevenueSectionName : "ReportSection5",

    PredictiveAnatyticsReportId : "#Retail_Predictive_Analytics#",
    PredictiveAnatyticsReportSectionName : "ReportSection01004f62b9c010350168",


    
    
    search_app_url:"https://purple-grass-07d210d1e.azurestaticapps.net",
    agolo_searchapp_url:"https://app-retailedgarsearch-dev001.azurewebsites.net",
    ceo_dashboard_mid_id:"c1a72671-03d3-4129-8f26-062b9eb424df",

    AcquisitionReportId:"#Acquisition_Impact_Report#",
    AcquisitionReportSectionName:"ReportSectiond2bfd6ee84e5d52c5aa9",

    AcquisitionAfterDashboardId: "ebb3bb23-a4b9-42b2-980f-9dd78aa39d39",

    PostAcquisitionReportId:"#Acquisition_Impact_Report#",
    PostAcquisitionReportSectionName:"ReportSection20dfb8c36bac84c37b61",

    ceo_dashboard_mid_top_report_id : "#Retail_Group_CEO_KPI#",
    ceo_dashboard_mid_top_report_sectionname : "ReportSectionfd6f0d440865b0c1da0a",

    ceo_dashboard_after_top_report_id : "#Retail_Group_CEO_KPI#",
    ceo_dashboard_after_top_report_sectionname : "ReportSection68cb8066934630a72b53"

}
