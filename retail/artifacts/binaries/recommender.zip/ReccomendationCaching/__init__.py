import logging
from azure.storage.blob import BlobClient,BlobServiceClient,ContainerClient
import json
import pandas as pd
from io import BytesIO
import azure.functions as func
import numpy as np 
import os



def main(myblob: func.InputStream):
    CONTAINERNAME = os.environ["CONTAINER_WITH_MODELS"]
    CONNECTIONSTRING= os.environ["CONNECTIONSTRING"]
    BLOBNAME = 'similarity.csv'
    blob = BlobClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME, blob_name=BLOBNAME)
    blob_data = blob.download_blob()
    content_df = pd.read_csv(BytesIO(blob_data.content_as_bytes()))
    
    BLOBNAME = "personalised_similarity.csv"
    blob = BlobClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME, blob_name=BLOBNAME)
    blob_data = blob.download_blob()
    personalised_df = pd.read_csv(BytesIO(blob_data.content_as_bytes()))

    BLOBNAME = "personas.json"
    blob = BlobClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME, blob_name=BLOBNAME)
    blob_data = blob.download_blob()
    personas = json.load(BytesIO(blob_data.content_as_bytes()))


    blobs = download_blobs()

    cache_content_based(content_df,blobs)
    cache_persona_based(personalised_df,blobs,personas)

def download_blobs(): 
    CONTAINERNAME = os.environ["CONTAINER_WITH_VIDEO_JSONS"]
    CONNECTIONSTRING=  os.environ["CONNECTIONSTRING"]
    container_client = ContainerClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME)


    json_objs= {}
    
    for blob in container_client.list_blobs():

        blob_client = BlobClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME, blob_name=blob.name)
        blob_data = blob_client.download_blob()
        json_obj = json.load(BytesIO(blob_data.content_as_bytes()))
        json_objs[json_obj['video_id']] = json_obj

    return json_objs



def cache_content_based(df,blobs): 
    CONTAINERNAME = os.environ["CONTAINER_WITH_MODELS"]
    CONNECTIONSTRING=  os.environ["CONNECTIONSTRING"]
    container_client = ContainerClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME)

    cols = df.columns.to_list()
    json_object = {}
    for i in df.index: 
        record = df.iloc[i]
        indices = np.argsort(record)
        indices = np.flipud(indices)[1:6]
        video_id = cols[i]
        json_object[video_id] =[]

        for vid_index in indices: 
            name = cols[vid_index] + ".json"
            data_dict= blobs[cols[vid_index]]['data']
            data_dict['name'] = blobs[cols[vid_index]]['name']
            data_dict['video_id'] = blobs[cols[vid_index]]['video_id']


            json_object[video_id].append(data_dict)
    blob_client = container_client.upload_blob(name ='RecommenderCache.json',data= json.dumps(json_object),overwrite=True)

def cache_persona_based(df,blobs,personas): 
    CONTAINERNAME = os.environ["CONTAINER_WITH_MODELS"]
    CONNECTIONSTRING=  os.environ["CONNECTIONSTRING"]
    container_client = ContainerClient.from_connection_string(conn_str=CONNECTIONSTRING, container_name=CONTAINERNAME)

    cols = df.columns.to_list()
    json_object = {}

    for persona in personas['items']: 
        index = int(persona['id']) - 1 
        indices = np.argsort(df.iloc[index])
        indices = np.flipud(indices)[1:6]
        json_object[persona['name']] = []

        for vid_index in indices: 
            data_dict= blobs[cols[vid_index]]['data']
            data_dict['name'] = blobs[cols[vid_index]]['name']
            data_dict['video_id'] = blobs[cols[vid_index]]['video_id']
                        
            json_object[persona['name']].append(data_dict)

    blob_client = container_client.upload_blob(name ='PersonalisedRecommenderCache.json',data= json.dumps(json_object),overwrite=True)