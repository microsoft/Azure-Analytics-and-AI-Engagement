import threading 
from flask import Flask
from thermostatTelemetry import thermostatData,occupancyData

app = Flask(__name__)

t1 = threading.Thread(target=thermostatData).start()
t2 = threading.Thread(target=occupancyData).start() 

if __name__ =='__main__':
    
    app.run()
    

