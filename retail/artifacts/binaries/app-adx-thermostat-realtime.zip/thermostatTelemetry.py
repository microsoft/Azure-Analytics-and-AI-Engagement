import os
import json
from datetime import datetime
import random 
import time
import requests
from azure.eventhub import EventHubProducerClient, EventData

def thermostatData():
    configs = json.loads(os.getenv("thermostatTelemetryConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    data = configs['data']
    url = configs["urlPowerBI"]
    connection_str = configs["urlStringEventhub"]
    eventhub_name = configs["EventhubName"]
    client = EventHubProducerClient.from_connection_string(connection_str, eventhub_name=eventhub_name)
    
    store_list = ["S"+"{:03d}".format(i) for i in range(1,11)]
    cities =["Miami","San Diego","New York","San Francisco","Las Vegas","London","Dubai","Singapore","Tokyo","Chicago"]
    store_list_cities_mapping = list(zip(store_list,cities))
    store_and_thermostat_mapping = []
    j = 0
    for i in range(1,101):
        store_and_thermostat_mapping.append(("TH"+"{:03d}".format(i),store_list_cities_mapping[j][0],store_list_cities_mapping[j][1]))
        if(i%10) == 0:
            j=j+1
    
    while True:
        start_time = time.time()    
        event_data_batch = client.create_batch()
        payloadBatch = []
        recordedOn = str(datetime.utcnow())
        for thermostatId,storeId,city in store_and_thermostat_mapping:
            payload = {}
            payload["DeviceId"] = thermostatId
            payload["City"] = city
            payload["StoreID"] = storeId
            payload["EnqueuedTimeUTC"] = recordedOn
            for index in range(len(data)):
                for key in data[index]:
                    # if(counter == 0 or (counter!=0 and (key in key_list))):
                    if type(data[index][key]["minValue"]) == int:
                        currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                        
                    elif type(data[index][key]["minValue"]) == float:
                        currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                    else:
                        currVal = random.choice(data[index][key]['minValue'])
                    payload[key]=currVal
            payloadBatch.append(payload)
            #print(payload)    
        mainPayloadStr = json.dumps(payloadBatch)
        print(mainPayloadStr)
        #print(inspect.getouterframes(inspect.currentframe())[1][3])
        print(time.time()-start_time)
        event_data_batch.add(EventData(mainPayloadStr))
        
        # Send list of payload to PowerBI...need to check will it work or not 
        try:
            x = requests.post(url, data=mainPayloadStr)
            print(x.text)
            x.close()
            print()
        except Exception as e:
            print(e)
        # Send the batch of events to the event hub.
        client.send_batch(event_data_batch)
        time.sleep(sleep_seconds)


def occupancyData():
    configs = json.loads(os.getenv("occupancyDataConfig"))
    sleep_seconds = configs['main_data_frequency_seconds']
    data = configs['data']
    url = configs["urlPowerBI"]
    connection_str = configs["urlStringEventhub"]
    eventhub_name = configs["EventhubName"]
    store_list = ["S"+"{:03d}".format(i) for i in range(1,11)]
    cities =["Miami","San Diego","New York","San Francisco","Las Vegas","London","Dubai","Singapore","Tokyo","Chicago"]
    store_list_cities_mapping = list(zip(store_list,cities))
    store_and_thermostat_mapping = []
    j = 0
    for i in range(1,101):
        store_and_thermostat_mapping.append(("TH"+"{:03d}".format(i),store_list_cities_mapping[j][0],store_list_cities_mapping[j][1]))
        if(i%10) == 0:
            j=j+1
    
    client = EventHubProducerClient.from_connection_string(connection_str, eventhub_name=eventhub_name)
    
    while True:
        start_time = time.time()
        event_data_batch = client.create_batch()
        payloadBatch = []
        recordedOn = str(datetime.utcnow())
        for thermostatId,storeId,city in store_and_thermostat_mapping:
            payload = {}
            payload["DeviceId"] = thermostatId
            payload["City"] = city
            payload["StoreID"] = storeId
            payload["EnqueuedTimeUTC"] = recordedOn
            for index in range(len(data)):
                for key in data[index]:
                    # if(counter == 0 or (counter!=0 and (key in key_list))):
                    if type(data[index][key]["minValue"]) == int:
                        currVal=random.randint(data[index][key]["minValue"], data[index][key]["maxValue"])
                        
                    elif type(data[index][key]["minValue"]) == float:
                        currVal = round(random.uniform(data[index][key]["minValue"], data[index][key]["maxValue"]), 1)
                    else:
                        currVal = random.choice(data[index][key]['minValue'])
                    payload[key]=currVal
            payloadBatch.append(payload)
            #print(payload)    
        mainPayloadStr = json.dumps(payloadBatch)
        print(mainPayloadStr)
        #print(inspect.getouterframes( inspect.currentframe() )[1][3])
        print(time.time()-start_time)
        event_data_batch.add(EventData(mainPayloadStr))
        
        # Send list of payload to PowerBI...need to check will it work or not 
        try:
            x = requests.post(url, data=mainPayloadStr)
            print(x.text)
            x.close()
            print()
        except Exception as e:
            print(e)
        # Send the batch of events to the event hub.
        client.send_batch(event_data_batch)        
        time.sleep(sleep_seconds)