window.config = {
  BASE_URL:
    '#OPEN_AI_ENDPOINT#openai/deployments/#MODEL_NAME#/completions?api-version=2022-12-01',

  CONTEXTUAL_SUMMARY_EXTERNAL_LINK:
	'https://ml.azure.com/fileexplorerAzNB?wsid=/subscriptions/#SUBSCRIPTION_ID#/resourcegroups/#RESOURCE_GROUP_NAME#/providers/Microsoft.MachineLearningServices/workspaces/#ML_WORKSPACE_NAME#&tid=#TENANT_ID#&activeFilePath=1%20Azure%20OpenAI%20Usecases%20for%20Healthcare.ipynb'
};
