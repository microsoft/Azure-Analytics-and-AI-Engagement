window.config = {
  BASE_URL:
    '#OPEN_AI_ENDPOINT#openai/deployments/#MODEL_NAME#/completions?api-version=2022-12-01',
  API_KEY: '#OPEN_AI_KEY#',
};
