param($Timer)
$URI="sb://#NAMESPACE_THERMOSTAT_OCCUPANCY#.servicebus.windows.net/payor-realtime-data"
$Access_Policy_Name="realtime"
$Access_Policy_Key="#EVENTHUB_ACCESS_POLICY_KEY#"
#Token expires now+3000
$Expires=([DateTimeOffset]::Now.ToUnixTimeSeconds())+3000
$SignatureString=[System.Web.HttpUtility]::UrlEncode($URI)+ "`n" + [string]$Expires
$HMAC = New-Object System.Security.Cryptography.HMACSHA256
$HMAC.key = [Text.Encoding]::ASCII.GetBytes($Access_Policy_Key)
$Signature = $HMAC.ComputeHash([Text.Encoding]::ASCII.GetBytes($SignatureString))
$Signature = [Convert]::ToBase64String($Signature)
$SASToken = "SharedAccessSignature sr=" + [System.Web.HttpUtility]::UrlEncode($URI) + "&sig=" + [System.Web.HttpUtility]::UrlEncode($Signature) + "&se=" + $Expires + "&skn=" + $Access_Policy_Name
$SASToken

$method = "POST"
$URI = "https://#NAMESPACE_THERMOSTAT_OCCUPANCY#.servicebus.windows.net/payor-realtime-data/messages"
$signature = $sastoken

# API headers
$headers = @{
            "Authorization"=$signature;
            "Content-Type"="application/atom+xml;type=entry;charset=utf-8";
            }

$EventHubTimer = new-timespan -seconds 120
$StopWatch = [diagnostics.stopwatch]::StartNew()
$low1=20
$low2=45
$low3=90
$low4=40
$low5=90
While ($StopWatch.elapsed -lt $EventHubTimer){
$id=new-guid
$id=$id.guid
$claimProcessingTimeBefore = Get-Random -minimum 45 -maximum 65
$claimProcessingTimeAfter = Get-Random -minimum 20 -maximum 35


if($low1 -lt 75){
$callCenterWaitTimeBefore = Get-Random -minimum $low1 -maximum ($low1+2)
}
$low1++

if($low2 -gt 3){
$callCenterWaitTimeafter = Get-Random -minimum ($low2-2) -maximum $low2
}
$low2--


if($low3 -gt 20){
$npsBefore = Get-Random -minimum ($low3-2) -maximum $low3
}
$low3--


if($low4 -lt 100){
$npsAfter = Get-Random -minimum $low4 -maximum ($low4+2)
}
$low4++


if($low5 -gt 20){
$memberSatisfactionBefore = Get-Random -minimum ($low5-2) -maximum $low5
}
$low5--

$memberSatisfactionAfter = Get-Random -minimum 7 -maximum 10
$strarry = @("Africa", "Europe", "North America")
$random=Get-Random -minimum 0 -maximum 2
$lastupdate=get-date
$body = @"
{"claimProcessingTimeBefore":$claimProcessingTimeBefore, "claimProcessingTimeAfter":$claimProcessingTimeAfter, "callCenterWaitTimeBefore":$callCenterWaitTimeBefore, "callCenterWaitTimeAfter":$callCenterWaitTimeAfter,"npsBefore": $npsBefore,"LastUpdate":"$lastupdate","npsAfter":$npsAfter,"memberSatisfactionBefore":$memberSatisfactionBefore,"memberSatisfactionAfter":$memberSatisfactionAfter}
"@

# execute the Azure REST API
Invoke-RestMethod -Uri $URI -Method $method -Headers $headers -Body $body
Start-Sleep -seconds 2
}
