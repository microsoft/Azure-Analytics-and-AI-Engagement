/// <reference types="react-scripts" />
interface Window {
  Microsoft: any;
}
