import * as powerbi from "powerbi-client";

export enum EmbedType {
  Report = "report",
  Dashboard = "dashboard",
  Tile = "tile",
}
export interface IFilter {
  table: string;
  column: string;
  value: string;
}

export interface IEmbedConfig {
  type: EmbedType;
  elementId: string;
  filter?: IFilter;
  height?: number;
  width?: number;
  pageName?: string;
  editMode?: boolean;
  onRendered?: Function;
  onClick?: Function;
}

export class PowerbiService {
  accessToken = "";
  embedToken = "";
  powerBiService: powerbi.service.Service;
  report: any;
  apiUrl = `${process.env.REACT_APP_API_BASE}`;
  instance: PowerbiService;

  constructor() {
    this.powerBiService = new powerbi.service.Service(
      powerbi.factories.hpmFactory,
      powerbi.factories.wpmpFactory,
      powerbi.factories.routerFactory
    );
    this.instance = this;
  }

  hydrate() {
    this.powerBiService.preload({});
  }

  switchMode(id: string, editMode: boolean) {
    const element = document.getElementById(id);
    if (!element) {
      return;
    }
    const report: any = this.powerBiService.get(element!);
    report.switchMode(editMode ? "edit" : "view");
  }

  switchPage(id: string, pageName: string) {
    const element = document.getElementById(id);
    if (!element) {
      return;
    }
    try {
      const report: any = this.powerBiService.get(element!);
      const page = report.page(pageName);
      page.setActive();
    } catch (error) {}
  }

  setFilter(id: string, filter: IFilter) {
    const element = document.getElementById(id);
    if (!element) {
      return;
    }
    const report: powerbi.Report = this.powerBiService.get(
      element!
    ) as powerbi.Report;

    report.removeFilters();
    const newFilter: powerbi.models.IBasicFilter = {
      filterType: powerbi.models.FilterType.Basic,
      target: {
        table: filter.table,
        column: filter.column,
      },
      operator: "In",
      values: [filter.value],
      $schema: "http://powerbi.com/product/schema#basic",
    };

    report.setFilters([newFilter]);
  }

  reload(id: string) {
    const element = document.getElementById(id);
    if (!element) {
      return;
    }

    const report: any = this.powerBiService.get(element!);
    report.reload();
  }

  refresh(id: string) {
    const element = document.getElementById(id);
    if (!element) {
      return;
    }

    const report: any = this.powerBiService.get(element);

    try {
      report.refresh();
    } catch (error) {}
  }

  async loadToken(id: string, embedConfig: IEmbedConfig): Promise<string> {
    let queryString = embedConfig.editMode ? "editMode=true" : "";
    if (queryString && embedConfig.filter) {
      queryString += (queryString ? "&" : "") + embedConfig.filter;
    }
    queryString = queryString ? "?" + queryString : "";

    const response = await fetch(
      `${this.apiUrl}/api/token/embed/${embedConfig.type}/${id}${queryString}`,
      {
        headers: {
          responseType: "text",
          "Access-Control-Allow-Origin": "*",
        },
      }
    );

    const token: string = await response.text();
    return token;
  }

  async load(id: string, embedConfig: IEmbedConfig) {
    let token = await this.loadToken(id, embedConfig);
    const config: any = {
      type: embedConfig.type,
      accessToken: token,
      tokenType: powerbi.models.TokenType.Embed,
      id: id,
      dashboardId: embedConfig.type === EmbedType.Dashboard ? id : "",
      embedUrl:
        embedConfig.type === EmbedType.Report
          ? "https://app.powerbi.com/reportEmbed"
          : embedConfig.type === EmbedType.Dashboard
          ? "https://app.powerbi.com/dashboardEmbed"
          : "https://app.powerbi.com/embed",
      permissions: embedConfig.editMode
        ? powerbi.models.Permissions.Create
        : powerbi.models.Permissions.Read,
      viewMode: embedConfig.editMode
        ? powerbi.models.ViewMode.Edit
        : powerbi.models.ViewMode.View,
      pageView: "fitToWidth",
    };

    if (embedConfig.type === EmbedType.Report) {
      config.settings = {
        filterPaneEnabled: false,
        navContentPaneEnabled: false,
        background: powerbi.models.BackgroundType.Transparent,
      };
    }
    if (embedConfig.pageName) {
      config.pageName = embedConfig.pageName;
    }
    if (embedConfig.height) {
      config.height = embedConfig.height;
    }
    if (embedConfig.width) {
      config.width = embedConfig.width;
    }

    const powerBiService = this.powerBiService;

    try {
      const report = powerBiService.embed(
        document.getElementById(embedConfig.elementId)!,
        config
      );

      let refreshToken = async (id: string, embedConfig: IEmbedConfig) => {
        let token = await this.loadToken(id, embedConfig);
        report.setAccessToken(token);
      };

      report.on("error", async (event: CustomEvent) => {
        if (event.detail.message === "TokenExpired") {
          await refreshToken(id, embedConfig);
        }
      });
      report.on("rendered", function (event) {
        if (embedConfig.onRendered) {
          embedConfig.onRendered(event);
        }
      });

      report.on("tileClicked", function (event) {
        if (embedConfig.onClick) {
          embedConfig.onClick(event);
        }
      });

      this.report = report;
    } catch (error) {}
  }
}

export const PowerbiServiceInstance = new PowerbiService();
