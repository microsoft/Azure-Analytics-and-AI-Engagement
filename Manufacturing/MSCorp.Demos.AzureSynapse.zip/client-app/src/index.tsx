import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import "./pulse.css";
import { Route, Switch, Redirect } from "react-router"; // react-router v4/v5
import MiamiMap from "./app/pages/MiamiMap";
import Miami from "./app/pages/Miami";
import GlobalBing from "./app/pages/GlobalBing";
import Factory from "./app/pages/Factory";
import Finance from "./app/pages/Finance";
import Login from "./app/pages/Login";
import AfterDashboard from "./app/pages/AfterDashboard";
import Video, { VideoType } from "./app/pages/Video";
import Machine from "./app/pages/Machine";
import SqlDiagram from "./app/pages/SqlDiagram";
import PostgreSqlDiagram from "./app/pages/PostgreSqlDiagram";
import Diagram from "./app/pages/Diagram";
import { store, history } from "./app/store";
import { Provider, connect } from "react-redux";
import * as serviceWorker from "./serviceWorker";
import { ConnectedRouter } from "connected-react-router";
import { PageType } from "./app/features/header/header";
import { login } from "./app/reducers/loginReducer";
import { setMobile } from "./app/reducers/mobileReducer";
import CampaignReport from "./app/pages/CampaignReport";
import PowerAppsReport from "./app/pages/PowerAppsReport";
import IncidentSearch from "./app/pages/IncidentSearch";
import GlobalSafetyDashboard from "./app/pages/GlobalSafetyDashboard";
import FormRecognizer from "./app/pages/FormRecognizer";
import ECommerce from "./app/pages/ECommerce";
import PostgreSqlRetailMap from "./app/pages/PostgreSqlRetailMap";
import PostgreSqlDashboardBefore from "./app/pages/PostgreSqlDashboardBefore";
import PostgreSqlDashboardAfter from "./app/pages/PostgreSqlDashboardAfter";
import PostgreSqlDashboardDuring from "./app/pages/PostgreSqlDashboardDuring";
import SalesCampaignReportPostMigration from "./app/pages/SalesCampaignReportPostMigration";
import SalesCampaignReportPreMigration from "./app/pages/SalesCampaignReportPreMigration";
import AnomalyDetectionReport from "./app/pages/AnomalyDetectionReport"

const mapState = (state: any) => state;
const actionCreators = {
  login,
  setMobile,
};
function App({}) {
  const width =
    window.innerWidth ||
    document.documentElement.clientWidth ||
    document.body.clientWidth;
  if (width <= 900) {
    setMobile();
  }

  return (
    <ConnectedRouter history={history}>
      <Switch>
        <Redirect exact from="/" to="/login" />
        <Route exact path="/miami" render={() => <Miami />} />
        <Route exact path="/MiamiMap" render={() => <MiamiMap />} />
        <Route
          exact
          path="/MiamiVideo"
          render={() => (
            <Video type={PageType.MiamiVideo} video={VideoType.MiamiVideo} />
          )}
        />
        <Route exact path="/global-bing" render={() => <GlobalBing />} />
        <Route exact path="/factory" render={() => <Factory />} />
        <Route exact path="/machine" render={() => <Machine />} />
        <Route exact path="/diagram" render={() => <Diagram />} />
        <Route exact path="/sqlDiagram" render={() => <SqlDiagram />} />
        <Route
          exact
          path="/postgreSqlDiagram"
          render={() => <PostgreSqlDiagram />}
        />
        <Route
          exact
          path="/postgreSqlDashboardBefore"
          render={() => (
            <PostgreSqlDashboardBefore
              dashboardId="7e9f44c1-4405-480e-8195-85a41022a7b8"
              type={PageType.PSSqlDashboardBefore}
            />
          )}
        />
          <Route
          exact
          path="/postgreSqlDashboardDuring"
          render={() => (
            <PostgreSqlDashboardDuring
              dashboardId="73110aee-e6d1-434e-86f6-e953ccc020c7"
              type={PageType.PSSqlDashboardDuring}
            />
          )}
        />
        <Route
          exact
          path="/postgreSqlDashboardAfter"
          render={() => (
            <PostgreSqlDashboardAfter
              dashboardId="36892896-3444-4073-a841-940c62be64dd"
              type={PageType.PSSqlDashboardAfter}
            />
          )}
        />
        <Route
          exact
          path="/postgreSqlRetailMap"
          render={() => <PostgreSqlRetailMap />}
        />
        <Route exact path="/login" render={() => <Login />} />
        <Route
          exact
          path="/campaign-report"
          render={() => <CampaignReport />}
        />
        <Route
          exact
          path="/field"
          render={() => (
            <Video type={PageType.Field} video={VideoType.HololensVideo} />
          )}
        />
         <Route
          exact
          path="/racetrack"
          render={() => (
            <Video type={PageType.RaceTrackVideo} video={VideoType.MiamiVideo} />
          )}
        />
        <Route
          exact
          path="/iaasVideo"
          render={() => (
            <Video type={PageType.IaasVideo} video={VideoType.IaasVideo} />
          )}
        />
        <Route
          exact
          path="/rio-de-janeiro"
          render={() => (
            <Video
              type={PageType.RioDeJaneiro}
              video={VideoType.RioDeJaneiro}
            />
          )}
        />
        <Route
          exact
          path="/postgreSqlVideo"
          render={() => (
            <Video
              type={PageType.PSSQLVideo}
              video={VideoType.PostgreSQL}
            />
          )}
        />
        <Route exact path="/finance" render={() => <Finance />} />
        <Route exact path="/powerApps" render={() => <PowerAppsReport />} />
        <Route exact path="/afterdashboard" render={() => <AfterDashboard />} />
        <Route
          exact
          path="/incident-search"
          render={() => <IncidentSearch />}
        />
        <Route
          exact
          path="/globalsafetydashboard"
          render={() => <GlobalSafetyDashboard />}
        />
        <Route exact path="/formrecognizer" render={() => <FormRecognizer />} />
        <Route exact path="/anomaly-detection-report" render={() => <AnomalyDetectionReport />} />
        <Route exact path="/ecommerce" render={() => <ECommerce />} />
        <Route
          exact
          path="/ecommerce2"
          render={() => <ECommerce override={true} />}
        />
        <Route
          exact
          path="/sales-and-campaign-report-pre"
          render={() => (
            <SalesCampaignReportPreMigration
              type={PageType.SalesCampaignReportPreMigration}
            />
          )}
        />
        <Route
          exact
          path="/sales-and-campaign-report-post"
          render={() => (
            <SalesCampaignReportPostMigration
              type={PageType.SalesCampaignReportPostMigration}
            />
          )}
        />
      </Switch>
    </ConnectedRouter>
  );
}

const ConnectedApp = connect(mapState, actionCreators)(App);

ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <ConnectedApp></ConnectedApp>
    </Provider>
  </React.StrictMode>,
  document.getElementById("root")
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
