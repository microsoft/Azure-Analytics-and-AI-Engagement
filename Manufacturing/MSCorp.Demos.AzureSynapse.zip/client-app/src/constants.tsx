export const BlobBase =
  "https://manufacturingdemoassets.blob.core.windows.net/webappassets/";
