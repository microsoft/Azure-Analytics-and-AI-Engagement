import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../../app/store";

interface ILoginState {
  loggedIn: boolean;
  componentHistory: string[];
}

const initialState: ILoginState = {
  loggedIn: false,
  componentHistory: [],
};

const loginSlice = createSlice({
  name: "login",
  initialState,
  reducers: {
    login: (state: ILoginState) => {
      localStorage.setItem('LoginCache', Date.now().toString());
      state.loggedIn = true;
    },
    addHistory: (state: ILoginState, payload: any) => {
      state.componentHistory = [...state.componentHistory, payload.payload];
    },
  },
});

const { actions, reducer } = loginSlice;
export const { login, addHistory } = actions;
export const loggedInSelector = (state: RootState) => { 
   let loggedIn = state.loginReducer.loggedIn;
   const loginCache = localStorage.getItem('LoginCache');

   if(loginCache) {
      const cacheDate = +loginCache;
      const checkDate = removeMinutes(Date.now(), 60);

      loggedIn = cacheDate > checkDate ? true : false;
   }

   return loggedIn;
}
export const componentHistorySelector = (state: RootState) =>
  state.loginReducer.componentHistory;
export default reducer;


function removeMinutes(date: number, minutes: number): number {
  return date - minutes*60000;
}
