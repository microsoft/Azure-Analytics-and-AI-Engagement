import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../../app/store";

interface IMobileState {
  isMobile: boolean;
}

const initialState: IMobileState = {
  isMobile: false,
};

const mobileSlice = createSlice({
  name: "mobile",
  initialState,
  reducers: {
    setMobile: (state: IMobileState) => {
      state.isMobile = true;
    },
  },
});

const { actions, reducer } = mobileSlice;
export const { setMobile } = actions;
export const isMobileSelector = (state: RootState) =>
  state.mobileReducer.isMobile;
export default reducer;
