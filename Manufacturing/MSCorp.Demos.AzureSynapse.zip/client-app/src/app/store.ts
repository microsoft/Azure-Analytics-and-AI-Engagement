import { ThunkAction, Action, configureStore } from "@reduxjs/toolkit";
import { createHashHistory } from "history";
import createRootReducer from "./reducerCombined";
import { routerMiddleware } from "connected-react-router";

export const history = createHashHistory();

export const store = configureStore({
  reducer: createRootReducer(history), // root reducer with router state
  middleware: [routerMiddleware(history)],
});

export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
