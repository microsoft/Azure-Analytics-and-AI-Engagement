import React, { useState, useRef } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./PostgreSqlRetailMap.module.css";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";
import { StoresClient, StoreModel } from "./../../stores.service";
import Popup from "../features/popup/popup";

const beforeMapTitle = "PostgreSQL_map_before.png";
const beforeMapAfter = "PostgreSQL_map_after.png";

//initialize the counter to update storeid
var firstValueCheck = 0;
var curStoreId = 1001;
//var recentData = [];

function PostgreSqlRetailMap() {
  const [backgroundMap, setBackgroundMap] = useState(beforeMapTitle);
  const [showAddStoreForm, setShowAddStoreForm] = useState(false);
  const [showRecentStoreForm, setShowRecentStoreForm] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const [storeName, setStoreName] = useState<string>("");
  const [storeType, setStoreType] = useState<string>("");
  const [storeAddress, setStoreAddress] = useState<string>("");
  const [storeCountry, setStoreCountry] = useState<string>("");
  const [storeLatitude, setStoreLatitude] = useState<string>("");
  const [storeLongitude, setStoreLongitude] = useState<string>("");
  const [storeCity, setStoreCity] = useState<string>("");
  const [recenData, setRecentData] = useState<Array<object>>();

  const service = new StoresClient(`${process.env.REACT_APP_API_BASE}`);
 
  const retailMapVideo = useRef<HTMLVideoElement>(null);

  //To add data
  const addDataBase = () => {
    let storeModel = new StoreModel();
    //increments storeid
    if (firstValueCheck == 0){
      firstValueCheck += 1;
    }else if(firstValueCheck > 0){
      curStoreId += 1;
    }
    
    storeModel.storeID = curStoreId;
    storeModel.storeName = storeName || "WW Importers Store";
    storeModel.storeType = storeType || "Wholesale";
    storeModel.address = storeAddress || "Rua Carlos Gomes";
    storeModel.country = storeCountry || "Brazil";
    storeModel.latitude = storeLatitude || "-22.901576";
    storeModel.longitude = storeLongitude || "-43.201253";
    storeModel.city = storeCity || "Rio De Janeiro";

    const addResult = service.add(storeModel);

    addResult.then(x => console.log(x)).catch(x => console.error(x)).finally(() => {
      setBackgroundMap(beforeMapAfter);
      setShowAddStoreForm(!showAddStoreForm);
    })
  }
  //to reset data
  const resetDataBase = () => {
    //to reset storeid counter
    firstValueCheck = 0;
    curStoreId = 1001;
    //to remove recent data from API
    const resetResult = service.remove();
    resetResult.then(x => console.log(x)).catch(x => console.error(x)).finally(() => {
      setBackgroundMap(beforeMapTitle);
    })
  }
  
  //to get recently added rows
  const getDataBase = () => {
    const getResult = service.get();
    getResult.then(x =>{setRecentData(x)}).catch(x => console.error(x)).finally(() => {
      setShowRecentStoreForm(!showRecentStoreForm);
    })
  }
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.PSSqlRetailMap}></Header>
      <Navbar type={PageType.PSSqlRetailMap} />
      <div className={styles.background}>
        <div className={styles.buttons}>
          <div
            className={`${styles.button}`}
            onClick={() => setShowAddStoreForm(!showAddStoreForm)}>
            Add Store
          </div>
          <div className={`${styles.button}`} onClick={() => resetDataBase()}>
            Reset Stores
          </div>
          <div className={`${styles.button}`} onClick={() => getDataBase()}>
            Top 10 Recently Added
          </div>
          <div
            className={`${styles.button}`}
            onClick={() => setShowVideo(!showVideo)}>
            Video
          </div>
        </div>
        <img src={`${BlobBase}${backgroundMap}`} />
        {showAddStoreForm && (
          <div className={styles.popup}>
            <div className={styles.popup_Container}>
              <img className={styles.modalBackground}
                src={`${BlobBase}popup_add_store_blank.png`}
                alt="add"
                onClick={() => setShowAddStoreForm(!showAddStoreForm)}
              />
              <div className={styles.form_Container}>
                <div className={styles.form_Row}>
                  <div className={styles.form_label}>
                    <label>Store Name</label>
                  </div>
                  <div className={styles.form_input}>
                    <input type="text" defaultValue="WW Importers Store" onChange={(e)=>{setStoreName(e.target.value)}}></input>
                  </div>
                </div>

                <div className={styles.form_Row}>
                  <div className={styles.form_label}>
                    <label>Store Type</label>
                  </div>
                  <div className={styles.form_input}>
                    <input type="text" defaultValue="Wholesale" onChange={(e)=>{setStoreType(e.target.value)}}></input>
                  </div>
                </div>  

                <div className={styles.form_Row}>
                  <div className={styles.form_label}>
                    <label>Address</label>
                  </div>
                  <div className={styles.form_input}>
                    <input type="text" defaultValue="Rua Carlos Gomes" onChange={(e)=>{setStoreAddress(e.target.value)}}></input>
                  </div>
                </div>
                <div className={styles.form_Row}>
                  <div className={styles.form_label}>
                    <label>Country</label>
                  </div>
                  <div className={styles.form_input}>
                    <input type="text" defaultValue="Brazil" onChange={(e)=>{setStoreCountry(e.target.value)}}></input>
                  </div>
                </div>
                <div className={styles.form_Row}>
                  <div className={styles.form_label}>
                    <label>Latitude</label>
                  </div>
                  <div className={styles.form_input}>
                    <input type="text" defaultValue="-22.901576" onChange={(e)=>{setStoreLatitude(e.target.value)}}></input>
                  </div>
                </div>
                <div className={styles.form_Row}>
                  <div className={styles.form_label}>
                    <label>Longitude</label>
                  </div>
                  <div className={styles.form_input}>
                    <input type="text" defaultValue="-43.201253" onChange={(e)=>{setStoreLongitude(e.target.value)}}></input>
                  </div>
                </div>
                <div className={styles.form_Row}>
                  <div className={styles.form_label}>
                    <label>City</label>
                  </div>
                  <div className={styles.form_input}>
                    <input type="text" defaultValue="Rio De Janeiro" onChange={(e)=>{setStoreCity(e.target.value)}}></input>
                  </div>
                </div>
                <div className={styles.form_Row}>
                  <div className={styles.form_label}>
                   
                  </div>
                  <div className={styles.form_input}>          
                   <div className={styles.form_button_launch}
                    
                    onClick={() => addDataBase()}
                  >
                    Launch Store
               
                  </div>
                </div>
              </div>
              </div>
            </div>
          </div>
        )},
        {showRecentStoreForm && (
          <div className={styles.popup}>
            <div className={styles.popup_Container} onClick={() => setShowRecentStoreForm(false)}>
            <img className={styles.modalBackground}
              src={`${BlobBase}popup_recent_top10.png`}
              alt="top10" />
            <div className={styles.form_Container}>
                <div className={styles.tableResponsive}>
                   <table className={styles.table}>
                     <thead>
                       <tr>
                          <th>Store Name</th>
                          <th>Country</th>
                          <th>City</th>
                        </tr>
                     </thead>
                     <tbody>
                       {
                         recenData?.map((val:any, index)=>{
                           return val.map((item:any,i:any)=>{
                            return (
                              <tr key={i}>
                                <td>{item.storeName}</td>
                                <td>{item.country}</td>
                                <td>{item.city}</td>
                              </tr>     
                             )
                           })
                         })
                       } 
                     </tbody>
                    </table>
                </div>
            </div>
          </div>
          </div>
        )},
        {showVideo && (
          <Popup
            banner="Video"
            onPopupDismiss={() => {
              setShowVideo(false);
            }}
            >
            <div className={`${styles.popupContentContainer}`}>
              <video 
                ref={retailMapVideo}
                src={BlobBase + "retailMapVideoV1.mp4"}
                preload="auto"
                controls
                playsInline
                controlsList="nodownload"
                onLoadStart={() => {
                  if (!retailMapVideo || !retailMapVideo.current) {
                    return;
                  }
                  retailMapVideo.current.volume = 0.05;
                }}
                className={`${styles.popupContent} `}
              ></video>
            </div>
          </Popup>
        )}
      </div>
    </div>
  );
}

export default PostgreSqlRetailMap;