import React, { useState } from "react";
import styles from "./Diagram.module.css";
import Navbar from "../features/navbar/navbar";
import Header, { PageType } from "../features/header/header";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

enum DiagramScreen {
  Reference,
  Hot,
  Cold,
  AppArchitecture,
  AppArchitectureSimplified
}

const Diagram = () => {
  const [page, setPage] = useState(DiagramScreen.Hot);

  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.Diagram}></Header>
      <Navbar type={PageType.Diagram} />
      <div className={styles.background}>
        <div className={styles.buttons}>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.Hot && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.Hot)}
          >
            Hot Path
          </div>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.Cold && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.Cold)}
          >
            Cold Path
          </div>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.Reference && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.Reference)}
          >
            Demo Architecture
          </div>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.AppArchitecture && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.AppArchitecture)}
          >
            App Architecture
          </div>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.AppArchitectureSimplified &&
              styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.AppArchitectureSimplified)}
          >
            App Architecture (Simplified)
          </div>
        </div>
        <div className={styles.diagramContainer}>
          <img
            className={styles.diagram}
            src={`${BlobBase}${
              page === DiagramScreen.Reference
                ? "bothpaths"
                : page === DiagramScreen.Cold
                ? "coldpath"
                : page === DiagramScreen.AppArchitecture
                ? "app_architecture"
                : page === DiagramScreen.AppArchitectureSimplified
                ? "app_architecture_simplified"
                : "hotpath"
            }.gif`}
            alt=""
          />
        </div>
      </div>
    </div>
  );
};

export default Diagram;
