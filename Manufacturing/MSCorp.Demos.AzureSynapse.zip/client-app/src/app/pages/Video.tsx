import React, { useRef, useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./Video.module.css";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

export enum VideoType {
  None,
  HololensVideo,
  MiamiVideo,
  IntroVideo,
  RioDeJaneiro,
  IaasVideo,
  PostgreSQL,
}

export interface IVideoProps {
  type: PageType;
  video: VideoType;
}

function Video(props: IVideoProps) {
  const video: React.RefObject<HTMLVideoElement> = useRef<HTMLVideoElement>(
    null
  );
  const hololensSource = "Hololens_Stretch.mp4";
  const miamiSource = "Intro_product.mp4";
  const rioSource = "RioDeJaneiro_video.mp4";
  const IaaSSource = "Lift and Shift Assesment and Migration_V.1.mp4";
  const postGreScalingSource = "PostgreSQLScaling.mp4";

  const [played, setPlayed] = useState(false);
  const [source, setSource] = useState(miamiSource);
  const [prevVideo, setPrevVideo] = useState(VideoType.None);

  const onPlay = () => {
    if (!played) {
      video.current!.currentTime = 0;
      setPlayed(true);
    }
  };

  useEffect(() => {
    setPlayed(false);
    video.current!.currentTime = 0;
  }, [prevVideo]);

  switch (props.video) {
    case VideoType.HololensVideo:
      if (source !== hololensSource) {
        setSource(hololensSource);
      }
      break;

    case VideoType.MiamiVideo:
      if (source !== miamiSource) {
        setSource(miamiSource);
      }
      break;

    case VideoType.RioDeJaneiro:
      if (source !== rioSource) {
        setSource(rioSource);
      }
      break;

    case VideoType.IaasVideo:
      if (source !== IaaSSource) {
        setSource(IaaSSource);
      }
      break;

    case VideoType.PostgreSQL:
      if (source !== postGreScalingSource) {
        setSource(postGreScalingSource);
      }
      break;

    default:
      break;
  }
  if (prevVideo !== props.video) {
    setPrevVideo(props.video);
  }

  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={props.type}></Header>
      <Navbar type={props.type} />
      <div className={styles.videoContainer}>
        <video
          ref={video}
          playsInline
          controls
          preload="auto"
          onPlay={onPlay}
          src={BlobBase + source}
          controlsList="nodownload"
          onLoadStart={() => {
            if (!video || !video.current) {
              return;
            }
            video.current.volume = 0.05;
          }}
          className={styles.video}
        >
          <source src={BlobBase + source} />
        </video>
      </div>
    </div>
  );
}

export default Video;
