import React, { useState, useEffect } from "react";

import { PowerbiServiceInstance, EmbedType } from "../../powerbi.service";
import Header, { PageType } from "../features/header/header";
import styles from "./Factory.module.css";
import Navbar from "../features/navbar/navbar";
import FactoryPopup from "../features/factory-popup/factory-popup";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

function Factory() {
  const [showPopUp, setShowPopUp] = useState(false);
  const [dashboardLoading, setDashboardLoading] = useState(false);

  const reportId = "e1eed163-ceec-4628-9834-8b19aaca86ed";
  const overview = "ReportSection5691aa74d544b03cf6ed";
  const alert = "ReportSectiond6c63aee8dbd98c9083f";
  const production = "ReportSection3dc0fc6ef1aebcc543b0";
  const oee = "ReportSection948d06cf27c044d540e1";
  const downtime = "ReportSectionf756caaa87c195dd397c";
  const energyMaintenance = "ReportSection4216d59f0ea336b94ea0";

  const powerbiService = PowerbiServiceInstance;

  const width = 438;
  const widthCover = 440;
  const height = 248;
  const heightTall = 401;

  useEffect(() => {
    if (dashboardLoading) {
      return;
    }

    setDashboardLoading(true);
    try {
      powerbiService.load(reportId, {
        type: EmbedType.Report,
        elementId: production,
        height,
        width,
        pageName: production,
      });
      powerbiService.load(reportId, {
        type: EmbedType.Report,
        elementId: oee,
        height: heightTall,
        width: widthCover,
        pageName: oee,
      });
      powerbiService.load(reportId, {
        type: EmbedType.Report,
        elementId: energyMaintenance,
        height,
        width,
        pageName: energyMaintenance,
      });
      powerbiService.load(reportId, {
        type: EmbedType.Report,
        elementId: downtime,
        height: height,
        width,
        pageName: downtime,
      });
    } catch (error) {
      setDashboardLoading(false);
    }
  }, [dashboardLoading, powerbiService]);

  useEffect(() => {
    let refreshTimer = setInterval(() => {
      powerbiService.refresh(production);
      powerbiService.refresh(oee);
      powerbiService.refresh(energyMaintenance);
      powerbiService.refresh(downtime);
    }, 15000);
    return () => clearInterval(refreshTimer);
  });

  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <div id="scalable-wrapper" className="content-container">
        <div id="content" className="content">
          <Header type={PageType.Factory}></Header>
          <Navbar type={PageType.Factory} />
          <div className="factory-page">
            <a href="#/machine" className={styles.alertMachine}></a>
            <div
              className={styles.showMap}
              onClick={() => setShowPopUp(true)}
            ></div>
            <img className="background" src={`${BlobBase}Factory.jpg`} alt="" />
            <img
              className={styles.factoryAnimation}
              src={`${BlobBase}factory_alerts_small.gif`}
              alt=""
            />
            <div
              id={overview}
              className={styles.overview + " report show"}
              style={{
                width: width + "px",
                height: heightTall + "px",
              }}
            ></div>
            <div
              id={alert}
              className={styles.alert + " report  show"}
              style={{
                width: width + "px",
                height: height + "px",
              }}
            ></div>
            <div
              id={production}
              className={styles.production + " report  show"}
              style={{
                width: width + "px",
                height: height + "px",
              }}
            ></div>
            <div
              id={oee}
              className={styles.oee + " report  show"}
              style={{
                width: widthCover + "px",
                height: heightTall + "px",
              }}
            ></div>
            <div
              id={energyMaintenance}
              className={styles.energyMaintenance + " report  show"}
              style={{
                width: width + "px",
                height: height + "px",
              }}
            ></div>
            <div
              id={downtime}
              className={styles.downtime + " report  show"}
              style={{
                width: width + "px",
                height: height + "px",
              }}
            ></div>
          </div>
        </div>
      </div>
      {showPopUp && (
        <FactoryPopup
          onPopupDismiss={() => {
            setShowPopUp(false);
          }}
        ></FactoryPopup>
      )}
    </div>
  );
}

export default Factory;
