import React, { useEffect, useState } from "react";
import styles from "./Global.module.css";
import Header, { PageType } from "../features/header/header";
import { PowerbiServiceInstance, EmbedType } from "../../powerbi.service";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

enum City {
  None,
  Miami,
  SanDiego,
  Rio,
  Stuttgart,
  Kyoto,
}

function GlobalBing() {
  const [cityType, setCityType] = useState(City.None);
  const [availabilityReportLoaded, setAvailabilityReportLoaded] = useState(
    false
  );
  const [performanceReportLoaded, setPerformanceReportLoaded] = useState(false);
  const [qualityReportLoaded, setQualityReportLoaded] = useState(false);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [started, setStarted] = useState(false);

  const reportId = "03e8dfe9-8dc3-4e46-a1f4-4251534a9a6f";

  const availabilityId = "availabilityReport";
  const performanceId = "performanceReport";
  const qualityId = "qualityReport";

  const availabilityPageName = "ReportSectionc45278bb119aba730003";
  const performancePageName = "ReportSection013038b103686d6f9e5b";
  const qualityPageName = "ReportSection4c6302695d4e5f295d03";

  const powerbiService = PowerbiServiceInstance;

  const width = 438;
  const height = 123;

  useEffect(() => {
    if (dashboardLoading) {
      return;
    }

    setDashboardLoading(true);
    powerbiService.load(reportId, {
      type: EmbedType.Report,
      elementId: availabilityId,
      height,
      width,
      pageName: availabilityPageName,
      onRendered: () => {
        setAvailabilityReportLoaded(true);
      },
    });
    powerbiService.load(reportId, {
      type: EmbedType.Report,
      elementId: performanceId,
      height,
      width,
      pageName: performancePageName,
      onRendered: () => {
        setPerformanceReportLoaded(true);
      },
    });
    powerbiService.load(reportId, {
      type: EmbedType.Report,
      elementId: qualityId,
      height,
      width,
      pageName: qualityPageName,
      onRendered: () => {
        setQualityReportLoaded(true);
      },
    });
  }, [dashboardLoading, powerbiService]);

  function switchToCity(city: City) {
    let cityName = "";
    switch (city) {
      case City.Kyoto:
        cityName = "Kyoto";
        break;

      case City.Miami:
        cityName = "Miami";
        break;

      case City.SanDiego:
        cityName = "San Diego";
        break;

      case City.Stuttgart:
        cityName = "Stuttgart";
        break;
      case City.Rio:
        cityName = "Rio de Janeiro";
        break;

      default:
        return;
    }

    powerbiService.setFilter(performanceId, {
      table: "mfg-Location",
      column: "LocationName",
      value: cityName,
    });
    powerbiService.setFilter(availabilityId, {
      table: "mfg-Location",
      column: "LocationName",
      value: cityName,
    });
    powerbiService.setFilter(qualityId, {
      table: "mfg-Location",
      column: "LocationName",
      value: cityName,
    });
  }

  useEffect(() => {
    if (
      !performanceReportLoaded ||
      !availabilityReportLoaded ||
      !qualityReportLoaded
    ) {
      return;
    }
    switchToCity(cityType);
  }, [
    cityType,
    dashboardLoading,
    performanceReportLoaded,
    availabilityReportLoaded,
    qualityReportLoaded,
    powerbiService,
  ]);

  useEffect(() => {
    if (started) {
      return;
    }

    setTimeout(() => {
      const globalCenter = new window.Microsoft.Maps.Location(20, -20);
      var map: Microsoft.Maps.Map = new (window.Microsoft as any).Maps.Map(
        "#bingMap",
        {
          credentials:
            "Avu0REbv3O6zKm6nSTAXp1QEHRKSsW1Txn0cvPpdeworlOt_1g1AvIa8ZvDDOhz3",
          center: globalCenter,
          zoom: 2,
          mapTypeId: window.Microsoft.Maps.MapTypeId.aerial,
          showZoomButtons: false,
          showLocateMeButton: false,
          showMapTypeSelector: false,
        }
      );

      map.setOptions({
        maxZoom: 12,
        minZoom: 2,
      });

      const StuttgartLocation = new window.Microsoft.Maps.Location(
        48.767761,
        9.17199
      );
      const SanDiegoLocation = new window.Microsoft.Maps.Location(
        32.715679,
        -117.161713
      );
      const MiamiLocation = new window.Microsoft.Maps.Location(
        25.95428,
        -80.121659
      );
      const RioLocation = new window.Microsoft.Maps.Location(
        -11.8461,
        -45.185848
      );
      const KyotoLocation = new window.Microsoft.Maps.Location(
        35.015511,
        135.770035
      );

      const popupAnchor = new Microsoft.Maps.Point(90, 105);

      let icons = [
        new Microsoft.Maps.Pushpin(StuttgartLocation, {
          icon: `${BlobBase}pin_Stuttgart.png`,
          anchor: popupAnchor,
        }),
        new Microsoft.Maps.Pushpin(MiamiLocation, {
          icon: `${BlobBase}pin_Miami.png`,
          anchor: popupAnchor,
        }),
        new Microsoft.Maps.Pushpin(SanDiegoLocation, {
          icon: `${BlobBase}pin_San_Diego.png`,
          anchor: popupAnchor,
        }),
        new Microsoft.Maps.Pushpin(RioLocation, {
          icon: `${BlobBase}pin_Rio.png`,
          anchor: popupAnchor,
        }),
        new Microsoft.Maps.Pushpin(KyotoLocation, {
          icon: `${BlobBase}pin_Kyoto.png`,
          anchor: popupAnchor,
        }),
      ];

      map.entities.add(icons);

      Microsoft.Maps.Events.addHandler(icons[0], "click", () =>
        setCityType(City.Stuttgart)
      );
      Microsoft.Maps.Events.addHandler(icons[1], "click", () =>
        setCityType(City.Miami)
      );
      Microsoft.Maps.Events.addHandler(icons[2], "click", () =>
        setCityType(City.SanDiego)
      );
      Microsoft.Maps.Events.addHandler(icons[3], "click", () =>
        setCityType(City.Rio)
      );
      Microsoft.Maps.Events.addHandler(icons[4], "click", () =>
        setCityType(City.Kyoto)
      );
    }, 500);
    setStarted(true);
  }, [started]);

  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <div id="scalable-wrapper" className="content-container">
        <div id="content" className="content">
          <Header type={PageType.GlobalBing}></Header>
          <Navbar type={PageType.GlobalBing} />
          <img
            src={`${BlobBase}shade_overlay.png`}
            alt="/shade_overlay.png"
            className={styles["map-shadow"]}
          />
          <div id="bingMap" className={styles.map}></div>
          <img
            className={`background ${styles["global-page-background"]}`}
            src={`${BlobBase}dash_overlay.png`}
            alt=""
            id="shade-overlay"
          />
          <a href="#/factory" className={`${styles.miami} ${styles.tile}`}></a>
          <div
            className={`${styles.stuttgart} ${styles.tile}`}
            onClick={() => {
              setCityType(City.Stuttgart);
            }}
          ></div>
          <div
            className={`${styles.kyoto} ${styles.tile}`}
            onClick={() => {
              setCityType(City.Kyoto);
            }}
          ></div>
          <div
            className={`${styles.sanDiego} ${styles.tile}`}
            onClick={() => {
              setCityType(City.SanDiego);
            }}
          ></div>
          <div
            id={availabilityId}
            className={`report ${styles.report} ${styles.availability} show`}
            style={{
              width: width + "px",
              height: height + "px",
            }}
          ></div>
          <div
            id={performanceId}
            style={{
              width: width + "px",
              height: height + "px",
            }}
            className={`report ${styles.report} ${styles.performance} show`}
          ></div>
          <div
            id={qualityId}
            style={{
              width: width + "px",
              height: height + "px",
            }}
            className={`report ${styles.report} ${styles.quality} show`}
          ></div>
        </div>
      </div>
    </div>
  );
}

export default GlobalBing;
