import React, { useState } from "react";
import styles from "./SqlDiagram.module.css";
import Navbar from "../features/navbar/navbar";
import Header, { PageType } from "../features/header/header";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

enum DiagramScreen {
  IaaS,
  PaaS,
  Both,
}

const SqlDiagram = () => {
  const [page, setPage] = useState(DiagramScreen.PaaS);

  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.Diagram2}></Header>
      <Navbar type={PageType.Diagram2} />
      <div className={styles.background}>
        <div className={styles.buttons}>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.PaaS && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.PaaS)}
          >
            PaaS
          </div>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.IaaS && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.IaaS)}
          >
            IaaS
          </div>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.Both && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.Both)}
          >
            Both
          </div>
        </div>
        <div className={styles.diagramContainer}>
          <img
            className={styles.diagram}
            src={`${BlobBase}${
              page === DiagramScreen.IaaS
                ? "sqlArch-IaaS"
                : page === DiagramScreen.PaaS
                ? "sqlArch-PaaS"
                : page === DiagramScreen.Both
                ? "sqlArch-IaaSPaaS"
                : ""
            }.gif`}
            alt=""
          />
        </div>
      </div>
    </div>
  );
};

export default SqlDiagram;
