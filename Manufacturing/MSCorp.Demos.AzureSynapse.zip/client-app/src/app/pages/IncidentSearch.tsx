import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./IncidentSearch.module.css";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

function SearchIndex() {
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.IncidentSearch}></Header>
      <Navbar type={PageType.IncidentSearch} />

      <a href="#/rio-de-janeiro" className={styles.gotoRio}>
        {/* BlobBase + "icon_arrow.png" */}
        <div className={styles.arrow}>
          <img
            src={`${BlobBase}icon_arrow.png`}
            alt="link to rio de janeiro video"
          />
        </div>
      </a>

      <iframe
        className={styles.incidentSearch + " dashboard incidentSearchCover"}
        style={{
          width: "calc(100% - 48px)",
          height: "100% !important",
        }}
        src="./incident-search.html"
      ></iframe>
    </div>
  );
}

export default SearchIndex;
