import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./Finance.module.css";
import { PowerbiServiceInstance, EmbedType } from "../../powerbi.service";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";

// **** NB - BELOW TEMP import TO BE REMOVED relates to flashing issue
import { BlobBase } from "../../constants";

function Finance() {
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const finance = "04854839-2bbf-4cf9-98cf-29d77048db5d";

  const width = 1920;
  const height = 1280;

  useEffect(() => {
    if (dashboardLoading) {
      return;
    }

    setDashboardLoading(true);
    try {
      PowerbiServiceInstance.load(finance, {
        type: EmbedType.Dashboard,
        elementId: finance,
        height: height,
        width,
      });
    } catch (error) {
      setDashboardLoading(false);
    }
  }, [dashboardLoading, PowerbiServiceInstance]);

  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.Finance}></Header>
      <Navbar type={PageType.Finance} />
      {/* <div
        id={finance}
        className={styles.finance + " dashboard"}
        style={{
          width: "calc(100% - 48px)",
          height: "calc(100% - 54px)",
        }}
        
      ></div> */}
      {/* Below to be removed = flashing issue */}
      <div className={styles.background} style={{paddingRight: '20px'}}>
        <div className={`${styles.diagramContainer} ${styles.example}`}>
          <img
            className={styles.diagram}
            src={`${BlobBase}${"executive_dashboard.gif?a="}${Math.random()}`}
            alt=""
          />
        </div>
      </div>
    </div>
  );
}

export default Finance;
