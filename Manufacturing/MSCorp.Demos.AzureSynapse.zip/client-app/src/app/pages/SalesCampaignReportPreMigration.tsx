import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./SalesCampaignReport.module.css";
import { PowerbiServiceInstance, EmbedType } from "../../powerbi.service";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";

export type SCRProps = {
  type: PageType;
};

function SalesCampaignReportPreMigration(props: SCRProps) {
  const [reportLoading, setReportLoading] = useState(false);
  const salesAndCampaign = "da4801ad-6721-4ba1-af07-3933a04fbe9e";
  const salesAndCampaignReportID = "ReportSection811d0856f92253ddb79e";
  const width = 1920;
  const height = 1280;

  useEffect(() => {
    if (reportLoading) {
      return;
    }

    setReportLoading(true);
    try {
      PowerbiServiceInstance.load(salesAndCampaign, {
        type: EmbedType.Report,
        elementId: salesAndCampaign,
        height: height,
        width,
        pageName: salesAndCampaignReportID,
      });
    } catch (error) {
      setReportLoading(false);
    }
  }, [reportLoading, PowerbiServiceInstance]);

  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={props.type}></Header>
      <Navbar type={props.type} />
      <div
        id={salesAndCampaign}
        className={styles.finance + " dashboard"}
        style={{
          width: "calc(100% - 48px)",
          height: "calc(100% - 54px)",
        }}
      ></div>
    </div>
  );
}

export default SalesCampaignReportPreMigration;
