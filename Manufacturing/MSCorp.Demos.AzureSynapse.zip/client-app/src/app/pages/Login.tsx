import React, { useState, useEffect } from "react";
import styles from "./Login.module.css";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { login } from "../reducers/loginReducer";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { useDispatch } from "react-redux";
import { PowerbiServiceInstance, PowerbiService } from "../../powerbi.service";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [powerbiServiceHydrated, setPowerbiServiceHydrated] = useState(false);
  const [powerbiService, setPowerbiInstance] = useState<PowerbiService>();
  const dispatch = useDispatch();
  useEffect(() => {
    if (!powerbiService) {
      setPowerbiInstance(PowerbiServiceInstance);
    }
  }, [powerbiServiceHydrated]);

  useEffect(() => {
    if (!powerbiServiceHydrated && powerbiService) {
      powerbiService.hydrate();
      setPowerbiServiceHydrated(true);
    }
  }, [powerbiServiceHydrated]);

  const buttonStyles: any = {
    fieldGroup: {
      height: "50px",
      ":placeholder": {
        fontSize: "20px",
      },
    },
    root: {
      marginTop: "20px",
    },
    field: {
      fontSize: "20px",
      lineHeight: "50px",
      ":placeholder": {
        fontSize: "20px",
      },
    },
  };

  const onUsernameChange = (
    _event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>,
    newValue?: string
  ) => {
    setUsername(newValue || "");
  };
  const onPasswordChange = (
    _event: React.FormEvent<HTMLInputElement | HTMLTextAreaElement>,
    newValue?: string
  ) => {
    setPassword(newValue || "");
  };
  const checkLogin = () => {
    if (
      username.toLowerCase() === "Wendy@WideWorldImporters.com".toLowerCase() &&
      password === "M1cr050ft#1!"
    ) {
      dispatch(login());
    }
  };
  return (
    <div className={`${styles.loginBackground} page-container`}>
      <SecureRedirect></SecureRedirect>
      <div className={styles.dialogue}>
        <TextField
          className={styles.input}
          placeholder="Username"
          type="username"
          styles={buttonStyles}
          onChange={onUsernameChange}
          value={username}
        />
        <TextField
          className={styles.input}
          type="password"
          placeholder="Password"
          styles={buttonStyles}
          onChange={onPasswordChange}
          value={password}
        />
        <div
          className={`${styles.button} ${styles.login}`}
          onClick={checkLogin}
        >
          LOG IN
        </div>
        <div className={`${styles.button} ${styles.signup}`}>SIGN UP</div>
      </div>
    </div>
  );
}

export default Login;
