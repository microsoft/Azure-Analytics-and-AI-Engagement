import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./CampaignReport.module.css";
import { PowerbiServiceInstance, EmbedType } from "../../powerbi.service";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";

function CampaignReport() {
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const campaignReportId = "e8e73000-6e30-4795-a75d-3d37323d5ac1";
  const powerbiService = PowerbiServiceInstance;

  const width = 1920;
  const height = 1280;

  useEffect(() => {
    if (dashboardLoading) {
      return;
    }

    setDashboardLoading(true);
    try {
      powerbiService.load(campaignReportId, {
        type: EmbedType.Report,
        elementId: campaignReportId,
        height: height,
        width,
      });
    } catch (error) {
      setDashboardLoading(false);
    }
  }, [dashboardLoading, powerbiService]);
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.CampaignReport}></Header>
      <Navbar type={PageType.CampaignReport} />
      <div
        id={campaignReportId}
        className={styles.campaign + " dashboard"}
        style={{
          width: "calc(100% - 48px)",
          height: "calc(100% - 54px)",
        }}
      ></div>
    </div>
  );
}

export default CampaignReport;
