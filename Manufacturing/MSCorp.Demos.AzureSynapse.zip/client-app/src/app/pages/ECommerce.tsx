import React from "react";
import Navbar from "../features/navbar/navbar";
import Header, { PageType } from "../features/header/header";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import styles from "./ECommerce.module.css";

export type ECommerceProps = {
  override?: boolean;
};

const ECommerce = (props: ECommerceProps) => {
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header
        type={props.override ? PageType.ECommerce2 : PageType.ECommerce}
      ></Header>
      <Navbar
        type={props.override ? PageType.ECommerce2 : PageType.ECommerce}
      />
      <iframe
        src="https://c2cwwi08.azurewebsites.net/"
        className={styles.eCommerceFrame}
        sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox"
        title="Online Store"
      ></iframe>
    </div>
  );
};

export default ECommerce;
