import React from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./PowerAppsReport.module.css";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";

function PowerAppsReport() {
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.PowerApps}></Header>
      <Navbar type={PageType.PowerApps} />
      <div id="scalable-wrapper" className="page-container">
        <div id="content" className="content">
          <div className={styles.title}>Mobile Experience Using Power Apps</div>
          <div className={styles.leftCover} />
          <div className={styles.rightCover} />
          <iframe
            src="https://apps.powerapps.com/play/27c40aec-1645-4c1a-8a32-c9375df74679?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a"
            className={styles.iframe}
          ></iframe>
        </div>
      </div>
    </div>
  );
}

export default PowerAppsReport;
