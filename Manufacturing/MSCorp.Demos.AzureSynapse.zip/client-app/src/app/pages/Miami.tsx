import React from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./Miami.module.css";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

function Miami() {
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.Miami}></Header>
      <Navbar type={PageType.Miami} />
      <div
        id="scalable-wrapper"
        className={`content-container ${styles.container}`}
      >
        <div id="content" className="content">
          <div className={`pulsating-circle ${styles.plane}`}>
            <img
              className={styles.animatedIcon}
              src={`${BlobBase}miami_plane.gif`}
              alt=""
            />
          </div>
          <div className={`pulsating-circle ${styles.boat}`}>
            <img
              className={styles.animatedIcon}
              src={`${BlobBase}miami_boat.gif`}
              alt=""
            />
          </div>
          <div className={`pulsating-circle ${styles.f1}`}>
            <a href="#/MiamiMap">
              <img
                className={styles.animatedIcon}
                src={`${BlobBase}miami_f1.gif`}
                alt=""
              />
            </a>
          </div>
          <div className={`pulsating-circle ${styles.car}`}>
            <a href="#/MiamiMap">
              <img
                className={styles.animatedIcon}
                src={`${BlobBase}miami_car.gif`}
                alt=""
              />
            </a>
          </div>
          <div className={`pulsating-circle ${styles.truck}`}>
            <img
              className={styles.animatedIcon}
              src={`${BlobBase}miami_truck.gif`}
              alt=""
            />
          </div>
          <img
            className={styles.background}
            src={`${BlobBase}network_image.png`}
            alt=""
          />
        </div>
      </div>
    </div>
  );
}

export default Miami;
