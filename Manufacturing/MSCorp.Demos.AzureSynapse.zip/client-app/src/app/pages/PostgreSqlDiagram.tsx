import React, { useState } from "react";
import styles from "./PostgreSqlDiagram.module.css";
import Navbar from "../features/navbar/navbar";
import Header, { PageType } from "../features/header/header";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

enum DiagramScreen {
  Hyper,
  ERP,
  POS
}

const PostgreSqlDiagram = () => {
  const [page, setPage] = useState(DiagramScreen.Hyper);

  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.Diagram3}></Header>
      <Navbar type={PageType.Diagram3} />
      <div className={styles.background}>
        <div className={styles.buttons}>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.Hyper && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.Hyper)}
          >
            Hyperscale
          </div>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.ERP && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.ERP)}
          >
            ERP Data Sync
          </div>
          <div
            className={`${styles.button} ${
              page === DiagramScreen.POS && styles.selected
            }`}
            onClick={() => setPage(DiagramScreen.POS)}
          >
            POS Data Sync
          </div>
        </div>
        <div className={styles.diagramContainer}>
          <img
            className={styles.diagram}
            src={`${BlobBase}${
              page === DiagramScreen.Hyper
                ? "postgresArch-hyper"
                : page === DiagramScreen.ERP
                ? "Oracle_ERP_Data"
                : page === DiagramScreen.POS
                ? "Realtime_POS_Sales"
                : ""
            }.gif`}
            alt=""
          />
        </div>
      </div>
    </div>
  );
};

export default PostgreSqlDiagram;
