import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./AfterDashboard.module.css";
import { PowerbiServiceInstance, EmbedType } from "../../powerbi.service";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

export type PostgreSQLDashboardProps = {
    dashboardId: string;
    type: PageType;
}

function PostgreSqlDashboardAfter(props: PostgreSQLDashboardProps) {
  const [dashboardLoading, setDashboardLoading] = useState(false);

  const powerbiService = PowerbiServiceInstance;

  const width = 1920;
  const height = 1280;

  useEffect(() => {
    if (dashboardLoading) {
      return;
    }
    setDashboardLoading(true);
    try {
      powerbiService.load(props.dashboardId, {
        type: EmbedType.Dashboard,
        elementId: props.dashboardId,
        height: height,
        width,
      });
    } catch (error) {
      setDashboardLoading(false);
    }
  }, [dashboardLoading, powerbiService]);
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={props.type}></Header>
      <Navbar type={props.type} />
      {/* <div
        id={props.dashboardId}
        className={styles.finance + " dashboard"}
        style={{
          width: "calc(100% - 48px)",
          height: "calc(100% - 54px)",
        }}
      ></div> */}
      <div className={styles.background} style={{paddingRight: '20px'}}>
        <div className={`${styles.diagramContainer} ${styles.example}`}>
          <img
            className={styles.diagram}
            src={`${BlobBase}${"postgresql_after.gif?a="}${Math.random()}`}
            alt=""
          />
        </div>
      </div>
    </div>
  );
}

export default PostgreSqlDashboardAfter;
