import React, { useEffect, useState, useRef } from "react";
import Header, { PageType } from "../features/header/header";
import { EmbedType, PowerbiServiceInstance } from "../../powerbi.service";
import styles from "./Machine.module.css";
import VolumeController from "../features/volume-controller/volume-controller";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";
import Popup from "../features/popup/popup";
import Card, { CardTitle } from "../features/card/card";

enum ProdQualDegradPopup {
  With,
  Without,
  Introducing,
  HowWorks,
  Architecture,
}

function Machine() {
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [showVideoWorker, setShowVideoWorker] = useState(false);
  const [showHololensVideo, setshowHololensVideo] = useState(false);
  const [showVideoPPE, setShowVideoPPE] = useState(false);
  const [showProductDefect, setshowProductDefect] = useState(false);
  const [htapReportLoaded, setHtapReportLoaded] = useState(false);
  const [
    showProductQualityDegradation,
    setShowProductQualityDegradation,
  ] = useState(false);
  const [showPredictiveMaintenance, setShowPredictiveMaintenance] = useState(
    false
  );
  const [mute, setMute] = useState(true);
  const [volume, setVolume] = useState(0.02);
  const [ProdQualDegradPage, setProdQualDegradPage] = useState(
    ProdQualDegradPopup.Without
  );
  const video = useRef<HTMLVideoElement>(null);
  const safetyVideo = useRef<HTMLVideoElement>(null);

  const reportId = "525f3fab-3c17-4223-8c5e-2bdff2e27ef1";
  const vibrations = "ReportSection8f78bb77c041cc954390";
  const movements = "ReportSection66a414177b81ec5e9996";
  const temperature = "ReportSectiond9ce432c4ebc9150bd34";

  const anomolyReportID = "a8ac25dc-6c75-486d-970e-feddb9d0d6fb";
  const anomolyReportSection = "ReportSection070fb616c2ef645c8fc6";

  const htapReportID = "a0ddd8a2-fa67-4d18-97f5-bb747e73adb4";
  const withoutHtapReportSection = "ReportSectiond43e6b760e62282b78b3";
  const withHtapReportSection = "ReportSection3ba7c19440a924a246cb";

  const powerbiService = PowerbiServiceInstance;

  const width = 27.3125;
  const height = 15.5;
  const heightShort = 10.1875;
  const noMargin = 0;

  const anomolyWidth = 1630;
  const anomolyHeight = 750;

  const htapWidth = 1764;
  const htapHeight = 700;

  const pageTitle = "Equipment View";
  const subPageTitle = "Global / Miami / Machine 12";

  useEffect(() => {
    if (dashboardLoading) {
      return;
    }

    setDashboardLoading(true);
    try {
      powerbiService.load(reportId, {
        type: EmbedType.Report,
        elementId: vibrations,
        height: heightShort,
        width,
        pageName: vibrations,
      });
      powerbiService.load(reportId, {
        type: EmbedType.Report,
        elementId: movements,
        height,
        width,
        pageName: movements,
      });
      powerbiService.load(reportId, {
        type: EmbedType.Report,
        elementId: temperature,
        height: heightShort,
        width: width,
        pageName: temperature,
      });
      powerbiService.load(anomolyReportID, {
        type: EmbedType.Report,
        elementId: anomolyReportSection,
        height: anomolyHeight,
        width: anomolyWidth,
        pageName: anomolyReportSection,
      });
      powerbiService.load(htapReportID, {
        type: EmbedType.Report,
        elementId: htapReportID,
        height: htapHeight,
        width: htapWidth,
        pageName: withoutHtapReportSection,
        onRendered: () => {
          setHtapReportLoaded(true);
        },
      });
    } catch (error) {
      setDashboardLoading(false);
    }
  }, [dashboardLoading, powerbiService]);

  useEffect(() => {
    let refreshTimer = setInterval(() => {
      try {
        powerbiService.refresh(temperature);
        powerbiService.refresh(vibrations);
        powerbiService.refresh(movements);
      } catch (error) {}
    }, 15000);
    return () => clearInterval(refreshTimer);
  });

  useEffect(() => {
    video.current!.muted = mute;
  }, [mute]);

  useEffect(() => {
    if (!htapReportLoaded) {
      return;
    }
    if (ProdQualDegradPage === ProdQualDegradPopup.With) {
      powerbiService.switchPage(htapReportID, withHtapReportSection);
    }
    if (ProdQualDegradPage === ProdQualDegradPopup.Without) {
      powerbiService.switchPage(htapReportID, withoutHtapReportSection);
    }
  }, [ProdQualDegradPage, htapReportLoaded]);

  const updateVolume = () => {
    video.current!.volume = volume;
  };
  useEffect(updateVolume, [volume]);

  return (
    <div
      className={`${styles.machine} page-container`}
      style={{
        backgroundImage: `url("${BlobBase}Machine1_background.png")`,
      }}
    >
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.Machine}></Header>
      <Navbar type={PageType.Machine} />
      <div id="scalable-wrapper" className={styles.machinePageContainer}>
        <div id="content" className="content">
          <div className={styles.grid}>
            <div className={`${styles.titleArea} `}>
              <h1 className={styles.pageTitle}>{pageTitle}</h1>
              <h4 className={styles.subPageTitle}>{subPageTitle} </h4>
            </div>
            <div className={styles.assetArea}>
              <Card title={CardTitle.asset}>
                <a href="#/global-bing">
                  {" "}
                  <img
                    className={styles.NavigationButton}
                    src={`${BlobBase}icon_arrow.png`}
                    alt="navigation button"
                  />
                </a>
                <div className={styles.cardInnerContainer}>
                  <img
                    className={styles.machineImageDevice}
                    src={`${BlobBase}machine_image_device.png`}
                    alt="machine type"
                    onClick={() => setshowHololensVideo(true)}
                  />
                  <div className={styles.assetButtonContainer}>
                    <div className={styles.assetButtonItem}>
                      <img
                        src={`${BlobBase}machine_button_start.png`}
                        alt="background"
                      />
                      <p>Remote Start</p>
                    </div>
                    <div className={styles.assetButtonItem}>
                      <img
                        src={`${BlobBase}machine_button_stop.png`}
                        alt="background"
                      />
                      <p>Remote Stop</p>
                    </div>
                    <div className={styles.assetButtonItem}>
                      <img
                        src={`${BlobBase}machine_button_reset.png`}
                        alt="background"
                      />
                      <p>Fault Reset</p>
                    </div>
                    <div className={styles.assetButtonItem}>
                      <img
                        src={`${BlobBase}machine_button_camera.png`}
                        alt="background"
                      />
                      <p>Camera</p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
            <div className={styles.innerGridAlertsAreaTemperatureArea}>
              <Card title={CardTitle.alerts}>
                <div className={styles.cardInnerContainer}>
                  <div
                    className={styles.cardInnerItem}
                    onClick={() => setshowProductDefect(true)}
                  >
                    Product Defect Rate Spike
                    <img
                      src={`${BlobBase}alert-red.jpg`}
                      alt="red alert icon"
                    />
                  </div>
                  <div
                    className={styles.cardInnerItem}
                    onClick={() => setShowVideoPPE(true)}
                  >
                    PPE Compliance Alert
                    <img
                      src={`${BlobBase}alert-red.jpg`}
                      alt="red alert icon"
                    />
                  </div>
                  <div
                    className={styles.cardInnerItem}
                    onClick={() => setShowProductQualityDegradation(true)}
                  >
                    Production Quality Degradation
                    <img src={`${BlobBase}alert-red.jpg`} alt="red alert" />
                  </div>
                  <div
                    className={styles.cardInnerItem}
                    onClick={() => setShowVideoWorker(true)}
                  >
                    Occupational Safety Hazard
                    <img
                      src={`${BlobBase}alert-amber.jpg`}
                      alt="amber alert icon"
                    />
                  </div>
                </div>
              </Card>
              <Card title={CardTitle.temperature}>
                <div
                  id={temperature}
                  className={styles.cardInnerContainer + " report show"}
                  style={{
                    width: width + "rem",
                    height: heightShort + "rem",
                    right: noMargin + "rem",
                  }}
                ></div>
              </Card>
            </div>
            <div className={styles.liveFeedArea}>
              <Card title={CardTitle.liveFeed}>
                <div className={styles.videoContainer}>
                  <video
                    ref={video}
                    src={BlobBase + "Machine.mp4"}
                    autoPlay
                    preload="auto"
                    muted
                    playsInline
                    onLoadStart={updateVolume}
                    controlsList="nodownload"
                    loop
                    className={styles["machine-video"]}
                  ></video>
                </div>
                <div className={styles.volumeController}>
                  <VolumeController
                    onMuteChange={(newValue: boolean) => {
                      setMute(newValue);
                    }}
                    onVolumeChange={(value: number) => {
                      setVolume(value);
                    }}
                    mute={mute}
                    volume={volume}
                  />
                </div>
              </Card>
            </div>
            <div className={styles.overviewArea}>
              <Card title={CardTitle.overview}>
                <div className={styles.cardInnerContainer}>
                  <div
                    className={`${styles.cardInnerItem} ${styles.overviewItem}`}
                  >
                    <p>Device Name</p>
                    <p>XorTech Lathe Machine ST_20 - 042</p>
                  </div>
                  <div
                    className={`${styles.cardInnerItem} ${styles.overviewItem}`}
                  >
                    <p>Device Type</p>
                    <p>XorTech Lathe Machine</p>
                  </div>
                  <div
                    className={`${styles.cardInnerItem} ${styles.overviewItem}`}
                  >
                    <p>Device Sub Type</p>
                    <p>ST_20</p>
                  </div>
                  <div
                    className={`${styles.cardInnerItem} ${styles.overviewItem}`}
                  >
                    <p>Make</p>
                    <p>Worthington</p>
                  </div>
                  <div
                    className={`${styles.cardInnerItem} ${styles.overviewItem}`}
                  >
                    <p>Connection Status</p>
                    <p>Running</p>
                  </div>
                </div>
              </Card>
            </div>
            <div className={styles.jobAxesMovementArea}>
              <Card title={CardTitle.jobAxesMovement}>
                <div
                  id={movements}
                  className={styles.cardInnerContainer + " report show"}
                  style={{
                    width: width + "rem",
                    height: height + "rem",
                    right: noMargin + "rem",
                  }}
                ></div>
              </Card>
            </div>
            <div className={styles.machineVibrationArea}>
              <Card title={CardTitle.machineVibration}>
                <div
                  id={vibrations}
                  className={styles.cardInnerContainer + " report show"}
                  style={{
                    width: width + "rem",
                    height: height + "rem",
                    right: noMargin + "rem",
                  }}
                ></div>
              </Card>
            </div>
            <div className={styles.maintenanceSchedulingArea}>
              <Card title={CardTitle.maintenanceScheduling}>
                <div className={styles.cardInnerContainer}>
                  <div className={styles.cardInnerItem}>
                    <p>03/13/2020</p>
                    <p>Routine Maintenance</p>
                  </div>
                  <div className={styles.cardInnerItem}>
                    <p>01/05/2020</p>
                    <p>Replaced Tool</p>
                  </div>
                  <div
                    className={`${styles.cardInnerItem} ${styles.predMainText}`}
                    onClick={() => setShowPredictiveMaintenance(true)}
                  >
                    Predictive Maintenance
                    <img
                      className={styles.predictiveMaintenanceOverlayButton}
                      src={`${BlobBase}alert-red.jpg`}
                      alt="red alert icon"
                    />
                  </div>
                  <div className={styles.cardInnerItem}>
                    <p>Recommendation</p>
                    <p>
                      Replace{" "}
                      <span className={styles.orange}> speed controller </span>
                      within
                      <span className={styles.orange}> 7 days </span>
                    </p>
                  </div>
                  <div className={styles.cardInnerItem}>
                    <p>Risk</p>
                    <p className={styles.red}>Fire Hazard</p>
                  </div>
                  <div
                    className={`${styles.cardInnerItem} ${styles.customLineHeight}`}
                  >
                    <p>Description</p>
                    <p className={styles.maintenanceDescription}>
                      PdM module had identified a{" "}
                      <span className={styles.orange}>
                        {" "}
                        speed variation anomaly{" "}
                      </span>
                      that can result in overheating and possibly a fire
                    </p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
      {showVideoWorker && (
        <Popup
          banner="Occupational Safety Hazard"
          onPopupDismiss={() => {
            setShowVideoWorker(false);
          }}
        >
          <img
            src={`${BlobBase}machine_VideoWorker.jpg`}
            alt="Worker who demonstrates occupational safety hazard"
            className={`${styles.occupationalSafetyHazard} ${styles.popupContent}`}
          />
        </Popup>
      )}
      ,
      {showHololensVideo && (
        <Popup
          banner="Damage Alert"
          onPopupDismiss={() => {
            setshowHololensVideo(false);
          }}
        >
          <div className={`${styles.popupContentContainer}`}>
            <video
              ref={safetyVideo}
              src={BlobBase + "Machine Maintenance Demo.mp4"}
              preload="auto"
              controls
              playsInline
              controlsList="nodownload"
              onLoadStart={() => {
                if (!safetyVideo || !safetyVideo.current) {
                  return;
                }
                safetyVideo.current.volume = 0.05;
              }}
              className={`${styles.popupContent} `}
            ></video>
          </div>
        </Popup>
      )}
      ,
      {showVideoPPE && (
        <Popup
          banner="PPE Compliance Alert"
          onPopupDismiss={() => {
            setShowVideoPPE(false);
          }}
        >
          <div className={`${styles.popupContentContainer}`}>
            <video
              ref={safetyVideo}
              src={BlobBase + "factory_safety_video.mp4"}
              preload="auto"
              controls
              playsInline
              controlsList="nodownload"
              onLoadStart={() => {
                if (!safetyVideo || !safetyVideo.current) {
                  return;
                }
                safetyVideo.current.volume = 0.05;
              }}
              className={`${styles.popupContent} `}
            ></video>
          </div>
        </Popup>
      )}
      {showPredictiveMaintenance && (
        <Popup
          banner="Predictive Maintenance"
          onPopupDismiss={() => {
            setShowPredictiveMaintenance(false);
          }}
        >
          <div className={`${styles.popupContentContainer}`}>
            <img
              src={`${BlobBase}predictive_maintenance.png`}
              alt="Predictive maintenance"
              className={`${styles.popupContent}`}
            />
          </div>
        </Popup>
      )}
      <div className={`${styles.hide} ${showProductDefect && styles.show}`}>
        <Popup
          banner="Product Defect Rate Spike"
          onPopupDismiss={() => {
            setshowProductDefect(false);
          }}
        >
          <div className={`${styles.stretch} ${styles.popupContentContainer}`}>
            <div
              id={anomolyReportSection}
              className={`${styles.popupContent} `}
            ></div>
          </div>
        </Popup>
      </div>
      <div
        className={`${styles.hide} ${
          showProductQualityDegradation && styles.show
        }`}
      >
        <Popup
          banner="Product Quality Degradation"
          onPopupDismiss={() => {
            setProdQualDegradPage(ProdQualDegradPopup.Without);
            setShowProductQualityDegradation(false);
          }}
        >
          <div className={styles.buttons}>
            <div
              className={`${styles.button} ${
                ProdQualDegradPage === ProdQualDegradPopup.Without &&
                styles.selected
              }`}
              onClick={() => setProdQualDegradPage(ProdQualDegradPopup.Without)}
            >
              Without Azure Synapse Link
            </div>
            <div
              className={`${styles.button} ${
                ProdQualDegradPage === ProdQualDegradPopup.Introducing &&
                styles.selected
              }`}
              onClick={() =>
                setProdQualDegradPage(ProdQualDegradPopup.Introducing)
              }
            >
              Introducing Azure Synapse Link
            </div>
            <div
              className={`${styles.button} ${
                ProdQualDegradPage === ProdQualDegradPopup.With &&
                styles.selected
              }`}
              onClick={() => setProdQualDegradPage(ProdQualDegradPopup.With)}
            >
              With Azure Synapse Link
            </div>
            <div
              className={`${styles.button} ${
                ProdQualDegradPage === ProdQualDegradPopup.HowWorks &&
                styles.selected
              }`}
              onClick={() =>
                setProdQualDegradPage(ProdQualDegradPopup.HowWorks)
              }
            >
              How Azure Synapse Link works
            </div>
            <div
              className={`${styles.button} ${
                ProdQualDegradPage === ProdQualDegradPopup.Architecture &&
                styles.selected
              }`}
              onClick={() =>
                setProdQualDegradPage(ProdQualDegradPopup.Architecture)
              }
            >
              Architecture
            </div>
          </div>
          <div className={`${styles.popupContentContainer} ${styles.stretch}`}>
            <div
              id={htapReportID}
              className={`${
                ProdQualDegradPage !== ProdQualDegradPopup.With &&
                ProdQualDegradPage !== ProdQualDegradPopup.Without &&
                styles.offLoad
              } ${styles.popupContent}`}
            ></div>
            {ProdQualDegradPage === ProdQualDegradPopup.Architecture && (
              <img
                src={`${BlobBase}htap-architecture.jpg`}
                className={`${styles.popupContent}`}
                alt="Architecture system diagram"
              />
            )}
            {ProdQualDegradPage === ProdQualDegradPopup.Introducing && (
              <img
                id="introducingGif"
                src={`${BlobBase}synapse-link.gif` + "?a=" + Math.random()}
                className={`${styles.popupContent}`}
              />
            )}
            {ProdQualDegradPage === ProdQualDegradPopup.HowWorks && (
              <video
                src={BlobBase + "How-Synapse-Link-Works.mp4"}
                autoPlay
                preload="auto"
                controls
                playsInline
                controlsList="nodownload"
                className={`${styles.popupContent} `}
              ></video>
            )}
          </div>
        </Popup>
      </div>
    </div>
  );
}

export default Machine;
