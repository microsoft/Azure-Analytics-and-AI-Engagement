import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./MiamiMap.module.css";
import Navbar from "../features/navbar/navbar";
import { useHistory } from "react-router-dom";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { BlobBase } from "../../constants";

function MiamiMap() {
  const [started, setStarted] = useState(false);
  const history = useHistory();

  useEffect(() => {
    if (started) {
      return;
    }
    setTimeout(() => {
      const carLocation = new window.Microsoft.Maps.Location(
        25.949959,
        -80.120752
      );

      const navigationHelperCarLocation = new window.Microsoft.Maps.Location(25.949741, -80.120454);
      const navigationHelperCarLocationIcon = new Microsoft.Maps.Pushpin(navigationHelperCarLocation, {
        icon: BlobBase + "icon_arrow.png",
      });

      const floridaLocation = new window.Microsoft.Maps.Location(
        26.949959,
        -80.120752
      );

      const navigationHelperFloridaLocation = new Microsoft.Maps.Location(28.7,-80.53900);
      const navigationHelperFloridaLocationIcon = new Microsoft.Maps.Pushpin(navigationHelperFloridaLocation, {
        icon: BlobBase + "icon_arrow.png",
      });

      const navigationHelperRaceTrackLocation = new Microsoft.Maps.Location( 29.186,-81.0624);
      const navigationHelperRaceTrackLocationIcon = new Microsoft.Maps.Pushpin(navigationHelperRaceTrackLocation, {
        icon: BlobBase + "icon_arrow.png",
      });

      const carIcon = new Microsoft.Maps.Pushpin(carLocation, {
        icon: BlobBase + "miami_car.gif",
      });
      const f1Location = new window.Microsoft.Maps.Location(
        29.184956,
        -81.073952
      );
      const racetrackLocation = new window.Microsoft.Maps.Location(
        29.184956,
        -81.068952
      );
      const f1Icon = new Microsoft.Maps.Pushpin(f1Location, {
        icon: BlobBase + "miami_f1.gif",
      });
      const f1VideoLocation = new window.Microsoft.Maps.Location(
        29.186904,
        -81.063308
      );
      const f1VideoIcon = new Microsoft.Maps.Pushpin(f1VideoLocation, {
        icon: BlobBase + "miamimap_icon_blue_car.png",
      });
      var map: Microsoft.Maps.Map = new (window.Microsoft as any).Maps.Map(
        "#bingMap",
        {
          credentials:
            "Avu0REbv3O6zKm6nSTAXp1QEHRKSsW1Txn0cvPpdeworlOt_1g1AvIa8ZvDDOhz3",
          center: carLocation,
          zoom: 18,
          mapTypeId: window.Microsoft.Maps.MapTypeId.aerial,
        }
      );
      map.entities.add(carIcon);
      map.entities.add(f1Icon);
      map.entities.add(f1VideoIcon);
      map.entities.add(navigationHelperCarLocationIcon);
      map.entities.add(navigationHelperFloridaLocationIcon);
      map.entities.add(navigationHelperRaceTrackLocationIcon);
      
      Microsoft.Maps.Events.addHandler(f1VideoIcon, "click", () => {
        history.push("/MiamiVideo");
      });
      Microsoft.Maps.Events.addHandler(carIcon, "click", () => {
        map.setView({
          center: floridaLocation,
          zoom: 7,
          mapTypeId: window.Microsoft.Maps.MapTypeId.aerial,
        });
      });
      Microsoft.Maps.Events.addHandler(f1Icon, "click", () => {
        map.setView({
          center: racetrackLocation,
          zoom: 16,
          mapTypeId: window.Microsoft.Maps.MapTypeId.aerial,
        });
      });
    }, 500);
    setStarted(true);
  }, [started]);
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.MiamiMap}></Header>
      <Navbar type={PageType.MiamiMap} />
      <div id="bingMap" className={styles.map}></div>
    </div>
  );
}

export default MiamiMap;
