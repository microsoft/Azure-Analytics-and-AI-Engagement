import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./AfterDashboard.module.css";
import { PowerbiServiceInstance, EmbedType } from "../../powerbi.service";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";
import { useHistory } from "react-router-dom";
//BELOW TEMP import TO BE REMOVED relates to flashing issue
import { BlobBase } from "../../constants";

function AfterDashboard() {
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [navigateAway, setNavigateAway] = useState(false);
  const history = useHistory();

  const finance = "0b0436f0-cc27-4f56-9a6d-dfd21d5a7800";

  const powerbiService = PowerbiServiceInstance;

  const width = 1920;
  const height = 1280;

  // need to use effect to navigate, as window effects from iframe powerbi cause post message propblems
  useEffect(() => {
    if (navigateAway) {
      history.push("/campaign-report");
    }
  }, [navigateAway]);

  useEffect(() => {
    if (dashboardLoading) {
      return;
    }

    setDashboardLoading(true);
    try {
      powerbiService.load(finance, {
        type: EmbedType.Dashboard,
        elementId: finance,
        height: height,
        width,
        onClick: () => setNavigateAway(true),
      });
    } catch (error) {
      setDashboardLoading(false);
    }
  }, [dashboardLoading, powerbiService]);
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.AfterDashboard}></Header>
      <Navbar type={PageType.AfterDashboard} />
      {/* <div
        id={finance}
        className={styles.finance + " dashboard"}
        style={{
          width: "calc(100% - 48px)",
          height: "calc(100% - 54px)",
        }}
      ></div> */}
       {/* Below to be removed = flashing issue */}
       <div className={styles.background} style={{paddingRight: '20px'}}>
        <div className={`${styles.diagramContainer} ${styles.example}`}>
          <img
            className={styles.diagram}
            src={`${BlobBase}${"executive_dashboard_embedded.gif?a="}${Math.random()}`}
            alt=""
          />
        </div>
      </div>
    </div>
  );
}

export default AfterDashboard;
