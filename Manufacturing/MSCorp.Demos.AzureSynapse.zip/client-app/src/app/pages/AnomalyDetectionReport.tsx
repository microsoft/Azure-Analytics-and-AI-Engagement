import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./GlobalSafetyDashboard.module.css";
import { PowerbiServiceInstance, EmbedType } from "../../powerbi.service";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";

function AnomalyDetectionReport() {
  const [dashboardLoading, setDashboardLoading] = useState(false);

  const reportid = "a8ac25dc-6c75-486d-970e-feddb9d0d6fb";
  const reportSection = "ReportSection8c0113f3a1305bd11440";

  const powerbiService = PowerbiServiceInstance;

  const width = 1920;
  const height = 1280;

  useEffect(() => {
    if (dashboardLoading) {
      return;
    }

    setDashboardLoading(true);
    try {
      powerbiService.load(reportid, {
        type: EmbedType.Report,
        elementId: reportid,
        height: height,
        width,
        pageName: reportSection
      });
    } catch (error) {
      setDashboardLoading(false);
    }
  }, [dashboardLoading, powerbiService]);
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.AnomalyDetection}></Header>
      <Navbar type={PageType.AnomalyDetection} />
      <div
        id={reportid}
        className={styles.pwer + " dashboard"}
        style={{
          width: "calc(100% - 48px)",
          height: "calc(100% - 54px)",
        }}
      ></div>
    </div>
  );
}

export default AnomalyDetectionReport;
