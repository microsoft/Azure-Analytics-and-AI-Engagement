import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./FormRecognizer.module.css";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";

// @ts-ignore 
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
// @ts-ignore 
import 'react-tabs/style/react-tabs.css';

// @ts-ignore 
import { Document, Page, pdfjs } from "react-pdf";
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;


function FormRecognizer() {

    return (
        <div className="">
            <SecureRedirect></SecureRedirect>
            <Header type={PageType.FormRecognizer}></Header>
            <Navbar type={PageType.FormRecognizer} />
            <div id="" className="page-container">
                <div className={styles.mainer}>
                    <Tabs>
                        <TabList>
                            <Tab>Handwritten Form</Tab>
                            <Tab>Translated Form</Tab>
                            <Tab>Image Form</Tab>
                            <Tab>PDF Form</Tab>
                            
                        </TabList>
                        <TabPanel>
                            <h2>Handwritten Form</h2>
                            <div className="row">
                                <div className={styles.colhalf} style={{ marginRight: '20px' }}>
                                    <embed src="https://stcognitivesearch001.blob.core.windows.net/incidentreport/hdwrt_9285601250.pdf#zoom=80,80,200" width="640" height="770" type="application/pdf" role="presentation"></embed>
                                </div>
                                <div className={styles.colhalf2}>
                                    <h3>JSON</h3>
                                    <code>
                                        &#123;<br />
                                        "employer": "Wide World Importers",<br />
                                        "event": "Ladder fell on employee",<br />
                                        "location": "Rio de Janeiro",<br />
                                        "nature": "fractured skull",<br />
                                        "part_of_body": "skull",<br />
                                        "event_date": "8/22/2019",<br />
                                        "final_narrative": "Fracture in skull . Ladder fell on employee",<br />
                                        "caseid": "9285601250",<br />
                                        "source": "ladder",<br />
                                        "amputation": null,<br />
                                        "hospitalized": null<br />
                                        &#125;<br />
                                    </code>
                                </div>
                            </div>
                        </TabPanel>
                        <TabPanel>
                            
                            <h2>Translated Form</h2>
                            <div className="row">
                                <div className={styles.colhalf} style={{ marginRight: '20px' }}>
                                    <embed src="https://stcognitivesearch001.blob.core.windows.net/incidentreport/pt_202081083.pdf#zoom=100,80,200" width="640" height="770" type="application/pdf" role="presentation"></embed>
                                </div>
                                <div className={styles.colhalf2}>
                                    <h3>JSON</h3>
                                    <code>
                                        &#123;<br />
                                        "Nature":"burns",<br />
                                        "Hospitalization":"1",<br />
                                        "Location":"Rio de Janeiro",<br />
                                        "Amputation":"0",<br />
                                        "EventTitle":"Contact with hot objects or substances",<br />
                                        "Employer ":" WideWorldImporters ",<br />
                                        " CaseId ":" 202081083 ",<br />
                                        " Final_Narrative ":" An employee was placing hot rubberized asphalt when he sneezed and burned the employee's left wrist. ",<br />
                                        " Event_Date ":" 8/20/2019 ",<br />
                                        "Source":"roofs",<br />
                                        "part_of_body":"wrists and elbows"<br />
                                        &#125; <br/>
                                    </code>
                                </div>
                            </div>
                            
                        </TabPanel>
                        <TabPanel>
                            <h2>Form Image(JPG)</h2>
                            <div className="row">
                                <div className={styles.colhalf} style={{ marginRight: '20px' }}>
                                    <img src="https://stcognitivesearch001.blob.core.windows.net/incidentreport/202046643.jpg" width="640" height="auto"></img>
                                </div>
                                <div className={styles.colhalf2}>
                                    <h3>JSON</h3>
                                    <code>
                                        &#123;<br />
                                        "hospitalized":"1",<br />
                                        "amputation":"1",<br />
                                        "location":"Rio de Janeiro",<br />
                                        "event_date":"3/25/2015",<br />
                                        "caseid":"202046643",<br />
                                        "employer":"Wide World Importers",<br />
                                        "source":"presses",<br />
                                        "event":"Compressed or pinched between two stationary objects",<br />
                                        "final_narrative":"An employee was injured when his left leg got <br />caught between the truss press and the table. The employee sustained a left leg amputation from the knee down.",
                                        "part_of_body":"legs",<br />
                                        "nature":"amputations",<br />
                                        "form_url":"https://stcognitivesearch001.blob<br />.core.windows.net/formupload/202046643.jpg"<br />
                                        &#125;<br />
                                    </code>
                                </div>
                            </div>
                        </TabPanel>
                        <TabPanel>
                            <h2>PDF Form</h2>
                            <div className="row">
                                <div className={styles.colhalf} style={{marginRight:'20px'}}>
                                    <embed src="https://stcognitivesearch001.blob.core.windows.net/incidentreport/202046643.pdf#zoom=100,80,200" width="640" height="500" type="application/pdf" role="presentation"></embed>
                                </div>
                                <div className={styles.colhalf2}>
                                    <h3>JSON</h3>
                                    <code>
                                        &#123;<br />
                                            "hospitalized":"1",<br />
                                            "amputation":"1",<br />
                                            "location":"Rio de Janeiro",<br />
                                            "event_date":"3/25/2015",<br />
                                            "caseid":"202046643",<br/>
                                            "employer":"Wide World Importers",<br />
                                            "source":"presses",<br />
                                            "event":"Compressed or pinched between two stationary objects",<br />
                                            "final_narrative":"An employee was injured when his left leg got caught between<br /> the truss press and the table. The employee sustained a left leg amputation from the knee down.",
                                            "part_of_body":"legs",<br />
                                            "nature":"amputations",<br />
                                            "form_url":"https://stcognitivesearch001.blob<br />
                                            .core.windows.net/formupload/202046643.pdf"<br />
                                        &#125;<br />
                                        </code>
                                </div>
                            </div>
                            
                        </TabPanel>
                        
                    </Tabs>
                    
                </div>
            </div>
        </div>
    );
}

export default FormRecognizer;
