import React, { useState, useEffect } from "react";
import Header, { PageType } from "../features/header/header";
import styles from "./GlobalSafetyDashboard.module.css";
import { PowerbiServiceInstance, EmbedType } from "../../powerbi.service";
import Navbar from "../features/navbar/navbar";
import SecureRedirect from "../features/secure-redirect/secure-redirect";

function SafetyDashboard() {
  const [dashboardLoading, setDashboardLoading] = useState(false);

  const reportid = "010b8ad3-4d64-420f-b2aa-c4f8a0d8e8ee";
  const reportSection = "ReportSectionff14e21bdad140901345";

  const powerbiService = PowerbiServiceInstance;

  const width = 1920;
  const height = 1280;

  useEffect(() => {
    if (dashboardLoading) {
      return;
    }

    setDashboardLoading(true);
    try {
      powerbiService.load(reportid, {
        type: EmbedType.Report,
        elementId: reportid,
        height: height,
        width,
        pageName: reportSection
      });
    } catch (error) {
      setDashboardLoading(false);
    }
  }, [dashboardLoading, powerbiService]);
  return (
    <div className="page-container">
      <SecureRedirect></SecureRedirect>
      <Header type={PageType.Globalsafetydashboard}></Header>
      <Navbar type={PageType.Globalsafetydashboard} />
      <div
        id={reportid}
        className={styles.pwer + " dashboard"}
        style={{
          width: "calc(100% - 48px)",
          height: "calc(100% - 54px)",
        }}
      ></div>
    </div>
  );
}

export default SafetyDashboard;
