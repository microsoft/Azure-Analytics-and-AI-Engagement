import { combineReducers } from "redux";
import { connectRouter } from "connected-react-router";
import { History } from "history";
import loginReducer from "./reducers/loginReducer";
import mobileReducer from "./reducers/mobileReducer";

const createRootReducer = (history: History<any>) =>
  combineReducers({
    router: connectRouter(history),
    loginReducer,
    mobileReducer,
  });
export default createRootReducer;
