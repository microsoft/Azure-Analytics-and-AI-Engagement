import { useState, useRef, useEffect } from "react";

const recursiveParentCheck = (e: any, context: any): boolean => {
  if (!e) {
    return false;
  }

  if (e == context) {
    return true;
  }
  return recursiveParentCheck(e.parentNode, context);
};

export function useHover(): any {
  const [value, setValue] = useState(false);

  const ref = useRef(null);

  const isHoverOverChild = (e: any, context: any) => {
    // Over engineered? ಠ_ಠ
    try {
      return recursiveParentCheck(e, context);
    } catch (error) {}
    return false;
  };

  const handleMouseOver = () => setValue(true);
  const handleMouseOut = (event: any) => {
    var e = event.toElement || event.relatedTarget;
    if (!isHoverOverChild(e, ref.current)) {
      setValue(false);
    }
  };

  useEffect(
    () => {
      const node: any = ref.current;

      if (node) {
        node.addEventListener("mouseenter", handleMouseOver);
        node.addEventListener("mouseout", handleMouseOut);

        return () => {
          node.removeEventListener("mouseenter", handleMouseOver);
          node.removeEventListener("mouseout", handleMouseOut);
        };
      }
    },
    [ref.current] // Recall only if ref changes
  );

  return [ref, value];
}
