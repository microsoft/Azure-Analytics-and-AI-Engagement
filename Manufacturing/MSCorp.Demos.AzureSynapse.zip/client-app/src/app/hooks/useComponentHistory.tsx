import React, { useEffect } from 'react'
import { useDispatch } from 'react-redux';
import { addHistory } from "../reducers/loginReducer";

export default function useComponentHistory(route: string) {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(addHistory(route));
    },[]);
}
