import { useState, useEffect } from "react";
/**
 * This useBreakpoint is a custom hook we are using to handle CSS breakpoints within React.
 * The reasons are because we are using blob API and we can’t dynamically change the hardcoded URL in CSS. 
 * Also the hook avoids side-effects created in CSS during the React rendering process.
 * More can be found at this link: https://medium.com/better-programming/how-to-use-media-queries-programmatically-in-react-4d6562c3bc97
 * @param queries is an object containing string key + value pairs.
 * The key is a string name for the value, which is a string representing the media query condition.
 */
type Matches = { [key: string]: boolean }; 
const useBreakpoint = (queries: { [key: string]: string } ): Matches => {
    const [queryMatch, setQueryMatch] = useState<Matches>({});
  
    useEffect(() => {
      /*An empty object is initialised to be used to recieve the MediaQueryList object.
      The matchMedia method returns a MediaQueryList object, 
      representing the parsed results of the specified media query.*/
      const mediaQueryLists: { [key: string]: MediaQueryList } = {};

      const keys: string[] = Object.keys(queries);//need to understand better objects given to keys method returns string array?
      
      // To check whether event listener is attached or not
      let isAttached = false;
  
      const handleQueryListener = () => {
        const updatedMatches = keys.reduce((acc: any, media: string) => {//acc stands for accumulator?
          acc[media] = mediaQueryLists[media]?.matches ?? false;
          // acc[media] = !!(mediaQueryLists[media] && mediaQueryLists[media].matches);//This line I do not understand
          return acc;
        }, {})
        console.dir(updatedMatches);
        //Setting state to the updated matches when document either starts or stops matching a query
        setQueryMatch(updatedMatches)
      }
  //This condition is also confusing for me to understand
      if (window && window.matchMedia) {
        const matches: Matches = {};
        keys.forEach(key => {
          // if the value in the object `queries` at index `key` is a string, continue
          const query = queries[key];
          if (typeof query === 'string') {
            /*The matchMedia method returns a MediaQueryList object, 
            representing the parsed results of the specified media query.
            NOTE: The below two lines I struggle to read*/
            //if type of each value is string then give value to matchMedia.
            //This returns ???? string
            mediaQueryLists[key] = window.matchMedia(query);
            //Assign parsed string?? to new matches object at place of media key
            matches[key] = mediaQueryLists[key].matches
          } else {
            //else assign false as value for the media in the matches object (casting as boolean)?
            matches[key] = false
          }
        });
        //Setting state to initial matching queries
        setQueryMatch(matches);
        //For indicating an event listener is attached
        isAttached = true;
        //Looping through the keys string array with forEach loop
        keys.forEach(media => {
          //For each value, run function in ascending order. If it is string then add the listener we have defined above
          if(typeof queries[media] === 'string') {
            mediaQueryLists[media].addListener(handleQueryListener);
          }
        });
      }
  
      return () => {
      //If event listener is attached then remove it when deps (BEVAN: what is deps??) change
        if(isAttached) {
          keys.forEach(media => {
            if(typeof queries[media] === 'string') {
              mediaQueryLists[media].removeListener(handleQueryListener);
            }
          });
        }
      }
    }, [queries]);//Need to understand why this is here? For comparison to updated matches?
  
    return queryMatch;
  }
  
  export default useBreakpoint;