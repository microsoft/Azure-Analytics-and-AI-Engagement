import { useHistory, useLocation } from "react-router-dom";
import { Redirect } from "react-router";
import React, { useEffect } from "react";
import {
  loggedInSelector,
  componentHistorySelector,
} from "../../reducers/loginReducer";
import { useSelector } from "react-redux";
import useComponentHistory from "../../hooks/useComponentHistory";

function SecureRedirect() {
  const loggedIn = useSelector(loggedInSelector);
  const componentHistory = useSelector(componentHistorySelector);
  const history = useHistory();

  useComponentHistory(history.location.pathname);
  if (loggedIn && history.location.pathname === "/login") {
    let previousComponents = [...componentHistory].filter(
      (x) => x !== "/login"
    );
    if (previousComponents.length > 0) {
      return (
        <Redirect
          to={previousComponents[previousComponents.length - 1]}
        ></Redirect>
      );
    }
    return <Redirect to="/ecommerce"></Redirect>;
  }

  const loginRedirect: boolean = JSON.parse(
    `${process.env.REACT_APP_LOGIN_REDIRECT}`
  );

  if (!loginRedirect) {
    return null;
  }

  if (!loggedIn) {
    return <Redirect to="/login"></Redirect>;
  }
  return null;
}

export default SecureRedirect;
