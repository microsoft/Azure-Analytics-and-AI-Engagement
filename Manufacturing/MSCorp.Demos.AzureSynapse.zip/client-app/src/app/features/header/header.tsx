import React from "react";
import styles from "./header.module.css";
import { BlobBase } from "../../../constants";

export enum PageType {
  Miami,
  Global,
  GlobalBing,
  Factory,
  Machine,
  MiamiMap,
  MiamiVideo,
  Field,
  RioDeJaneiro,
  PowerApps,
  Finance,
  AfterDashboard,
  CampaignReport,
  Diagram,
  Diagram2,
  Diagram3,
  IncidentSearch,
  Globalsafetydashboard,
  AnomalyDetection,
  FormRecognizer,
  ECommerce,
  ECommerce2,
  IaasVideo,
  PSSqlDashboardBefore,
  PSSqlDashboardAfter,
  PSSqlDashboardDuring,
  SalesCampaignReportPreMigration,
  SalesCampaignReportPostMigration,
  PSSqlRetailMap,
  PSSQLVideo,
  RaceTrackVideo
}

export interface IPageProp {
  type: PageType;
}

function Header(prop: IPageProp) {
  const type = prop.type;

  let personaPath;

  switch (type) {
    case PageType.ECommerce:
    case PageType.ECommerce2:
    case PageType.Miami:
    case PageType.MiamiMap:
    case PageType.MiamiVideo:
    case PageType.RioDeJaneiro:
      personaPath = "persona_April_VP_Sales.jpg";
      break;
    case PageType.GlobalBing:
    case PageType.Global:
    case PageType.Factory:
    case PageType.Field:
      personaPath = "persona_Spencer_VP_Operations.jpg";
      break;
    case PageType.Machine:
    case PageType.PSSqlRetailMap:
    case PageType.Diagram3:
    case PageType.PSSqlDashboardBefore:
    case PageType.PSSqlDashboardAfter:
    case PageType.PSSqlDashboardDuring:
    case PageType.PSSQLVideo:
      personaPath = "persona_Miguel.jpg";
      break;
    case PageType.Finance:
    case PageType.AfterDashboard:
    case PageType.CampaignReport:
    case PageType.SalesCampaignReportPreMigration:
    case PageType.SalesCampaignReportPostMigration:
    case PageType.Diagram:
    case PageType.IncidentSearch:
    case PageType.Globalsafetydashboard:
    case PageType.Diagram2:
    case PageType.RaceTrackVideo:
    case PageType.FormRecognizer:
    case PageType.AnomalyDetection:
      personaPath = "persona_Wendy_Business_Analyst.jpg";
      break;
    default:
      break;
  }

  return (
    <div
      className={styles.header}
      style={{ backgroundImage: `url("${BlobBase}header_background.png")` }}
    >
      <a href="#/ecommerce">
        <div className={styles.logo}>
          <img src={`${BlobBase}header_WWI_logo.png`} alt="Company logo" />
        </div>
      </a>
      <a href="#/ecommerce">
        <div className={styles.logo}>
          <img src={`${BlobBase}header_WWI_title.png`} alt="Company logo" />
        </div>
      </a>
      <div className={`${styles.button} ${styles.right}`}>
        <img src={`${BlobBase}header_icon_search.png`} alt="Search" />
      </div>
      <div className={styles.button}>
        <img src={`${BlobBase}header_icon_alert.png`} alt="Company logo" />
      </div>
      <div className={styles.button}>
        <img src={`${BlobBase}header_icon_settings.png`} alt="Company logo" />
      </div>
      <div className={styles.button}>
        <img className={styles.persona} src={BlobBase + personaPath} alt="" />
      </div>
    </div>
  );
}

export default Header;
