import React, { FunctionComponent } from "react";
import styles from "./card.module.css";
import { BlobBase } from "../../../constants";

export enum CardTitle {
  asset = "Asset",
  alerts = "Alerts",
  temperature = "Temperature (°F)",
  liveFeed = "Live Feed",
  overview = "Overview",
  jobAxesMovement = "Job Axes Movement",
  machineVibration = "Machine Vibration",
  maintenanceScheduling = "Maintenance Scheduling",
}

export interface ICardTitle {
  title: CardTitle;
}

const Card: FunctionComponent<ICardTitle> = ({ title, children }) => {
  
  return (
    <div className={styles.card}>
      <div className={styles.cardTitleContainer}>
        <img
          className={styles.cardTitleBackground}
          src={`${BlobBase}factory_card_title_texture.png`}
          alt=""
        />
        <div className={styles.text}>
          <h2>{title}</h2>
        </div>
      </div>
      {children}
    </div>
  );
};

export default Card;
