import React, { useState } from "react";
import styles from "./navbar.module.css";
import { IPageProp, PageType } from "../header/header";
import { BlobBase } from "../../../constants";
import NavbarItem from "./navbarItem";
import NavbarGroup from "./navbarGroup";

const Navbar = (prop: IPageProp) => {
  const [expandMenu, setExpandMenu] = useState(false);
  const [expandCognitiveMenu, setExpandCognitiveMenu] = useState(false);
  const [expandExecDash, setExpandExecDash] = useState(false);
  const [expandTdm, setExpandTdm] = useState(false);
  const [expandSqlMigration, setExpandSqlMigration] = useState(false);
  const [expandPostgres, setExpandPostgres] = useState(false);
  const [expandIot, setExpandIot] = useState(false);
  const [expandStore, setExpandStore] = useState(false);

  const clearAllExpand = () => {
    setExpandStore(false);
    setExpandTdm(false);
    setExpandSqlMigration(false);
    setExpandExecDash(false);
    setExpandCognitiveMenu(false);
    setExpandPostgres(false);
    setExpandIot(false);
  };

  return (
    <div
      className={styles.nav}
      style={{ backgroundImage: `url("${BlobBase}navbar_background.png")` }}
    >
      <NavbarItem
        imgSrc="navbar_icon_menu.png"
        expanded={expandMenu}
        currentPage={false}
        onClick={() => {
          setExpandMenu(!expandMenu);
        }}
      />
      <NavbarGroup
        imgSrc="icon_retail.png"
        title="Online Store"
        expanded={expandStore || expandMenu}
        toggleExpand={() => {
          clearAllExpand();
          setExpandStore(!expandStore);
        }}
        currentPage={prop.type === PageType.ECommerce}
      >
        <NavbarItem
          href="#/ecommerce"
          imgSrc="icon_retail.png"
          title="Online Store"
          expanded={true}
          currentPage={prop.type === PageType.ECommerce}
        />
        <NavbarItem
          href="https://c2cwwi08.azurewebsites.net/"
          imgSrc="icon_retail.png"
          title="Online Store - New Tab"
          expanded={true}
          currentPage={false}
          targetExternalPage={true}
        />
      </NavbarGroup>
      <NavbarGroup
        imgSrc="navbar_icon_home.png"
        title="Executive Dashboards - May"
        expanded={expandStore || expandMenu}
        toggleExpand={() => {
          clearAllExpand();
          setExpandStore(!expandStore);
        }}
        currentPage={prop.type === PageType.Finance}
      >
        <NavbarItem
          href="#/finance"
          imgSrc="navbar_icon_home.png"
          title="Executive Dashboard - Embedded"
          expanded={true}
          currentPage={prop.type === PageType.Finance}
        />
        <NavbarItem
          href="https://app.powerbi.com/groups/4292532e-bd79-4004-a7cc-a78977685b59/dashboards/04854839-2bbf-4cf9-98cf-29d77048db5d"
          imgSrc="navbar_icon_home.png"
          title="Executive Dashboard - New Tab"
          expanded={true}
          currentPage={false}
          targetExternalPage={true}
        />
      </NavbarGroup>
      <NavbarGroup
        imgSrc="navbar_icon_network.png"
        title="IoT Network"
        expanded={expandIot || expandMenu}
        toggleExpand={() => {
          clearAllExpand();
          setExpandIot(!expandIot);
        }}
        currentPage={
          prop.type === PageType.MiamiMap ||
          prop.type === PageType.MiamiVideo ||
          prop.type === PageType.Miami
        }
      >
        <NavbarItem
          href="#/miami"
          imgSrc="navbar_icon_network.png"
          title="IoT Network"
          expanded={true}
          currentPage={prop.type === PageType.Miami}
        />

        <NavbarItem
          href="#/MiamiMap"
          imgSrc="navbar_icon_bing.png"
          title="Location via Bing"
          expanded={true}
          currentPage={prop.type === PageType.MiamiMap}
        />
        <NavbarItem
          href="#/MiamiVideo"
          imgSrc="navbar_icon_track.png"
          title="On the Racetrack"
          expanded={true}
          currentPage={prop.type === PageType.MiamiVideo}
        />
      </NavbarGroup>
      <NavbarItem
        href="#/global-bing"
        imgSrc="navbar_icon_global.png"
        title="Global Operations Overview"
        expanded={expandMenu}
        currentPage={prop.type === PageType.GlobalBing}
      />
      <NavbarItem
        href="#/factory"
        imgSrc="navbar_icon_factory.png"
        title="Miami Factory Overview"
        expanded={expandMenu}
        currentPage={prop.type === PageType.Factory}
      />
      <NavbarItem
        href="#/machine"
        imgSrc="navbar_icon_machine.png"
        title="Equipment View"
        expanded={expandMenu}
        currentPage={prop.type === PageType.Machine}
      />
      <NavbarItem
        href="#/diagram"
        imgSrc="navbar_icon_diagram.png"
        title="Architecture"
        expanded={expandMenu}
        currentPage={prop.type === PageType.Diagram}
      />
      <NavbarItem
        href="#/field"
        imgSrc="navbar_icon_racecar.png"
        title="Driver safety using Hololens"
        expanded={expandMenu}
        currentPage={prop.type === PageType.Field}
      />
      <NavbarGroup
        imgSrc="navbar_icon_chart.png"
        title="Executive Dashboard – August"
        expanded={expandExecDash || expandMenu}
        currentPage={prop.type === PageType.AfterDashboard}
        toggleExpand={() => {
          clearAllExpand();
          setExpandExecDash(!expandExecDash);
        }}
      >
        <NavbarItem
          href="#/afterdashboard"
          imgSrc="navbar_icon_chart.png"
          title="Executive Dashboard – Embedded"
          expanded={true}
          currentPage={prop.type === PageType.AfterDashboard}
        />
        <NavbarItem
          href="https://app.powerbi.com/groups/4292532e-bd79-4004-a7cc-a78977685b59/dashboards/0b0436f0-cc27-4f56-9a6d-dfd21d5a7800"
          imgSrc="navbar_icon_chart.png"
          title="Executive Dashboard – New Tab"
          expanded={true}
          targetExternalPage={true}
          currentPage={false}
        />
        <NavbarItem
          href="https://app.powerbi.com/groups/4292532e-bd79-4004-a7cc-a78977685b59/reports/e8e73000-6e30-4795-a75d-3d37323d5ac1"
          imgSrc="navbar_icon_chart.png"
          title="Campaign Report - New Tab"
          expanded={true}
          targetExternalPage={true}
          currentPage={false}
        />
      </NavbarGroup>
      <NavbarGroup
        imgSrc="icon_KMCS.png"
        title="Safety Incidents Insights"
        expanded={expandCognitiveMenu || expandMenu}
        toggleExpand={() => {
          clearAllExpand();
          setExpandCognitiveMenu(!expandCognitiveMenu);
        }}
        currentPage={
          prop.type === PageType.IncidentSearch ||
          prop.type === PageType.Globalsafetydashboard ||
          prop.type === PageType.FormRecognizer ||
          prop.type === PageType.AnomalyDetection
        }
      >
        <NavbarItem
          href="#/anomaly-detection-report"
          imgSrc="icon_pbi.png"
          title="Safety & Quality Report"
          expanded={true}
          currentPage={prop.type === PageType.AnomalyDetection}
        />
        <NavbarItem
          href="#/globalsafetydashboard"
          imgSrc="dashboard_icon.png"
          title="Safety Incident Report"
          expanded={true}
          currentPage={prop.type === PageType.Globalsafetydashboard}
        />
        <NavbarItem
          href="#/formrecognizer"
          imgSrc="dashboard_icon.png"
          title="Azure Form Recognizer "
          expanded={true}
          currentPage={prop.type === PageType.FormRecognizer}
        />
        <NavbarItem
          href="#/incident-search"
          imgSrc="search_icon.png"
          title="Accident Search "
          expanded={true}
          currentPage={prop.type === PageType.IncidentSearch}
        />
      </NavbarGroup>

      <NavbarItem
        href="#/rio-de-janeiro"
        imgSrc="navbar_icon_sth_america.png"
        title="Predictive Maintenance in Rio"
        expanded={expandMenu}
        currentPage={prop.type === PageType.RioDeJaneiro}
      />

      <NavbarItem
        href="#/powerApps"
        imgSrc="navbar_icon_powerapps.png"
        title="Mobile Experience Using Power Apps"
        expanded={expandMenu}
        currentPage={prop.type === PageType.PowerApps}
      />

      <NavbarGroup
        imgSrc="icon_tdm.png"
        title="TDM Analytics & AI Demo"
        expanded={expandTdm || expandMenu}
        currentPage={false}
        toggleExpand={() => {
          clearAllExpand();
          setExpandTdm(!expandTdm);
        }}
      >
        <NavbarItem
          href="https://portal.azure.com/#@CloudLabsAIoutlook.onmicrosoft.com/resource/subscriptions/49d66a68-7c00-43c3-93ae-602ee60e1eb6/resourceGroups/Manufacturing-Demo/providers/Microsoft.Devices/IotHubs/mfg-IoThub/Overview"
          imgSrc="icon_IoT.png"
          title="Azure IoT"
          currentPage={false}
          expanded={true}
          targetExternalPage={true}
        />
        <NavbarItem
          href="https://portal.azure.com/#@CloudLabsAIoutlook.onmicrosoft.com/resource/subscriptions/49d66a68-7c00-43c3-93ae-602ee60e1eb6/resourceGroups/Manufacturing-Demo/providers/Microsoft.DocumentDb/databaseAccounts/cosmosdb-manufacturing-demo/overview"
          imgSrc="icon_cosmos.png"
          title="Azure Cosmos DB"
          currentPage={false}
          expanded={true}
          targetExternalPage={true}
        />
        <NavbarItem
          href="https://web.azuresynapse.net/"
          imgSrc="navbar_icon_synapse.png"
          title="Azure Synapse Analytics"
          currentPage={false}
          expanded={true}
          targetExternalPage={true}
        />
        <NavbarItem
          href="https://ml.azure.com/?wsid=/subscriptions/49d66a68-7c00-43c3-93ae-602ee60e1eb6/resourceGroups/CDP-VISION-DEMO-RG/providers/Microsoft.MachineLearningServices/workspaces/Auto-ML-2"
          imgSrc="icon_ML.png"
          title="Azure Machine Learning"
          currentPage={false}
          expanded={true}
          targetExternalPage={true}
        />
      </NavbarGroup>

      <NavbarGroup
        imgSrc="icon_sql_migration.png"
        title="SQL Migration to Azure"
        expanded={expandSqlMigration || expandMenu}
        toggleExpand={() => {
          clearAllExpand();
          setExpandSqlMigration(!expandSqlMigration);
        }}
        currentPage={
          prop.type === PageType.Diagram2 ||
          prop.type === PageType.ECommerce2 ||
          prop.type === PageType.IaasVideo ||
          prop.type === PageType.SalesCampaignReportPreMigration ||
          prop.type === PageType.SalesCampaignReportPostMigration ||
          prop.type === PageType.RaceTrackVideo
        }
        flip={true}
      >
        <NavbarItem
          href="#/ecommerce2"
          imgSrc="icon_retail.png"
          title="Online Store"
          currentPage={prop.type === PageType.ECommerce2}
          expanded={true}
        />
        <NavbarItem
          href="#/racetrack"
          imgSrc="navbar_icon_track.png"
          title="On the Racetrack"
          expanded={true}
          currentPage={prop.type === PageType.RaceTrackVideo}
        />
        <NavbarItem
          href="#/sales-and-campaign-report-pre"
          imgSrc="icon_pbi.png"
          title="Pre-Migration Report"
          currentPage={prop.type === PageType.SalesCampaignReportPreMigration}
          expanded={true}
        />
        <NavbarItem
          href="#/sales-and-campaign-report-post"
          imgSrc="icon_pbi.png"
          title="Post-Migration Report"
          currentPage={prop.type === PageType.SalesCampaignReportPostMigration}
          expanded={true}
        />
        <NavbarItem
          href="#/sqlDiagram"
          imgSrc="navbar_icon_diagram.png"
          title="Architecture Diagram"
          currentPage={prop.type === PageType.Diagram2}
          expanded={true}
        />
        <NavbarItem
          href="https://manage.cloudlabs.ai/#/odl/b5afa3dd-d194-4d93-8355-474d3a8bf2c6/875a45e2-c7d6-4276-bc14-d779f63d1f73"
          imgSrc="icon_PaaS.png"
          title="Azure Migrate Portal (PaaS)"
          expanded={true}
          targetExternalPage={true}
          currentPage={false}
        />
        <NavbarItem
          href="#/iaasVideo"
          imgSrc="icon_IaaS.png"
          title="Lift and Shift (IaaS)"
          expanded={true}
          currentPage={prop.type === PageType.IaasVideo}
        />
      </NavbarGroup>

      <NavbarGroup
        imgSrc="icon_portgre_sql_migration.png"
        title="PostgreSQL"
        expanded={expandPostgres || expandMenu}
        toggleExpand={() => {
          clearAllExpand();
          setExpandPostgres(!expandPostgres);
        }}
        currentPage={
          prop.type === PageType.Diagram3 ||
          prop.type === PageType.PSSQLVideo ||
          prop.type === PageType.PSSqlRetailMap ||
          prop.type === PageType.PSSqlDashboardAfter ||
          prop.type === PageType.PSSqlDashboardBefore ||
          prop.type === PageType.PSSqlDashboardDuring
        }
        flip={true}
      >
        <NavbarItem
          href="#/postgreSqlRetailMap"
          imgSrc="navbar_icon_global.png"
          title="Retail Map"
          currentPage={prop.type === PageType.PSSqlRetailMap}
          expanded={true}
        />
        <NavbarItem
          href="#/postgreSqlDashboardBefore"
          imgSrc="navbar_icon_chart.png"
          title="Report (Before)"
          currentPage={prop.type === PageType.PSSqlDashboardBefore}
          expanded={true}
        />
        <NavbarItem
          href="https://app.powerbi.com/groups/4292532e-bd79-4004-a7cc-a78977685b59/reports/216b12ce-7aa2-4d31-b281-7f814654da25/ReportSectionf41f31307dc22a4adb9c?noSignUpCheck=1"
          imgSrc="icon_pbi.png"
          title="Report (Before) - New Tab"
          currentPage={false}
          expanded={true}
          targetExternalPage={true}
        />
        <NavbarItem
          href="#/postgreSqlDashboardDuring"
          imgSrc="navbar_icon_chart.png"
          title="Report (During)"
          currentPage={prop.type === PageType.PSSqlDashboardDuring}
          expanded={true}
        />
        <NavbarItem
          href="#/postgreSqlDashboardAfter"
          imgSrc="navbar_icon_chart.png"
          title="Report (After)"
          currentPage={prop.type === PageType.PSSqlDashboardAfter}
          expanded={true}
        />
        <NavbarItem
          href="#/PostgreSqlDiagram"
          imgSrc="navbar_icon_diagram.png"
          title="Architecture"
          currentPage={prop.type === PageType.Diagram3}
          expanded={true}
        />
        <NavbarItem
          href="https://online.visualstudio.com/environment/458bc7bd-1f9a-4962-b3a4-9dc59dd659d1"
          imgSrc="icon_vs_code_space.png"
          title="Visual Studio Codespaces"
          currentPage={false}
          expanded={true}
          targetExternalPage={true}
        />
        <NavbarItem
          href="https://portal.azure.com/#@f94768c8-8714-4abe-8e2d-37a64b18216a/resource/subscriptions/49d66a68-7c00-43c3-93ae-602ee60e1eb6/resourceGroups/Manufacturing-Demo/providers/Microsoft.DBforPostgreSQL/serverGroups/sales-pg-hyperscale-dem/pricingTier"
          imgSrc="icon_portgre_sql_migration.png"
          title="Azure Portal"
          currentPage={false}
          expanded={true}
          targetExternalPage={true}
        />
        <NavbarItem
          href="#/postgreSqlVideo"
          imgSrc="icon_portgre_sql_scaling.png"
          title="PostgreSQL Scaling (Video)"
          currentPage={prop.type === PageType.PSSQLVideo}
          expanded={true}
        />
      </NavbarGroup>
    </div>
  );
};

export default Navbar;
