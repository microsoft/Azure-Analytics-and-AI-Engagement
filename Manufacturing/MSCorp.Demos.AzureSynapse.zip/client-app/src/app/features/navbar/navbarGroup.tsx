import React from "react";
import styles from "./navbar.module.css";
import { BlobBase } from "../../../constants";
import { useHover } from "../../hooks/useHover";

export type NavbarGroupProps = {
  imgSrc: string;
  currentPage: boolean;
  expanded: boolean;
  children: any;
  toggleExpand: (value: boolean) => void;
  flip?: boolean;
  title?: string;
  targetExternalPage?: boolean;
};

const NavbarGroup = (props: NavbarGroupProps) => {
  const [hoverRef, isHovered] = useHover();
  const [submenuHoverRef, isSubmenuHovered] = useHover();
  const expanded = isHovered || isSubmenuHovered;
  return (
    <div
      ref={hoverRef}
      className={`${styles.button} 
      ${isHovered && styles.buttonHover} `}
    >
      <div
        className={`${styles.navImg} 
        ${styles.alignTop} 
        ${isHovered && styles.buttonHover}
        ${props.currentPage && styles.selected}`}
      >
        <img src={`${BlobBase}${props.imgSrc}`} alt="" />
      </div>
      {props.title && (
        <div
          className={`${styles.subMenu} 
          ${props.flip && styles.flipped}
          ${isHovered && styles.buttonHover}
          ${(props.expanded || expanded) && styles.expanded}`}
        >
          <div className={styles.navbarMenuTitle}>{props.title}</div>
          {!props.expanded && expanded && (
            <div ref={submenuHoverRef} className={`${styles.children} `}>
              {props.children}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NavbarGroup;
