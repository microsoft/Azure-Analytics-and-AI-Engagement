import React from "react";
import styles from "./navbar.module.css";
import { BlobBase } from "../../../constants";
import { useHover } from "../../hooks/useHover";

export type NavbarItemProps = {
  href?: string;
  imgSrc: string;
  currentPage: boolean;
  expanded: boolean;
  onClick?: () => void;
  title?: string;
  targetExternalPage?: boolean;
};

const NavbarItem = (props: NavbarItemProps) => {
  const [hoverRef, isHovered] = useHover();
  let href = props.href ? { href: props.href } : {};

  return (
    <a
      {...href}
      ref={hoverRef}
      className={`${styles.button} 
      ${props.expanded && styles.expanded} 
      ${isHovered && styles.notSelected} `}
      onClick={() => {
        if (props.onClick) {
          props.onClick();
        }
      }}
      target={`${props.targetExternalPage ? "_blank" : "_self"}`}
    >
      <div
        className={`${styles.navImg}
        ${props.currentPage && styles.selected}`}
      >
        <img src={`${BlobBase}${props.imgSrc}`} alt="" />
      </div>
      {props.title && (
        <div
          className={`${styles.titleContainer} 
          ${isHovered && styles.buttonHover} 
          ${(props.expanded || isHovered) && styles.expanded}`}
        >
          <div
            className={`${styles.navbarMenuTitle}
          ${props.currentPage && styles.selected} `}
          >
            {props.title}
          </div>
        </div>
      )}
    </a>
  );
};

export default NavbarItem;
