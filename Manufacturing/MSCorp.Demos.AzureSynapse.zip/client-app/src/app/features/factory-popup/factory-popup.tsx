import React, { useEffect, useState, useRef } from "react";
import styles from "./factory-popup.module.css";
import VolumeController from "../volume-controller/volume-controller";
import Popup from "../popup/popup";
import { BlobBase } from "../../../constants";

enum PopupPage {
  Map,
  Heatmap,
  Camera,
}

interface IFactoryPopupProps {
  onPopupDismiss(): void;
}

const FactoryPopup = (props: IFactoryPopupProps) => {
  const [alarmOn, setAlarmOn] = useState(false);
  const [page, setPage] = useState(PopupPage.Map);
  const [mute, setMute] = useState(true);
  const [volume, setVolume] = useState(0.05);
  const video = useRef<HTMLVideoElement>(null);
  const factoryAudioRef = useRef<HTMLAudioElement>(null);
  const alarmAudioRef = useRef<HTMLAudioElement>(null);
  const factoryVideo = BlobBase + "factory_safety_video.mp4";
  const heatmapVideo = BlobBase + "heatmap.mp4";
  const audioFactoryAlarm = BlobBase + "audio_factory_alarm.mp3";
  const audioFactoryWav = BlobBase + "audio_factory.wav";
  const bannerTitle = "Factory";

  const updateVolume = () => {
    if (factoryAudioRef && factoryAudioRef.current) {
      factoryAudioRef.current.volume = volume;
    }
    if (alarmAudioRef && alarmAudioRef.current) {
      alarmAudioRef.current.volume = volume;
    }
  };

  useEffect(updateVolume, [volume]);

  return (
    <Popup banner={bannerTitle} onPopupDismiss={props.onPopupDismiss}>
      <>
        <div className={styles.buttons}>
          <div
            className={`${styles.button} ${
              page === PopupPage.Map && styles.selected
            }`}
            onClick={() => setPage(PopupPage.Map)}
          >
            Alerts
          </div>
          <div
            className={`${styles.button} ${
              page === PopupPage.Heatmap && styles.selected
            }`}
            onClick={() => setPage(PopupPage.Heatmap)}
          >
            Heatmap
          </div>
        </div>
        {page === PopupPage.Map && (
          <div className={styles.content}>
            <a href="#/machine" className={styles.alertMachine}></a>
            <img
              className={styles.animation}
              src={`${BlobBase}factory_alerts.gif`}
              onClick={() => {
                if (mute) {
                  return;
                }
                setAlarmOn(!alarmOn);
              }}
            />
            <div className={styles.volumeController}>
              <VolumeController
                onMuteChange={(newValue: boolean) => {
                  setMute(newValue);
                }}
                onVolumeChange={(value: number) => {
                  setVolume(value);
                }}
                mute={mute}
                volume={volume}
              />
            </div>
            {!mute && (
              <div>
                <audio
                  ref={factoryAudioRef}
                  autoPlay
                  loop
                  preload="auto"
                  onLoadStart={updateVolume}
                  src={audioFactoryWav}
                ></audio>
                {alarmOn && (
                  <audio
                    ref={alarmAudioRef}
                    autoPlay
                    preload="auto"
                    loop
                    onLoadStart={updateVolume}
                    src={audioFactoryAlarm}
                  ></audio>
                )}
              </div>
            )}
          </div>
        )}
        {page === PopupPage.Heatmap && (
          <div className={styles.content}>
            <video
              src={heatmapVideo}
              preload="auto"
              playsInline
              loop
              autoPlay
              muted
              controlsList="nodownload"
              className={styles.animation}
            ></video>
          </div>
        )}
        {page === PopupPage.Camera && (
          <div className={styles.content}>
            <video
              ref={video}
              src={factoryVideo}
              controls
              preload="auto"
              playsInline
              controlsList="nodownload"
              onLoadStart={() => {
                if (!video || !video.current) {
                  return;
                }
                video.current.volume = 0.05;
              }}
              className={styles.animation}
            ></video>
          </div>
        )}
      </>
    </Popup>
  );
};

export default FactoryPopup;
