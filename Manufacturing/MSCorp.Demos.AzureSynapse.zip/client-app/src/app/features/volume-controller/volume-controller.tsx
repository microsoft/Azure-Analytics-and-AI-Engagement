import React from "react";
import styles from "./volume-controller.module.css";
import { Slider } from "office-ui-fabric-react/lib/Slider";

export interface IVolumeControllerLevel {
  volume: number;
  mute: boolean;
  onMuteChange(isMute: boolean): void;
  onVolumeChange(volume: number): void;
}

function VolumeController(props: IVolumeControllerLevel) {
  function getVolumeSliderValue(value: any) {
    props.onVolumeChange(value / 100);
  }

  let sliderStyle = {
    activeSection: { backgroundColor: "grey !important" },
  };

  return (
    <div className={styles.position}>
      <div
        className={styles.mute}
        onClick={() => {
          props.onMuteChange(!props.mute);
        }}
      >
        {props.mute ? "" : ""}
      </div>
      <Slider
        min={0}
        max={100}
        step={5}
        defaultValue={20}
        showValue={false}
        value={props.volume * 100}
        onChange={getVolumeSliderValue}
        styles={sliderStyle}
      />
    </div>
  );
}

export default VolumeController;
