import React from "react";
import styles from "./popup.module.css";
import { BlobBase } from "../../../constants";

interface IPopupProps {
  banner: string;
  onPopupDismiss: () => void;
}

const Popup: React.FC<IPopupProps> = ({ banner, onPopupDismiss, children }) => {
  return (
    <>
      <div className={styles.popup}>
        <h3
          className={styles.banner}
          style={{
            backgroundImage: `url("${BlobBase}factory_card_title_texture.png")`,
          }}
        >
          {banner}
        </h3>
        <div
          className={`${styles.dismiss} ${styles.button}`}
          onClick={onPopupDismiss}
        >
          
        </div>
        {children}
      </div>
      <div className={styles.cover}></div>
    </>
  );
};

export default Popup;
