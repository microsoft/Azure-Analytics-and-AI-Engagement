using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;

namespace server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StoresController : ControllerBase
    {
        string connString = "Data Source=(DESCRIPTION="
                             + "(ADDRESS=(PROTOCOL = TCP)(HOST = 52.149.38.86)(PORT = 1521))"
                             + "(CONNECT_DATA=(SERVER = DEDICATED)(SERVICE_NAME = oranoncdb.zvd5xqx5u12eppswob4m4gr2zg.xx.internal.cloudapp.net)));"
                             + "User Id=SYSTEM;Password=Newuser#54321;";



        OracleConnection con;
        OracleCommand cmd;
        OracleDataReader dr;
        private static readonly int InitialCount = 925;
        [HttpGet]
        public IEnumerable<List<StoreModel>> Get()
        {
            List<StoreModel> storeModels = new List<StoreModel>();
            using (con = new OracleConnection(connString))
            {
                try
                {
                    string cmdStr = "select * from SALES.\"store\" order by STOREID desc fetch first 10 rows only";
                    //string cmdStr = "PRC_SELECT_STORE";
                    using (cmd = new OracleCommand(cmdStr, con))
                    {
                        cmd.Connection.Open();
                        //cmd.CommandType = CommandType.StoredProcedure;
                        dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            storeModels.Add(new StoreModel { StoreID = Convert.ToInt32(dr[0].ToString()), StoreName = dr[1].ToString(), StoreType = dr[2].ToString(), Address = dr[3].ToString(), Country = dr[4].ToString(), Latitude = dr[5].ToString(), Longitude = dr[6].ToString(), City = dr[7].ToString() });
                        }
                        cmd.Connection.Close();
                    }
                }
                catch (OracleException ex)
                {
                    switch (ex.Number)
                    {
                        case 1:
                            Response.WriteAsync("Error attempting to insert duplicate data.");
                            break;
                        case 12545:
                            Response.WriteAsync("The database is unavailable.");
                            break;
                        default:
                            Response.WriteAsync("Database error: " + ex.Message.ToString());
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Response.WriteAsync(ex.Message.ToString());
                }
            }
            yield return storeModels;
        }
        [HttpPost]
        public void Add(StoreModel storeModels)
        {
            using (con = new OracleConnection(connString))
            {
                try
                {
                    string cmdStr = "Insert into SALES.\"store\" (STOREID,STORENAME,STORETYPE,ADDRESS,COUNTRY,LATITUDE,LONGITUDE,CITY) Values ('" + storeModels.StoreID + "','" + storeModels.StoreName + "','" + storeModels.StoreType + "','" + storeModels.Address + "','" + storeModels.Country + "','" + storeModels.Latitude + "','" + storeModels.Longitude + "','" + storeModels.City + "')";
                    //string cmdStr = "sp_Name";
                    using (cmd = new OracleCommand(cmdStr, con))
                    {
                        cmd.Connection.Open();
                        //cmd.CommandType = CommandType.StoredProcedure;
                        int flag = cmd.ExecuteNonQuery();
                        if (flag > 0)
                        {
                            Response.WriteAsync("Store details added successfully!");
                        }
                        cmd.Connection.Close();
                    }
                }
                catch (OracleException ex)
                {
                    switch (ex.Number)
                    {
                        case 1:
                            Response.WriteAsync("Error attempting to insert duplicate data.");
                            break;
                        case 12545:
                            Response.WriteAsync("The database is unavailable.");
                            break;
                        default:
                            Response.WriteAsync("Database error: " + ex.Message.ToString());
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Response.WriteAsync(ex.Message.ToString());
                }
            }
        }
        [HttpDelete]
        public void Remove()
        {
            //List<int> storeList = new List<int>();
            using (con = new OracleConnection(connString))
            {
                try
                {
                    string cmdStr = "Delete from SALES.\"store\" where STOREID Not IN (Select STOREID from SALES.\"store\" order by STOREID fetch first '" + InitialCount + "' rows only)";
                    //string cmdStr = "sp_Name";
                    using (cmd = new OracleCommand(cmdStr, con))
                    {
                        cmd.Connection.Open();
                        //cmd.CommandType = CommandType.StoredProcedure;
                        int flag = cmd.ExecuteNonQuery();
                        if (flag > 0)
                        {
                            Response.WriteAsync("Store details removed successfully!");
                        }
                        else
                        {
                            Response.WriteAsync("Recent details is not available!");
                        }
                        cmd.Connection.Close();
                    }
                }
                catch (OracleException ex)
                {
                    switch (ex.Number)
                    {
                        case 1:
                            Response.WriteAsync("Error attempting to insert duplicate data.");
                            break;
                        case 12545:
                            Response.WriteAsync("The database is unavailable.");
                            break;
                        default:
                            Response.WriteAsync("Database error: " + ex.Message.ToString());
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Response.WriteAsync(ex.Message.ToString());
                }
            }

        }
    }
}
