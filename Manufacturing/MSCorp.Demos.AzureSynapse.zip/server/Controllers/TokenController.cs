﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace server.Controllers
{
    [Route("api/[controller]")]
    public class TokenController : Controller
    {
        private static AzureAdTokenResponse aadToken;
        private static Dictionary<string, EmbededToken> embedTokenCache = new Dictionary<string, EmbededToken>();
        private static string baseUrl = "https://api.powerbi.com/v1.0/myorg/groups/4292532e-bd79-4004-a7cc-a78977685b59";

        private static HttpRequestMessage FormRequest(string type, string id, bool editMode)
        {
            string tokenEndpointUri = "";

            if (type == "report")
            {
                tokenEndpointUri = $"{baseUrl}/reports/{id}/GenerateToken";
            }
            else if (type == "dashboard")
            {
                tokenEndpointUri = $"{baseUrl}/dashboards/{id}/GenerateToken";
            }
            else if (type == "qna")
            {
                tokenEndpointUri = $"{baseUrl}/datasets/{id}/GenerateToken";
            }

            var content = new FormUrlEncodedContent(new[] {
                new KeyValuePair<string, string>("accessLevel", editMode ? "Edit" : "View")
            });

            var request = new HttpRequestMessage()
            {
                RequestUri = new Uri(tokenEndpointUri),
                Method = HttpMethod.Post,
                Content = content
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", aadToken.access_token);
            return request;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        [Route("Embed/{type}/{id}")]
        public async Task<IActionResult> GetEmbedToken(string type, string id, [FromQuery] bool editMode = false)
        {
            if (string.IsNullOrEmpty(type) || string.IsNullOrEmpty(id)) return BadRequest();

            string tokenKey = $"{type}-{id}-{editMode}";
            bool tokenExists = embedTokenCache.ContainsKey(tokenKey);
            if (tokenExists && !string.IsNullOrEmpty(embedTokenCache[tokenKey].token) && !HasEmbedTokenExpired(embedTokenCache[tokenKey]))
            {
                return Ok(embedTokenCache[tokenKey].token);
            }

            if (aadToken == null || aadToken.access_token == null || HasTokenExpired())
            {
                await GetAccessToken();
            }

            using (var client = new HttpClient())
            {
                var request = FormRequest(type, id, editMode);
                var requestContent = await request.Content.ReadAsStringAsync();

                HttpResponseMessage res = await client.SendAsync(request);
                var resContent = await res.Content.ReadAsStringAsync();
                EmbededToken tokenRes = JsonConvert.DeserializeObject<EmbededToken>(resContent);
                if (tokenRes != null && !string.IsNullOrEmpty(tokenRes.token))
                {
                    embedTokenCache[tokenKey] = tokenRes;
                }
                else
                {
                    throw new Exception("invalid access token response", new Exception(
                        $"request: {JsonConvert.SerializeObject(request)},\n requestContent: {requestContent},\n res: {JsonConvert.SerializeObject(res)},\n resContent: {resContent}, \n tokenRes: {JsonConvert.SerializeObject(tokenRes)}"
                    ));
                }

                return Ok(tokenRes.token);
            }
        }

        private bool HasEmbedTokenExpired(EmbededToken token)
        {
            long timeNow = DateTimeOffset.Now.ToUnixTimeSeconds();
            long expireDate = DateTimeOffset.Parse(token.expiration).ToUnixTimeSeconds();
            return timeNow > expireDate;
        }

        private bool HasTokenExpired()
        {
            long timeNow = DateTimeOffset.Now.ToUnixTimeSeconds();
            long expireDate = long.Parse(aadToken.expires_on);
            return timeNow > expireDate;
        }

        [Route("Access")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<string> GetAccessToken()
        {
            string pBiUser = "demo-pbi-user@cloudlabsaioutlook.onmicrosoft.com";
            string pBiPwd = "Fuja74081";
            string pBiClientId = "ff8ded49-99b1-44ef-9f90-6688f02327d4";
            string pBiSecret = "pxPdhwSuEeXLbOgK5ZAmoH4v0ZFeNePWRHPSO1uTt6s=";

            string tokenEndpointUri = "https://login.microsoftonline.com/f94768c8-8714-4abe-8e2d-37a64b18216a/oauth2/token";

            var content = new FormUrlEncodedContent(new[] {
                new KeyValuePair<string, string>("grant_type", "password"),
                new KeyValuePair<string, string>("username", pBiUser),
                new KeyValuePair<string, string>("password", pBiPwd),
                new KeyValuePair<string, string>("client_id", pBiClientId),
                new KeyValuePair<string, string>("client_secret", pBiSecret),
                new KeyValuePair<string, string>("resource", "https://analysis.windows.net/powerbi/api")
            });

            using (var client = new HttpClient())
            {
                HttpResponseMessage res = client.PostAsync(tokenEndpointUri, content).Result;
                string json = await res.Content.ReadAsStringAsync();
                AzureAdTokenResponse tokenRes = JsonConvert.DeserializeObject<AzureAdTokenResponse>(json);
                if (tokenRes == null || string.IsNullOrEmpty(tokenRes.access_token))
                {
                    throw new Exception("invalid access token response");
                }

                aadToken = tokenRes;
                return tokenRes.access_token;
            }
        }
    }

    public class AzureAdTokenResponse
    {
        public string token_type { get; set; }
        public string scope { get; set; }
        public string expires_in { get; set; }
        public string ext_expires_in { get; set; }
        public string expires_on { get; set; }
        public string not_before { get; set; }
        public string resource { get; set; }
        public string access_token { get; set; }
        public string refresh_token { get; set; }
    }

    public class EmbededToken
    {
        public string token { get; set; }
        public string tokenId { get; set; }
        public string expiration { get; set; }
    }
}