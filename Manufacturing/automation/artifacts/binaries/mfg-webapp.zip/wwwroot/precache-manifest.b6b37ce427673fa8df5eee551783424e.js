self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "06ae443dd5239d6dbd601b5f01e8a542",
    "url": "/index.html"
  },
  {
    "revision": "7f63f68b550c28665203",
    "url": "/static/css/2.5c17b9f1.chunk.css"
  },
  {
    "revision": "accfdb88536c56febd84",
    "url": "/static/css/main.73123f61.chunk.css"
  },
  {
    "revision": "7f63f68b550c28665203",
    "url": "/static/js/2.d260f79d.chunk.js"
  },
  {
    "revision": "48381455726b6a2098baefbc7c0fc62a",
    "url": "/static/js/2.d260f79d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "accfdb88536c56febd84",
    "url": "/static/js/main.6c4861b3.chunk.js"
  },
  {
    "revision": "6b7fdcd7cbf592947331",
    "url": "/static/js/runtime-main.0a5d56c1.js"
  }
]);