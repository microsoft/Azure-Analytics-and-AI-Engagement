window['runConfig'] = {
    BlobBaseUrl : "https://manufacturingdemoassets.blob.core.windows.net/webappassets/",

    PSSqlDashboardBefore_ID : '7e9f44c1-4405-480e-8195-85a41022a7b8',
    PSSqlDashboardDuring_ID : '73110aee-e6d1-434e-86f6-e953ccc020c7',
    PSSqlDashboardAfter_ID : '36892896-3444-4073-a841-940c62be64dd',

    // Used in app/pages/AfterDashboard
    AfterDashBoard_ID : "0b0436f0-cc27-4f56-9a6d-dfd21d5a7800",

    // Used in app/pages/AnomalyDetectionReport
    AnomalyDetectionReport_ID : "a8ac25dc-6c75-486d-970e-feddb9d0d6fb",
    AnomalyDetectionReport_NAME : "ReportSection8c0113f3a1305bd11440",

    // Used in app/pages/CampaignReport
    campaignReport_ID : "e8e73000-6e30-4795-a75d-3d37323d5ac1",

    // Used in app/pages/ecommerce
    ecommercIframeSrc: "https://wideworldimporters-mfg.azurewebsites.net/",

    // Used in app/pages/Factory
    fc_reportId : "0ac723ba-6bd5-4ff2-a2c2-450b8c43acd2",
    fc_overview : "ReportSection5691aa74d544b03cf6ed",
    fc_alert : "ReportSectiond6c63aee8dbd98c9083f",
    fc_production : "ReportSection3dc0fc6ef1aebcc543b0",
    fc_oee : "ReportSection948d06cf27c044d540e1",
    fc_downtime : "ReportSectionf756caaa87c195dd397c",
    fc_energyMaintenance : "ReportSection4216d59f0ea336b94ea0",

    // Used in app/pages/Finance
    finance_ID : "04854839-2bbf-4cf9-98cf-29d77048db5d",

    // Used in app/pages/FormRecognizer
    PDFBaseLink : "https://stcognitivesearch001.blob.core.windows.net/incidentreport/",

    // Used in app/pages/GlobalBing
    gb_reportId : "03e8dfe9-8dc3-4e46-a1f4-4251534a9a6f",
    gb_availabilityId : "availabilityReport",
    gb_performanceId : "performanceReport",
    gb_qualityId : "qualityReport",
    gb_availabilityPageName : "ReportSectionc45278bb119aba730003",
    gb_performancePageName : "ReportSection013038b103686d6f9e5b",
    gb_qualityPageName : "ReportSection4c6302695d4e5f295d03",

    // Used in app/pages/globalsafetydashboard : 
    gsd_reportid : "010b8ad3-4d64-420f-b2aa-c4f8a0d8e8ee",
    gsd_reportSection : "ReportSectionff14e21bdad140901345",


    // Used in app/pages/Machine
    mach_reportId : "525f3fab-3c17-4223-8c5e-2bdff2e27ef1",
    mach_vibrations : "ReportSection8f78bb77c041cc954390",
    mach_movements : "ReportSection66a414177b81ec5e9996",
    mach_temperature : "ReportSectiond9ce432c4ebc9150bd34",
    mach_anomolyReportID : "a8ac25dc-6c75-486d-970e-feddb9d0d6fb",
    mach_anomolyReportSection : "ReportSection070fb616c2ef645c8fc6",
    mach_htapReportID : "a0ddd8a2-fa67-4d18-97f5-bb747e73adb4",
    mach_withoutHtapReportSection : "ReportSectiond43e6b760e62282b78b3",
    mach_withHtapReportSection : "ReportSection3ba7c19440a924a246cb",


    // Use in app/pages/SlaesCampaginReportPostMigration
    salesAndCampaign_first : "2aa09e3d-188b-4e63-9334-19d96c0e0951",
    salesAndCampaign_second : "ReportSection811d0856f92253ddb79e",

    // Use in app/pages/PowerApps
    powerAppsSrc : "https://apps.powerapps.com/play/27c40aec-1645-4c1a-8a32-c9375df74679?tenantId=f94768c8-8714-4abe-8e2d-37a64b18216a",

    apiUrl: "https://manufacturing-demo.azure-api.net/demo",

    workspaceId: "4292532e-bd79-4004-a7cc-a78977685b59"
}