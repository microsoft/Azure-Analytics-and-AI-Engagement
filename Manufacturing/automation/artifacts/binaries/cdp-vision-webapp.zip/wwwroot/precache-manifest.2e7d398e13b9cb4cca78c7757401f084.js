self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b19af12e7cc1a32f5b172df6f8f5709e",
    "url": "/index.html"
  },
  {
    "revision": "cb72149700231f745d7f",
    "url": "/static/css/main.a3a2f716.chunk.css"
  },
  {
    "revision": "1241fd4bf3e556757a07",
    "url": "/static/js/2.b9f85aa3.chunk.js"
  },
  {
    "revision": "c342c74b984cd5bd0027b3882c4c044c",
    "url": "/static/js/2.b9f85aa3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cb72149700231f745d7f",
    "url": "/static/js/main.cdc0ecbf.chunk.js"
  },
  {
    "revision": "6b7fdcd7cbf592947331",
    "url": "/static/js/runtime-main.0a5d56c1.js"
  }
]);