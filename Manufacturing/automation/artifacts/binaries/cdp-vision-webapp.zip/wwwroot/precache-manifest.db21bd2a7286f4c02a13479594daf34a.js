self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8715f44a64ea79cec08eafb796db27be",
    "url": "/index.html"
  },
  {
    "revision": "060c87b3e51514c650bf",
    "url": "/static/css/main.a3a2f716.chunk.css"
  },
  {
    "revision": "1241fd4bf3e556757a07",
    "url": "/static/js/2.b9f85aa3.chunk.js"
  },
  {
    "revision": "c342c74b984cd5bd0027b3882c4c044c",
    "url": "/static/js/2.b9f85aa3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "060c87b3e51514c650bf",
    "url": "/static/js/main.361b4518.chunk.js"
  },
  {
    "revision": "6b7fdcd7cbf592947331",
    "url": "/static/js/runtime-main.0a5d56c1.js"
  }
]);