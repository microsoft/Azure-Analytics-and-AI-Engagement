window.config = {
  LogAPI: "https://#POWERBI_SERVER#.azurewebsites.net/ActivityLog/",
  SPEECH_KEY: "#SPEECH_KEY#",
  SPEECH_REGION: "eastus",
  BlobBaseUrl: "https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/",
  IconBlobBaseUrl:
    "https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/",

  APIUrl: "https://#POWERBI_SERVER#.azurewebsites.net",
  BackendAPIUrl: "https://#BACKEND_API_URL#.azurewebsites.net",
  
  StartCallAPI: "https://#FUNC_APP_URL#.azurewebsites.net/api/start_call",
  CUSTOMER_DETAILS_API:
    " https://#FUNC_APP_URL#.azurewebsites.net/api/customerdetails",
  EMAIL_GENERATION_API:
    "https://#FUNC_APP_URL#.azurewebsites.net/api/predicting_customer_churn",
  INITIAL_ACTIONS: [
    "Do you have any demos for AI Design Wins?",
    "Do you have any demos for Fabric with Databricks?",
    "Are there any demos available for the latest Fabric features?",
    "Do you have any demo that shows integration of Microsoft Purview and Microsoft Fabric?",
  ],

  FSI_IQ_WORKFLOW:
  "https://#FUNC_MORTGAGE_LOAN#.azurewebsites.net/api/fsi_iq_workflow",

  demoMenus: [
    {
      id: 99,
      demoId: 4,
      url: "/bank-landing-page",
      name: "Bank Landing Page",
      order: 0,
      icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/aoai_2_home_icon.png",
      arrowIcon: "",
      hidden: false,
      componentId: 3,
      componentName: "demo narrative",
      componentParameters: [
        {
          id: 1,
          key: "url",
          value:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/BG-with-logo.png",
        },
      ],
      externalArrows: [],
      personaId: 1,
      personaName: "Kayo",
      personaImageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
    },
    {
      id: 99,
      demoId: 4,
      url: "/microsoft-iq-overview",
      name: "Microsoft IQ Overview",
      order: 0,
      icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/icon12.png",
      arrowIcon: "",
      hidden: false,
      componentId: 3,
      componentName: "backend video work iq",
      componentParameters: [
        {
          id: 1,
          key: "url",
          value:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/videos/Microsoft IQ Overview.mp4"
            
        },
      ],
      externalArrows: [],
      personaId: 1,
      personaName: "Kayo",
      personaImageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
    },
    {
      id: 99,
      demoId: 4,
      url: "/demo-architecture",
      name: "Demo Architecture",
      order: 0,
      icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/dashboard_icon.png",
      arrowIcon: "",
      hidden: false,
      componentId: 3,
      componentName: "demo architecture",
      componentParameters: [
        {
          id: 1,
          key: "url",
          value:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Microsoft-IQ-FSI-Lending-Agents.png",
        },
      ],
      externalArrows: [],
      personaId: 1,
      personaName: "Kayo",
      personaImageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
    },
    {
      id: 1,
      demoId: 4,
      url: "",
      name: "Intro & CEO Dashboard",
      order: 1,
      hidden: true,
      icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/aoai_2_home_icon.png",
      arrowIcon: "",
      demoSubMenus: [
        {
          id: 1,
          url: "/landing-page",
          name: "Landing Page",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/icon1_2.png",
          arrowIcon: null,
          order: 1,
          componentId: 3,
          componentName: "custom landing page",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/landing--page.png",
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Molly",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-molly.jpg",
        },
        {
          id: 2,
          url: "Before Dashboard",
          name: "Before Dashboard",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/dashboard_icon.png",
          arrowIcon: null,
          order: 2,
          componentId: 2,
          componentName: "power bi report",
          componentParameters: [],
          externalArrows: [],
          personaId: 1,
          personaName: "Kayo",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
        },
      ],
      componentParameters: [],
      externalArrows: [],
      componentId: null,
      componentName: null,
      personaId: null,
      personaName: null,
      personaImageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
    },
    {
      id: 98,
      demoId: 4,
      url: "",
      name: "Introduction to Caldova and Business Problem",
      order: 3,
      icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
      arrowIcon: "",
      hidden: false,
      demoSubMenus: [
        {
          id: 9801,
          url: "/intro-to-zava-bank",
          name: "Introduction to Caldova Bank",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 1,
          componentId: 3,
          componentName: "demo narrative",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/BG-with-logo.png",
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Kayo",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
        },
        {
          id: 9801,
          url: "/work-iq-overview",
          name: "Work IQ Overview",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 1,
          componentId: 3,
          componentName: "demo architecture",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-work-iq.png",
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Kayo",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
        },
        {
          id: 9804,
          url: "/head-of-mortgages-before-dashboard",
          name: "Head of Mortgages - Before Dashboard",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/dashboard_icon.png",
          arrowIcon: null,
          order: 4,
          componentId: 2,
          componentName: "power bi report",
          componentParameters: [
            {
              id: 300,
              key: "url",
              value:
                "https://app.powerbi.com/groups/#PBI_WORKSPACE_ID#/reports/#PBI_REPORT_ID#/5a2906582ddab13b2518?redirectedFromSignup=1&experience=power-bi",
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Molly",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-molly.jpg",
        },
      ],
      componentParameters: [],
      externalArrows: [],
      componentId: null,
      componentName: null,
      personaId: null,
      personaName: "Molly",
      personaImageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-molly.jpg",
    },
    {
      id: 97,
      demoId: 4,
      url: "",
      name: "Customer Journey",
      order: 4,
      icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
      arrowIcon: "",
      hidden: false,
      componentId: null,
      componentName: null,
      demoSubMenus: [
        {
          id: 9701,
          url: "/customer-journey-overview",
          name: "Customer Journey Overview",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 1,
          componentId: 3,
          componentName: "backend video work iq",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/videos/FSI-Customer-Journey-overview-caldova.mp4"
            },
            {
              id: 2,
              key: "originalSize",
              value: true,
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Joe",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/joe.png",
        },
        {
          id: 9702,
          url: "/customer-journey",
          name: "Schedule meetings",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 2,
          componentId: null,
          componentName: "application submission",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Caldova bank logo-mobile ver-1.png",
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Joe",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/joe.png",
        },
      ],
      externalArrows: [],
      personaId: 1,
      personaName: "Joe",
      personaImageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/joe.png",
    },
    {
      id: 96,
      demoId: 4,
      url: "",
      name: "Mortgage Officer Journey",
      order: 5,
      icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
      arrowIcon: "",
      hidden: false,
      demoSubMenus: [
        {
          id: 9603,
          url: "/mortgage-officer",
          name: "Mortgage Officer",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 3,
          componentId: 3,
          componentName: "mortgage officer",
          componentParameters: [],
          externalArrows: [],
          personaId: 1,
          personaName: "Robin",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-robin.png",
        },
        {
          id: 9604,
          url: "/backend-video-work-iq",
          name: "Work IQ Video",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 4,
          componentId: 3,
          componentName: "backend video work iq",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/videos/FSI-WorkIQ-Video-Caldova.mp4"
              },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Robin",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-robin.png",
        },
        {
          id: 9601,
          url: "/application-submission",
          name: "Application Submission",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/dashboard_icon.png",
          arrowIcon: null,
          order: 1,
          componentId: 3,
          componentName: "application submission",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Caldova bank logo-mobile ver-1.png",
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Joe",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/joe.png",
        },
        {
          id: 9607,
          url: "/loan-application-review",
          name: "Loan Application Review",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/dashboard_icon.png",
          arrowIcon: null,
          order: 7,
          componentId: 3,
          componentName: "loan application review",
          componentParameters: [],
          externalArrows: [],
          personaId: 1,
          personaName: "Robin",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-robin.png",
        },
        {
          id: 9604,
          url: "/backend-video-rti",
          name: "Backend Video RTI",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 4,
          componentId: 3,
          componentName: "backend video work iq",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/videos/BackendVideoRTI.mp4"
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Robin",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-robin.png",
        },
        {
          id: 9604,
          url: "/backend-video-foundry-iq",
          name: "Backend Video Foundry IQ",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 4,
          componentId: 3,
          componentName: "backend video work iq",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/videos/BackendVideoFoundary-IQ.mp4"
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Robin",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-robin.png",
        },
        {
          id: 9604,
          url: "/backend-video-fabric-iq",
          name: "Backend video of Fabric IQ​",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 4,
          componentId: 3,
          componentName: "backend video work iq",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/videos/Backend-Video-FabricIQ.mp4"
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Kayo",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
        },
      ],
      componentParameters: [],
      externalArrows: [],
      componentId: null,
      componentName: null,
      personaId: null,
      personaName: "Robin",
      personaImageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-robin.png",
    },
    {
      id: 95,
      demoId: 4,
      url: "",
      name: "Final Steps to Mortgage Decision​",
      order: 6,
      icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
      arrowIcon: "",
      hidden: false,
      demoSubMenus: [
        {
          id: 9505,
          url: "/loan-approval-and-next-best-offers",
          name: "Loan Approval and Next Best Offers",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 4,
          componentId: 3,
          componentName: "backend video work iq",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/videos/FSI-Loan-Approval-and-Next-Best-offer-Caldova.mp4"
                },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Robin",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-robin.png",
        },
      ],
      componentParameters: [],
      externalArrows: [],
      componentId: null,
      componentName: null,
      personaId: null,
      personaName: null,
      personaImageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
    },
    {
      id: 94,
      demoId: 4,
      url: "",
      name: "Finale",
      order: 7,
      icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/post-fabric-icon.png",
      arrowIcon: "",
      hidden: false,
      demoSubMenus: [
        {
          id: 9401,
          url: "/after-dashboard",
          name: "After Dashboard",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/dashboard_icon.png",
          arrowIcon: null,
          order: 1,
          componentId: 2,
          componentName: "power bi report",
          componentParameters: [
            {
              id: 301,
              key: "url",
              value:
                "https://app.powerbi.com/groups/#PBI_WORKSPACE_ID#/reports/#PBI_REPORT_ID#/ea79c552a9a3d80abe20?redirectedFromSignup=1&experience=power-bi",
            },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Molly",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-molly.jpg",
        },
        {
          id: 9604,
          url: "/finale-video",
          name: "Finale Video",
          icon: "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/microSoftLogoV3.png",
          arrowIcon: null,
          order: 4,
          componentId: 3,
          componentName: "backend video work iq",
          componentParameters: [
            {
              id: 1,
              key: "url",
              value:
                "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/videos/FSI-End-to-End-Video-Caldova.mp4"   
              },
          ],
          externalArrows: [],
          personaId: 1,
          personaName: "Kayo",
          personaImageUrl:
            "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Kayo-Caldova-ceo-pp.jpg",
        },
      ],
      componentParameters: [],
      externalArrows: [],
      componentId: null,
      componentName: null,
      personaId: null,
      personaName: "Robin",
      personaImageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/fsi-robin.png",
    },
  ],
  id: 410,
  userId: 85,
  customerId: 374,
  industryId: 1,
  preFillCredentials: true,
  customerName: "Contoso",
  customerEmail: "anna@city.gov.cs",
  name: "Contoso",
  password: "12345",
  title: "Contoso",
  logoImageURL:
    "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Caldova Bank.png",
  backgroundImageURL:
    "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/aoai_2_login_background.png",
  chatImageLogoURL:
    "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/aoai_2_chat_logo.png",
  backgroundColor: null,
  primaryColor: "#00a1cbff",
  secondaryColor: "#004b76ff",
  headerImageUrl:
    "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/contoso_top_level_header_bg.png",
  headerBgColor: "rgba(97, 160, 4, 1)",
  navImageUrl:
    "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/contoso_left_nav_bg.png",
  navColor: "rgba(97, 160, 4, 1)",
  isFavorite: false,
  description: "Ask me something",
  subTitle: "Contoso",
  color: null,
  isEnabled: true,
  endPointURL: null,
  documents: [],
  campaigns: [
    {
      id: 397,
      name: "Electric Bus",
      imageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/Input_Bus.png",
      demoId: 410,
      order: 3,
      instagramText:
        "Write an Instagram post for the city Contoso, showcasing their groundbreaking electric bus fleet and its eco-friendly technology and efficiency. The post should include the following: \n1. A captivating headline for the Instagram post. \n2. Use words that convey sustainability and efficiency. \n3. Craft a short paragraph that highlights the bus's features and benefits. \n4. Choose emojis that emphasize eco-friendliness and convenience. \n5. Incorporate relevant hashtags to increase visibility. \n6. The post should have a minimum of 40 words. \nConsidering everything described above, give me an Instagram post having a title, post content with appropriate hashtags and emojis. Close the post with a poem as described above. ",
      emailText:
        "Write an email advertisement for the city of Contoso, showcasing their groundbreaking electric bus fleet. The email should highlight a special promotion of a 20% discount on electric bus tours to celebrate the city's commitment to eco-friendly and efficient public transportation. The email should include the following: \n1. A captivating subject line for the email. \n2. Words that emphasize sustainability and convenient travel. \n3. A brief poem capturing the essence of green mobility. \n4. Include emojis that signify eco-friendliness. \n5. Add relevant hashtags to engage a broader audience. \n6. The email should comprise a minimum of 40 words. \nConsidering everything described above, give me an Instagram post having a title, post content with appropriate hashtags and emojis. Close the post with a poem as described above. ",
      bgPrompt: null,
    },
    {
      id: 396,
      name: "Electric Taxi/Cab",
      imageUrl:
        "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/electric_car_input.png",
      demoId: 410,
      order: 2,
      instagramText:
        "Create an Instagram post for Contoso, featuring their cutting-edge electric taxi/cab service. The post should highlight the eco-conscious and speedy nature of our taxis. Your post should include: \n1. An attention-grabbing headline for the Instagram post. \n2. Use words that convey eco-awareness and speed. \n3. Craft a short paragraph showcasing the taxi's eco-friendly features and efficiency. \n4. Include emojis that emphasize sustainability and performance. \n5. Include relevant hashtags to boost visibility. \n6. Ensure the post contains a minimum of 40 words. \nConsidering everything described above, give me an Instagram post having a title, post content with appropriate hashtags and emojis. Close the post with a poem as described above. ",
      emailText:
        "Write an email advertisement for Contoso, featuring their cutting-edge electric taxi/cab service. The email should highlight a special promotion of a 20% discount on electric taxi/cab tours to celebrate the city's commitment to eco-friendly and efficient public transportation services. The email should include the following: \n1. A captivating subject line. \n2. Use words that convey eco-awareness and speed. \n3. Craft a short message highlighting the discount and the eco-friendly car's features. \n4. Choose emojis that emphasize sustainability and performance. \n5. Incorporate relevant hashtags. \n6. The email should have a minimum of 40 words. \nConsidering everything described above, give me an Instagram post having a title, post content with appropriate hashtags and emojis. Close the post with a poem as described above. ",
      bgPrompt: null,
    },
  ],
  prompt1:
    "What are the five most important insights for effectively marketing to millennials?",
  prompt2:
    "How are the shopping behaviors and preferences of millennials shaping the retail industry?",
  prompt3: "What can we learn and deduce around retaining millennials?",
  questionPlaceHolder:
    "What are the five most important insights for effectively marketing to millennials?",
  iFrames: [],
  userName: "Kayo@caldovabank.com",
  loginBoxImage:
    "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/CONTOSO_login_visual.png",
  loginBackground:
    "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/aoai_2_login_background.png",
  loginBackgroundColor: "#090254",
  loginTextBoxImage:
    "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/contoso_login_text_box.png",
  disableTitle: true,
  navBarPrimaryColor: "#004b76ff",
  navBarSecondaryColor: "#004b76ff",
  navBarTextColor: "rgba(255, 255, 255, 1)",
  tabPrimaryColor: "#00a1cbff",
  tabSecondaryColor: "#004b76ff",
  dropdownPrimaryColor: "#00a1cbff",
  dropdownSecondaryColor: "#004b76ff",
  scrollBarPrimaryColor: "rgba(255, 255, 255, 0.5)",
  scrollBarSecondaryColor: "#004b76ff",
  pdfUploadApi: null,
  florenceAdApi: null,
  florenceDallEApi: null,
  dalleRegenerateAPI: null,
  dropdownTextColor: null,
  tabTextColor: "rgba(255, 255, 255, 1)",
  chatApproach: null,
  guid: "#GUID#",
  chatCompany: null,
  DELAY_TIME: 2000,
  callCenterReportID: "#CALL_CENTER_REPORT_ID#",
  callCenterReportSectionName: "ReportSection623b64746831c0065bc0",
  callCenterVideoURL: "",
  callCenterScript: `Meena: Thank you for reaching out to the City Call Center. I'm Meena, and I'm here to assist you. \nBrent: Hi Meena, I'm a concerned resident in the city. I've been hearing about the city's sustainability efforts, particularly related to air quality and green initiatives. Can you tell me more about these? \nMeena: Absolutely, Brent. We take sustainability seriously, and we have some exciting initiatives in place. First, let's talk about air quality. We've introduced a fleet of green buses that run on clean energy sources. These buses are reducing harmful emissions and contributing to cleaner air in the city. \nBrent: That's impressive. What about the sustainable buildings and the green rooftops I've heard about? \nMeena: We're equally committed to sustainable urban planning. Our new buildings incorporate proper ventilation and eco-friendly materials, ensuring better indoor air quality. The green rooftops you mentioned are indeed a part of our efforts. They help retain rainwater, reducing pressure on our drainage systems, and also play a role in temperature regulation, making our city more energy-efficient. \nBrent: It's great to see these efforts. Are there more sustainability initiatives you can tell me about? \nMeena: Of course, Brent. We have an array of programs. Recycling is a big part of our sustainability push. We also encourage urban gardening and work on waste reduction and energy efficiency initiatives. If you'd like more information or want to participate, I can provide you with details. \nBrent: That's fantastic, Meena. I'd love to learn more about the recycling programs and urban gardens. How can I get involved? \nMeena: I can certainly provide you with all the details you need. You can join our urban gardening community and participate in various recycling drives. We appreciate residents like you who actively contribute to our sustainability goals. \nBrent: Thank you, Meena. I'm excited to get involved and support these initiatives. \nMeena: We're delighted to have you on board, Brent. If you have more questions or need further information, please feel free to ask. We're here to assist you. \nBrent: Thank you, Meena. I appreciate your help. Have a great day! \nMeena: You too, Brent! Have a wonderful day, and thank you for your dedication to a greener, healthier city.`,
  callCenterCustomerImage: "customer_gm.png",
  callCenterBackendImage: "backend_gm.png",
  callCenterAgentImage: "agent_gm.png",
  callCenterExtractFromConversationWithKey:
    "Extract the following information from the conversation below:\nCall reason (key: reason) \nCaller name (key: caller_name)\nAgent Name (key: agent_name)\nCaller sentiment (key: caller_sentiment) \nMobile number (key: mobile_number) \nCustomer Plan Type (key: customer_plan_type)\nOffer Value (key: offered_discount) \nTravel Destination (key: travel_destination)\n A short, yet detailed summary (key: summary)\n Please answer in JSON machine-readable format, using the keys from above.If any value is not available, it should be None.Format the output as a JSON object called “results”. Pretty print the JSON and make sure that it is properly closed at the end .",
  callCenterExtractFromConversationWithoutKey:
    // "Generate a summary of the conversation in the following format with proper numbering: \n\n1. Main reason for the conversation.\n2. Sentiment of the customer.\n3. Create a short summary of the conversation.",
    // `Generate a summary of the conversation in the following format with proper numbering: \n1. Main reason for the conversation.\n2. Sentiment of the customer.\n3. How did the agent handle the conversation?\n4. What was the final outcome of the conversation?\n5. Create a short summary of the conversation.\n6. Did the agent request the order number?\n7. What SKU Number did the call correspond to?\n8. What Store ID did the call correspond to?`,
    `Generate a summary of the conversation in the following format with proper numbering: : \n1. What issue is the customer experiencing while traveling? \n2. How did the customer's sentiment change during the conversation?\n3. How did the agent handle the conversation?\n4. What was the final outcome of the conversation?\n5. Create a short summary of the conversation.\n6. What is the standard price of the International Travel Pack offered by the agent? \n7. What discounted price did the agent offer for the International Travel Pack? \n8. What final steps did the agent advise the customer to take to activate the service? `,

  showSettings: true,
  chatContainerBackgroundColor: "rgba(0, 75, 118, 1)",
  isSampleDemo: null,
  landingPageImage:
    "https://#BLOB_STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/images/landing_page_visual.png",
  order: 0,
  active: true,
  pdfUploadApi:
    "https://#FUNCTION_SEARCH_URL#.azurewebsites.net/api/pdfindexer",
  florenceAdApi:
    "https://#FLORENCE_AD_API_URL#.azurewebsites.net/api/campaigngenerationv3",
  florenceDallEApi:
    "https://#FLORENCE_DALLE_API_URL#.azurewebsites.net/api/recommendimages",
  dalleRegenerateAPI:
    "https://#DALLE_REGENERATE_API_URL#.azurewebsites.net/api/regenerate-dalle",
  summarizeConversationAPI:
    "https://#SUMMARIZE_CONVERSATION_API_URL#.openai.azure.com/daidemo/deployments/text-davinci-003/completions?api-version=2022-12-01",
  summarizeConversationAPIKey: "#SUMMARIZE_CONVERSATION_API_KEY#",
  CALL_CENTER_API: "https://#FUNC_APP_URL#.azurewebsites.net/api/",

  index: "#INDEX#",
  container: "#AI_CONTAINER#",
  CEODashboardBeforeID: "#CEO_DASHBOARD_BEFORE_ID#",
  CEODashboardBeforeReportID: "#CEO_DASHBOARD_BEFORE_REPORT_ID#",
  CEODashboardBeforeReportSectionName: "#CEO_DASHBOARD_BEFORE_REPORT_SECTION_NAME#",
  tryYourOwnDataEndpoint:
    "https://#TRY_YOUR_OWN_DATA_ENDPOINT#.azurewebsites.net/api",
  endPointURL: "https://#ENDPOINT_URL#.azurewebsites.net/api",
};
