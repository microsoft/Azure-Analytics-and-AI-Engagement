window.environment = {
  WorkspaceID: "#WorkspaceID#", // "2b3be873-2fa8-4bd2-b0e6-4b91ac5083a1",
  LogAPI: "https://app-common-powerbi-server.azurewebsites.net/ActivityLog/",
  SPEECH_KEY: "08829058ce334a5f950440324be656db",
  SPEECH_REGION: "eastus",
  BlobBaseUrl: "#BlobURL#",
  IconBlobBaseUrl: "#IconURL#",
  PersonaBlobURL: "#PersonaURL#",

  APIUrl: "https://#BackendURL#.azurewebsites.net",

  BackendAPIUrl: "https://#OpenAIBAckendURL#.azurewebsites.net",

  StartCallAPI: "https://func-aoai2-demo-prod.azurewebsites.net/api/start_call",
  Dalle3API:
    "https://func-fsi2-prod.azurewebsites.net/api/create_3_images_with_dalle3?",
  CUSTOMER_DETAILS_API:
    "https://func-aoai2-demo-prod.azurewebsites.net/api/customerdetails",
  EMAIL_GENERATION_API:
    "https://func-aoai2-demo-prod.azurewebsites.net/api/predicting_customer_churn",

  FormScannerAPIUrl: "https://func-form-recognizer-prod.azurewebsites.net",
  //--------------------------------------
  WorldMapReportID: "#WorldMapReportID#", //"07af9664-a04e-40a2-8f5b-ad7d7d3a9290",
  WorldMapReportSectionName: "ReportSectionae2d438d3737f6ada513",

  CEODashBoardJanBeforeReportID: "#CEODashBoardJanBeforeReportID#", //"231d4815-f12d-4cca-a31f-9067bcf49427",
  CEODashBoardJanBeforeSection: "ffce5ed4a1a06d5fc7c9",
  CCODashboardReportID: "#CCODashboardReportID#", //"740a9006-89fc-4e4c-b2e3-c5a1f24409f0",
  CCODashboardReportSection: "ed6ae45bd04d38c15d01",
  ESGDashboardReportID: "#ESGDashboardReportID#", //"b86ff39d-7075-4f2a-90d7-a97dbe0d2484",
  ESGDashboardReportSection: "b81ba9ac99ac033c1b63",
  ESGTalkReportId: "#ESGTalkReportId#", //"f2b829aa-ba88-4b11-af3c-0ad961a95df9",
  ESGTalkReportSection: "ReportSectioncfca52084a74580356b0",
  MSCIReportID: "#MSCIReportID#", //"5f586e7d-3fea-475c-a000-4afcd16f0847",
  MSCIReportSection: "ReportSectiond3ea9e5a414206b44eb1",
  MSCIReportAfterID: "#MSCIReportAfterID#", //"5f586e7d-3fea-475c-a000-4afcd16f0847",
  MSCIReportAfterSection: "ReportSection5d233aa8c046ad27dce4",
  CEODashBoardJuneBeforeReportID: "#CEODashBoardJuneBeforeReportID#", //"9e41671e-4f25-42f7-bc3a-3ad3587b6798"
  CEODashBoardJuneBeforeSection: "90a3214e77bebc54060e",

  CFODashBoardReportID: "#CFODashBoardReportID#", //"8285ca53-e29a-4b87-a74b-b782036bd10a"
  CFODashBoardSection: "166fb3e320b1c443871a",

  RevenueProfitReportID: "#RevenueProfitReportID#", //"5b62a50f-9b24-41e2-99fe-71f7328653a9"
  RevenueProfitSection: "ReportSection",

  CEODashBoardSeptBeforeReportID: "#CEODashBoardSeptBeforeReportID#", //"10a77e83-11c2-4c60-a670-3c0fe1c322f6"
  CEODashBoardSeptBeforeSection: "ffce5ed4a1a06d5fc7c9",

  SenitmentReportID: "#SenitmentReportID#", //"10a77e83-11c2-4c60-a670-3c0fe1c322f6"
  SenitmentReportSection: "ReportSection0678bfe0cde017e8e721",

  HofiDashBoardBeforeReportID: "#HofiDashBoardBeforeReportID#", //"befb10ec-f76b-4ab0-ae4b-ab3107e135c7"
  HofiDashBoardBeforeReportSection: "437239c414d2b9049ac5",

  HofiDashBoardAfterReportID: "#HofiDashBoardAfterReportID#", //"befb10ec-f76b-4ab0-ae4b-ab3107e135c7"
  HofiDashBoardAfterReportSection: "d61d8325c23416bc3627",

  InitialInvestmentReportID: "#InitialInvestmentReportID#", //"3ec4a8e4-e26c-4c3d-84ef-bb153af59489"
  InitialInvestmentReportSection: "ReportSection73f3b1cfd8180a98e3bc",

  ModifiedInitialInvestmentReportID: "#ModifiedInitialInvestmentReportID#", //"3ec4a8e4-e26c-4c3d-84ef-bb153af59489"
  ModifiedInitialInvestmentReportSection: "ReportSection0ef65b5c069040b3bd22",

  WealthAdviserReport: "#WealthAdviserReport#", //5effd99b-217f-47b6-b8c8-6ce0f1907ceb",
  WealthAdviserReportSection: "ReportSection73f3b1cfd8180a98e3bc",

  CallCenterBeforeSummaryReport: "#CallCenterBeforeSummaryReport#", //"6c79d1d1-bc84-4bab-8b80-b28b41f6c244"
  CallCenterBeforeSummaryReportSection: "ReportSectionda209890a7f0f9e42736", //"ReportSectionda209890a7f0f9e42736"

  CallCenterBeforeScriptReport: "#CallCenterBeforeScriptReport#", //"6c79d1d1-bc84-4bab-8b80-b28b41f6c244"
  CallCenterBeforeScriptReportSection: "ReportSection623b64746831c0065bc0", //"ReportSection623b64746831c0065bc0"

  CallCenterAfterSummaryReport: "#CallCenterAfterSummaryReport#", //"fa82c4db-2d39-4c91-8057-1b144ea6c5c4"
  CallCenterAfterSummaryReportSection: "ReportSectionda209890a7f0f9e42736", //"ReportSection623b64746831c0065bc0"

  CallCenterAfterScriptReport: "#CallCenterAfterScriptReport#", //"fa82c4db-2d39-4c91-8057-1b144ea6c5c4"
  CallCenterAfterScriptReportSection: "ReportSection623b64746831c0065bc0", //"ReportSection623b64746831c0065bc0"

  CEODashBoardDecBeforeReportID: "#CEODashBoardDecBeforeReportID#", //"485d377a-0a54-487b-aa6a-e0ef10e9ed2a"
  CEODashBoardDecBeforeSection: "0dac2b94a5468065897e",

  HtapReportID: "#HtapReportID#", //"485d377a-0a54-487b-aa6a-e0ef10e9ed2a"
  HtapSection: "ReportSection7cb15bccee28f85ee6c5",

  HtapWithAzureCosmosReportID: "#HtapWithAzureCosmosReportID#", //"485d377a-0a54-487b-aa6a-e0ef10e9ed2a"
  HtapWithAzureCosmosSection: "ReportSectionac43dfdb10c718d00489",

  ExecutiveDashboardBeforeTopReportID: "68f84ee9-6513-475b-894d-30eb92e272c0",
  ExecutiveDashboardBeforeTopReportName: "ReportSection5f752c6bde03670c8284",
  ExecutiveDashboardBeforeDashboardID: "94f74092-c75a-4474-b093-00a19963365d",

  ExecutiveDashboardAfterTopReportID: "68f84ee9-6513-475b-894d-30eb92e272c0",
  ExecutiveDashboardAfterTopReportName: "ReportSection68cb8066934630a72b53",
  ExecutiveDashboardAfterDashboardID: "94f74092-c75a-4474-b093-00a19963365d",

  FinanceRevenueAndProfitabilityReportID:
    "7e72d293-e1d4-4a4d-92fd-fb1fc57e71c9",
  FinanceRevenueAndProfitabilityReportSectionName: "ReportSection",

  CustomerChurnReportID: "39d0deed-a4a5-4d7d-b746-36b36839dd3b",
  CustomerChurnReportSectionName: "ReportSection05c28ac273e0d030e640",
  SalesPerformenceReportID: "ce87447d-56ec-48d1-a562-b06d96533d41",
  SalesPerformenceReportSectionName: "ReportSection",

  CampaignAnalyticsReportID: "70bc1234-b9f0-46d4-b9a3-c127e66bbcc1",
  CampaignAnalyticsReportSectionName: "ReportSection",

  HRAnalyticsReportID: "e8173a33-22d2-4e16-9d78-eb3a033b8ba3",
  HRAnalyticsReportSectionName: "ReportSection",

  OperationsReportID: "42772036-e12f-4c53-bb3c-64d38ec2a20e",
  OperationsReportSectionName: "ReportSection",

  ITReportID: "270451a4-08c4-4eae-afa4-4a2f779190a6",
  ITReportSectionName: "ReportSection",

  StoreVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/91dff02c-8b6a-4eb4-906b-1d8f224ca7e0/Fabric_StoreVideo_V06.ism/manifest",
  FinalVideoUrl:
    "https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/7b28bfbe-7bfd-4cbf-8b8e-3647950742b1/Fabric_2_Demo_Finale08.ism/manifest",
};
