﻿namespace LocationAnalytics
{
    public class Department
    {
        public string Name { get; set; }
        public string[] Items { get; set; }
        public int PassingCutoff { get; set; }
        public int PassingCutoff1 { get; set; }
    }
}
